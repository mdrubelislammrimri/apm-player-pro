package app.apmplayer.ui.components

import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Star
import androidx.compose.material.icons.rounded.StarBorder
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import app.apmplayer.ui.theme.Apm
import app.apmplayer.ui.theme.n
import kotlin.math.ceil

/**
 * Five stars. Tap a star to rate, tap the same one again to clear, tap the empty space before the first star to clear,
 * swipe over the stars to choose, press and hold to switch between 5 and 0 stars.
 */
@Composable
fun StarRating(rating: Int, onRate: (Int) -> Unit, modifier: Modifier = Modifier, starSize: Dp = 30.dp) {
    var preview by remember { mutableStateOf<Int?>(null) }
    var widthPx by remember { mutableFloatStateOf(1f) }
    val shown = preview ?: rating
    fun starAt(x: Float): Int = ceil(x / widthPx * 5f).toInt().coerceIn(0, 5)
    Row(
        modifier
            .onSizeChanged { widthPx = it.width.toFloat().coerceAtLeast(1f) }
            .pointerInput(rating) {
                detectTapGestures(
                    onTap = { o ->
                        val picked = starAt(o.x)
                        onRate(if (picked == rating) 0 else picked)
                    },
                    onLongPress = { onRate(if (rating >= 5) 0 else 5) },
                )
            }
            .pointerInput(rating) {
                detectHorizontalDragGestures(
                    onDragStart = { o -> preview = starAt(o.x) },
                    onDragEnd = {
                        preview?.let(onRate)
                        preview = null
                    },
                    onDragCancel = { preview = null },
                ) { change, _ ->
                    change.consume()
                    preview = starAt(change.position.x)
                }
            }
            .semantics { contentDescription = "Rating $rating of 5 stars" },
        horizontalArrangement = Arrangement.spacedBy(2.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        for (i in 1..5) {
            Icon(
                if (i <= shown) Icons.Rounded.Star else Icons.Rounded.StarBorder,
                contentDescription = null,
                tint = if (i <= shown) Apm.colors.accent else n(Color(0xFF8A8A8A)),
                modifier = Modifier.size(starSize),
            )
        }
    }
}
