package app.apmplayer.lyrics

import android.content.Context
import android.net.Uri
import android.provider.DocumentsContract
import java.nio.charset.Charset

/** Finds .lrc and .txt lyrics files in a folder the user picked once, and reads them. */
object LrcFolder {
    /** Name of the file without its type, in small letters, to the file. A .lrc wins over a .txt of the same name. */
    fun index(context: Context, tree: Uri): Map<String, Uri> {
        val out = HashMap<String, Uri>()
        val queue = ArrayDeque<Pair<String, Int>>()
        queue.add(DocumentsContract.getTreeDocumentId(tree) to 0)
        var seen = 0
        while (queue.isNotEmpty() && seen < 30_000) {
            val (docId, depth) = queue.removeFirst()
            val children = DocumentsContract.buildChildDocumentsUriUsingTree(tree, docId)
            val columns = arrayOf(
                DocumentsContract.Document.COLUMN_DOCUMENT_ID,
                DocumentsContract.Document.COLUMN_DISPLAY_NAME,
                DocumentsContract.Document.COLUMN_MIME_TYPE,
            )
            context.contentResolver.query(children, columns, null, null, null)?.use { c ->
                while (c.moveToNext()) {
                    seen++
                    val id = c.getString(0)
                    val name = c.getString(1) ?: continue
                    if (c.getString(2) == DocumentsContract.Document.MIME_TYPE_DIR) {
                        if (depth < 6) queue.add(id to depth + 1)
                        continue
                    }
                    val lower = name.lowercase()
                    if (lower.endsWith(".lrc") || lower.endsWith(".txt")) {
                        val base = lower.substringBeforeLast('.')
                        if (lower.endsWith(".lrc") || base !in out) out[base] = DocumentsContract.buildDocumentUriUsingTree(tree, id)
                    }
                }
            }
        }
        return out
    }

    /** Reads a lyrics file. UTF-8 (or UTF-16 with a mark) unless [utf8Only] is off, then [fallback] is used for non-Unicode files. */
    fun readText(context: Context, uri: Uri, utf8Only: Boolean, fallback: Charset): String? {
        val bytes = try {
            context.contentResolver.openInputStream(uri)?.use { it.readBytes() }
        } catch (e: Exception) {
            null
        } ?: return null
        if (bytes.size > 400_000) return null
        if (bytes.size >= 2 && bytes[0] == 0xFF.toByte() && bytes[1] == 0xFE.toByte()) return String(bytes, Charsets.UTF_16LE)
        if (bytes.size >= 2 && bytes[0] == 0xFE.toByte() && bytes[1] == 0xFF.toByte()) return String(bytes, Charsets.UTF_16BE)
        val text = if (utf8Only) {
            String(bytes, Charsets.UTF_8)
        } else {
            val strict = try {
                Charsets.UTF_8.newDecoder().decode(java.nio.ByteBuffer.wrap(bytes)).toString()
            } catch (e: Exception) {
                null
            }
            strict ?: String(bytes, fallback)
        }
        return text.removePrefix("\uFEFF").takeIf { it.isNotBlank() }
    }
}
