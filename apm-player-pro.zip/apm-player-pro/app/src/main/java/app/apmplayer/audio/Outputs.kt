package app.apmplayer.audio

import android.content.Context
import android.media.AudioDeviceInfo
import android.media.AudioManager

/** The kinds of output the settings talk about. */
enum class OutputKind(val label: String) {
    WIRED("Wired Headset/AUX"),
    SPEAKER("Speaker"),
    BLUETOOTH("Bluetooth"),
    USB("USB DAC"),
    OTHER("Other Output Devices"),
}

object Outputs {
    fun kindOf(type: Int): OutputKind = when (type) {
        AudioDeviceInfo.TYPE_WIRED_HEADSET, AudioDeviceInfo.TYPE_WIRED_HEADPHONES, AudioDeviceInfo.TYPE_LINE_ANALOG, AudioDeviceInfo.TYPE_LINE_DIGITAL -> OutputKind.WIRED
        AudioDeviceInfo.TYPE_BUILTIN_SPEAKER, AudioDeviceInfo.TYPE_BUILTIN_EARPIECE -> OutputKind.SPEAKER
        AudioDeviceInfo.TYPE_BLUETOOTH_A2DP, AudioDeviceInfo.TYPE_BLUETOOTH_SCO, 26, 27 -> OutputKind.BLUETOOTH // 26 and 27 are the Bluetooth LE headset and speaker
        AudioDeviceInfo.TYPE_USB_DEVICE, AudioDeviceInfo.TYPE_USB_HEADSET, AudioDeviceInfo.TYPE_USB_ACCESSORY -> OutputKind.USB
        else -> OutputKind.OTHER
    }

    /** The output the sound goes to now, guessed from what is connected: a USB device, then a wired one, then Bluetooth, else the speaker. */
    fun active(context: Context): OutputKind {
        val kinds = context.getSystemService(AudioManager::class.java)
            .getDevices(AudioManager.GET_DEVICES_OUTPUTS).map { kindOf(it.type) }.toSet()
        return when {
            OutputKind.USB in kinds -> OutputKind.USB
            OutputKind.WIRED in kinds -> OutputKind.WIRED
            OutputKind.BLUETOOTH in kinds -> OutputKind.BLUETOOTH
            OutputKind.SPEAKER in kinds -> OutputKind.SPEAKER
            else -> OutputKind.OTHER
        }
    }
}
