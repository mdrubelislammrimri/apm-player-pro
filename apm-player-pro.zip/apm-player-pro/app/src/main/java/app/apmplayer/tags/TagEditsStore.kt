package app.apmplayer.tags

import android.content.Context
import org.json.JSONObject

/** A change to how a song is named inside this app. null means "keep what the file says", an empty text means "no value". */
data class TagEdit(val title: String?, val artist: String?, val album: String?)

/**
 * Edited names, kept by this app and applied every time the library is scanned.
 * The song file itself is never changed, so a scan can always go back to what the file says.
 */
class TagEditsStore(context: Context) {
    private val prefs = context.getSharedPreferences("tagedits", Context.MODE_PRIVATE)

    fun put(mediaStoreId: Long, edit: TagEdit) {
        val json = JSONObject()
        edit.title?.let { json.put("title", it) }
        edit.artist?.let { json.put("artist", it) }
        edit.album?.let { json.put("album", it) }
        prefs.edit().putString("m$mediaStoreId", json.toString()).apply()
    }

    fun remove(mediaStoreId: Long) {
        prefs.edit().remove("m$mediaStoreId").apply()
    }

    fun has(mediaStoreId: Long): Boolean = prefs.contains("m$mediaStoreId")

    /** Every edit, by the song's id in the phone's media library. */
    fun all(): Map<Long, TagEdit> {
        val out = HashMap<Long, TagEdit>()
        for ((key, value) in prefs.all) {
            val id = key.removePrefix("m").toLongOrNull() ?: continue
            try {
                val json = JSONObject(value as String)
                out[id] = TagEdit(
                    title = if (json.has("title")) json.getString("title") else null,
                    artist = if (json.has("artist")) json.getString("artist") else null,
                    album = if (json.has("album")) json.getString("album") else null,
                )
            } catch (e: Exception) {
                // a damaged entry is ignored
            }
        }
        return out
    }
}
