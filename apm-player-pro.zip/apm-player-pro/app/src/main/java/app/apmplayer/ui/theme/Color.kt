// generated from tokens.json and tokens.light.json. Change the tokens, not this file.
package app.apmplayer.ui.theme

import androidx.compose.runtime.Immutable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color

@Immutable
data class ApmColors(
    val bg: Color,
    val surface: Color,
    val surfaceRaised: Color,
    val border: Color,
    val borderInput: Color,
    val text: Color,
    val textMuted: Color,
    val accent: Color,
    val onAccent: Color,
    val danger: Color,
    val success: Color,
    val warning: Color,
    val focusRing: Color,
    val waveUnplayed: Color,
    val chipBgWorst: Color,
    val chipText: Color,
)

val DarkApmColors = ApmColors(
    bg = Color(0xFF000000),
    surface = Color(0xFF121212),
    surfaceRaised = Color(0xFF1F1F1F),
    border = Color(0xFF3A3A3A),
    borderInput = Color(0xFF8A8A8A),
    text = Color(0xFFF3F5F8),
    textMuted = Color(0xFFA5ADBA),
    accent = Color(0xFF4FD1C5),
    onAccent = Color(0xFF04211E),
    danger = Color(0xFFFF7B7B),
    success = Color(0xFF4ADE80),
    warning = Color(0xFFFBBF24),
    focusRing = Color(0xFF8AE6DC),
    waveUnplayed = Color(0xFF7A828E),
    chipBgWorst = Color(0xFF4D4D4D),
    chipText = Color(0xFFFFFFFF),
)

val LightApmColors = ApmColors(
    bg = Color(0xFFF7F8FA),
    surface = Color(0xFFFFFFFF),
    surfaceRaised = Color(0xFFFFFFFF),
    border = Color(0xFFE1E4E8),
    borderInput = Color(0xFF6B7280),
    text = Color(0xFF101318),
    textMuted = Color(0xFF525A66),
    accent = Color(0xFF0F766E),
    onAccent = Color(0xFFFFFFFF),
    danger = Color(0xFFC62828),
    success = Color(0xFF1B7A43),
    warning = Color(0xFF8A5A00),
    focusRing = Color(0xFF0F766E),
    waveUnplayed = Color(0xFF6B7280),
    chipBgWorst = Color(0xFF4D4D4D),
    chipText = Color(0xFFFFFFFF),
)

val LocalApmColors = staticCompositionLocalOf { DarkApmColors }
