package app.apmplayer.util

import java.util.Locale

/** 44100 -> "44.1", 48000 -> "48". */
fun formatKiloHertz(hz: Int): String =
    if (hz % 1000 == 0) (hz / 1000).toString() else String.format(Locale.ROOT, "%.1f", hz / 1000.0)

/** Short codec name for the info line, like "AAC LC" or "FLAC". */
fun codecLabel(mime: String?, codecs: String?): String = when {
    codecs?.startsWith("mp4a.40.2") == true -> "AAC LC"
    codecs?.startsWith("mp4a.40.5") == true -> "HE-AAC"
    codecs?.startsWith("mp4a.40.29") == true -> "HE-AAC V2"
    mime == "audio/mpeg" -> "MP3"
    mime == "audio/flac" -> "FLAC"
    mime == "audio/vorbis" -> "VORBIS"
    mime == "audio/opus" -> "OPUS"
    mime == "audio/raw" -> "WAV"
    mime == "audio/alac" -> "ALAC"
    mime == "audio/mp4a-latm" -> "AAC"
    else -> mime?.substringAfter('/')?.uppercase(Locale.ROOT).orEmpty()
}

/** "44.1 KHZ 96 KBPS AAC LC". Parts that are unknown are left out. */
fun audioInfoLine(sampleRate: Int, bitrateBps: Int, codec: String): String =
    listOfNotNull(
        sampleRate.takeIf { it > 0 }?.let { formatKiloHertz(it) + " KHZ" },
        bitrateBps.takeIf { it > 0 }?.let { (it / 1000).toString() + " KBPS" },
        codec.takeIf { it.isNotBlank() },
    ).joinToString(" ")

/** File type shown in the track menu, from the MIME type. */
fun mimeToExtension(mime: String?): String = when (mime) {
    "audio/mpeg" -> "mp3"
    "audio/mp4", "audio/mp4a-latm", "audio/x-m4a" -> "m4a"
    "audio/flac", "audio/x-flac" -> "flac"
    "audio/ogg", "application/ogg" -> "ogg"
    "audio/x-wav", "audio/wav", "audio/vnd.wave" -> "wav"
    "audio/opus" -> "opus"
    null -> ""
    else -> mime.substringAfter('/').removePrefix("x-")
}
