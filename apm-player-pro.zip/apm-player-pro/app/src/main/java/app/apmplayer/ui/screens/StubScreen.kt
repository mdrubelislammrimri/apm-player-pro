package app.apmplayer.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import app.apmplayer.ui.components.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextAlign
import app.apmplayer.ui.theme.Apm
import app.apmplayer.ui.theme.ApmSpace

/** Stands in for screens that are routed but not built yet. */
@Composable
fun StubScreen(title: String, note: String) {
    Column(
        modifier = Modifier.fillMaxSize().padding(ApmSpace.s5),
        verticalArrangement = Arrangement.spacedBy(ApmSpace.s2, Alignment.CenterVertically),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text(title, style = Apm.type.title, color = Apm.colors.text)
        Text(note, style = Apm.type.bodySm, color = Apm.colors.textMuted, textAlign = TextAlign.Center)
    }
}
