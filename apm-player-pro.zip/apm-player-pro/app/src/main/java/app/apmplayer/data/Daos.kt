package app.apmplayer.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface ArtistDao {
    @Query("SELECT * FROM artists WHERE name = :name LIMIT 1")
    suspend fun findByName(name: String): ArtistEntity?

    @Insert
    suspend fun insert(artist: ArtistEntity): Long
}

@Dao
interface AlbumDao {
    @Query("SELECT * FROM albums WHERE title = :title AND ((:artistId IS NULL AND artist_id IS NULL) OR artist_id = :artistId) LIMIT 1")
    suspend fun find(title: String, artistId: Long?): AlbumEntity?

    @Insert
    suspend fun insert(album: AlbumEntity): Long
}

@Dao
interface FolderDao {
    @Query("SELECT * FROM folders WHERE path = :path LIMIT 1")
    suspend fun findByPath(path: String): FolderEntity?

    @Insert
    suspend fun insert(folder: FolderEntity): Long

    @Query("SELECT * FROM folders WHERE parent_id IS NULL ORDER BY name COLLATE NOCASE")
    fun observeRoots(): Flow<List<FolderEntity>>

    @Query(
        "SELECT c.* FROM folders c JOIN folders p ON c.parent_id = p.id " +
            "WHERE p.path = :path ORDER BY c.name COLLATE NOCASE"
    )
    fun observeChildren(path: String): Flow<List<FolderEntity>>
}

@Dao
interface TrackDao {
    @Query("SELECT * FROM tracks WHERE media_store_id = :mediaStoreId LIMIT 1")
    suspend fun findByMediaStoreId(mediaStoreId: Long): TrackEntity?

    @Insert
    suspend fun insert(track: TrackEntity): Long

    @Update
    suspend fun update(track: TrackEntity)

    @Query("UPDATE tracks SET is_missing = 1 WHERE scan_generation < :generation")
    suspend fun markMissing(generation: Long)

    @Query(
        "SELECT t.*, a.name AS artist_name FROM tracks t " +
            "JOIN folders f ON t.folder_id = f.id " +
            "LEFT JOIN artists a ON t.artist_id = a.id " +
            "WHERE f.path = :path AND t.is_missing = 0 ORDER BY t.title COLLATE NOCASE"
    )
    fun observeInFolder(path: String): Flow<List<TrackWithArtist>>

    @Query(
        "SELECT t.*, a.name AS artist_name FROM tracks t " +
            "LEFT JOIN artists a ON t.artist_id = a.id " +
            "WHERE t.is_missing = 0 AND (t.title LIKE '%' || :query || '%' OR a.name LIKE '%' || :query || '%') " +
            "ORDER BY t.title COLLATE NOCASE LIMIT 300"
    )
    fun search(query: String): Flow<List<TrackWithArtist>>

    @Query(
        "SELECT t.*, a.name AS artist_name, al.title AS album_title, f.path AS folder_path FROM tracks t " +
            "JOIN folders f ON t.folder_id = f.id " +
            "LEFT JOIN artists a ON t.artist_id = a.id " +
            "LEFT JOIN albums al ON t.album_id = al.id WHERE t.id = :id LIMIT 1"
    )
    fun observeDetail(id: Long): Flow<TrackDetail?>

    @Query("UPDATE tracks SET rating = :rating WHERE id = :id")
    suspend fun setRating(id: Long, rating: Int)

    @Query("UPDATE tracks SET play_count = play_count + 1, last_played_ms = :now WHERE id = :id")
    suspend fun markPlayed(id: Long, now: Long)
}

@Dao
interface WaveformDao {
    @Query("SELECT * FROM waveforms WHERE track_id = :trackId LIMIT 1")
    suspend fun find(trackId: Long): WaveformEntity?

    @Insert(onConflict = androidx.room.OnConflictStrategy.REPLACE)
    suspend fun save(waveform: WaveformEntity)
}

private const val TRACK_SELECT =
    "SELECT t.*, a.name AS artist_name FROM tracks t LEFT JOIN artists a ON t.artist_id = a.id "

/** Lists for the library screens. */
@Dao
interface BrowseDao {
    @Query("SELECT COUNT(*) FROM tracks WHERE is_missing = 0")
    fun observeTrackCount(): Flow<Int>

    @Query("SELECT COUNT(*) FROM playlists")
    fun observePlaylistCount(): Flow<Int>

    @Query(
        "SELECT al.id AS id, al.title AS title, ar.name AS artist_name, COUNT(t.id) AS track_count " +
            "FROM albums al LEFT JOIN artists ar ON al.artist_id = ar.id " +
            "JOIN tracks t ON t.album_id = al.id AND t.is_missing = 0 " +
            "WHERE al.title LIKE '%' || :q || '%' GROUP BY al.id ORDER BY al.title COLLATE NOCASE LIMIT 100"
    )
    fun searchAlbums(q: String): Flow<List<AlbumRow>>

    @Query(
        "SELECT ar.id AS id, ar.name AS name, COUNT(t.id) AS track_count " +
            "FROM artists ar JOIN tracks t ON t.artist_id = ar.id AND t.is_missing = 0 " +
            "WHERE ar.name LIKE '%' || :q || '%' GROUP BY ar.id ORDER BY ar.name COLLATE NOCASE LIMIT 100"
    )
    fun searchArtists(q: String): Flow<List<ArtistRow>>

    @Query(
        "SELECT album_artist AS name, COUNT(*) AS track_count FROM tracks " +
            "WHERE is_missing = 0 AND album_artist LIKE '%' || :q || '%' GROUP BY album_artist ORDER BY album_artist COLLATE NOCASE LIMIT 100"
    )
    fun searchAlbumArtists(q: String): Flow<List<NameCountRow>>

    @Query(
        "SELECT genre AS name, COUNT(*) AS track_count FROM tracks " +
            "WHERE is_missing = 0 AND genre LIKE '%' || :q || '%' GROUP BY genre ORDER BY genre COLLATE NOCASE LIMIT 100"
    )
    fun searchGenres(q: String): Flow<List<NameCountRow>>

    @Query(
        "SELECT f.path AS path, f.name AS name, COUNT(t.id) AS track_count " +
            "FROM folders f JOIN tracks t ON t.folder_id = f.id AND t.is_missing = 0 " +
            "WHERE f.name LIKE '%' || :q || '%' GROUP BY f.id ORDER BY f.name COLLATE NOCASE LIMIT 100"
    )
    fun searchFolders(q: String): Flow<List<FolderRow>>

    @Query(TRACK_SELECT + "WHERE t.is_missing = 0 ORDER BY t.title COLLATE NOCASE")
    fun observeAll(): Flow<List<TrackWithArtist>>

    @Query(TRACK_SELECT + "WHERE t.is_missing = 0 AND t.rating = :rating ORDER BY t.title COLLATE NOCASE")
    fun observeByRating(rating: Int): Flow<List<TrackWithArtist>>

    @Query(TRACK_SELECT + "WHERE t.is_missing = 0 ORDER BY t.date_added_ms DESC, t.title COLLATE NOCASE LIMIT 300")
    fun observeRecentlyAdded(): Flow<List<TrackWithArtist>>

    @Query(TRACK_SELECT + "WHERE t.is_missing = 0 AND t.duration_ms >= :minMs ORDER BY t.duration_ms DESC")
    fun observeLong(minMs: Long): Flow<List<TrackWithArtist>>

    @Query(TRACK_SELECT + "WHERE t.is_missing = 0 AND t.album_id = :albumId ORDER BY t.disc_no, t.track_no, t.title COLLATE NOCASE")
    fun observeAlbum(albumId: Long): Flow<List<TrackWithArtist>>

    @Query(TRACK_SELECT + "WHERE t.is_missing = 0 AND t.artist_id = :artistId ORDER BY t.title COLLATE NOCASE")
    fun observeArtist(artistId: Long): Flow<List<TrackWithArtist>>

    @Query(
        "SELECT t.*, a.name AS artist_name FROM tracks t JOIN folders f ON t.folder_id = f.id " +
            "LEFT JOIN artists a ON t.artist_id = a.id WHERE t.is_missing = 0 AND f.path = :path ORDER BY t.title COLLATE NOCASE"
    )
    fun observeFolderTracks(path: String): Flow<List<TrackWithArtist>>

    @Query(TRACK_SELECT + "WHERE t.is_missing = 0 AND t.year = :year ORDER BY t.title COLLATE NOCASE")
    fun observeYear(year: Int): Flow<List<TrackWithArtist>>

    @Query(
        "SELECT al.id AS id, al.title AS title, ar.name AS artist_name, COUNT(t.id) AS track_count " +
            "FROM albums al LEFT JOIN artists ar ON al.artist_id = ar.id " +
            "JOIN tracks t ON t.album_id = al.id AND t.is_missing = 0 " +
            "GROUP BY al.id ORDER BY al.title COLLATE NOCASE"
    )
    fun observeAlbums(): Flow<List<AlbumRow>>

    @Query(
        "SELECT ar.id AS id, ar.name AS name, COUNT(t.id) AS track_count " +
            "FROM artists ar JOIN tracks t ON t.artist_id = ar.id AND t.is_missing = 0 " +
            "GROUP BY ar.id ORDER BY ar.name COLLATE NOCASE"
    )
    fun observeArtists(): Flow<List<ArtistRow>>

    @Query(TRACK_SELECT + "WHERE t.is_missing = 0 AND t.play_count > 0 ORDER BY t.play_count DESC, t.last_played_ms DESC LIMIT 300")
    fun observeMostPlayed(): Flow<List<TrackWithArtist>>

    @Query(TRACK_SELECT + "WHERE t.is_missing = 0 AND t.last_played_ms > 0 ORDER BY t.last_played_ms DESC LIMIT 300")
    fun observeRecentlyPlayed(): Flow<List<TrackWithArtist>>

    @Query(TRACK_SELECT + "WHERE t.is_missing = 0 AND t.genre = :name ORDER BY t.title COLLATE NOCASE")
    fun observeGenre(name: String): Flow<List<TrackWithArtist>>

    @Query(TRACK_SELECT + "WHERE t.is_missing = 0 AND t.composer = :name ORDER BY t.title COLLATE NOCASE")
    fun observeComposer(name: String): Flow<List<TrackWithArtist>>

    @Query(TRACK_SELECT + "WHERE t.is_missing = 0 AND t.album_artist = :name ORDER BY t.title COLLATE NOCASE")
    fun observeAlbumArtist(name: String): Flow<List<TrackWithArtist>>

    @Query(
        "SELECT genre AS name, COUNT(*) AS track_count FROM tracks " +
            "WHERE is_missing = 0 AND genre IS NOT NULL AND genre != '' GROUP BY genre ORDER BY genre COLLATE NOCASE"
    )
    fun observeGenres(): Flow<List<NameCountRow>>

    @Query(
        "SELECT composer AS name, COUNT(*) AS track_count FROM tracks " +
            "WHERE is_missing = 0 AND composer IS NOT NULL AND composer != '' GROUP BY composer ORDER BY composer COLLATE NOCASE"
    )
    fun observeComposers(): Flow<List<NameCountRow>>

    @Query(
        "SELECT album_artist AS name, COUNT(*) AS track_count FROM tracks " +
            "WHERE is_missing = 0 AND album_artist IS NOT NULL AND album_artist != '' GROUP BY album_artist ORDER BY album_artist COLLATE NOCASE"
    )
    fun observeAlbumArtists(): Flow<List<NameCountRow>>

    @Query(
        "SELECT t.year AS year, COUNT(*) AS track_count FROM tracks t " +
            "WHERE t.is_missing = 0 AND t.year IS NOT NULL GROUP BY t.year ORDER BY t.year DESC"
    )
    fun observeYears(): Flow<List<YearRow>>

    @Query(
        "SELECT f.path AS path, f.name AS name, COUNT(t.id) AS track_count " +
            "FROM folders f JOIN tracks t ON t.folder_id = f.id AND t.is_missing = 0 " +
            "GROUP BY f.id ORDER BY f.name COLLATE NOCASE"
    )
    fun observeFoldersWithMusic(): Flow<List<FolderRow>>
}

@Dao
interface QueueDao {
    @Query(
        "SELECT t.*, a.name AS artist_name FROM queue_items q JOIN tracks t ON q.track_id = t.id " +
            "LEFT JOIN artists a ON t.artist_id = a.id WHERE t.is_missing = 0 ORDER BY q.position"
    )
    fun observeTracks(): Flow<List<TrackWithArtist>>

    @Query("SELECT COUNT(*) FROM queue_items")
    fun observeCount(): Flow<Int>

    @Query("DELETE FROM queue_items")
    suspend fun deleteAll()

    @Insert
    suspend fun insertAll(items: List<QueueItemEntity>)
}

@Dao
interface PlaylistDao {
    @Query(
        "SELECT p.id AS id, p.name AS name, COUNT(t.id) AS track_count FROM playlists p " +
            "LEFT JOIN playlist_items pi ON pi.playlist_id = p.id " +
            "LEFT JOIN tracks t ON t.id = pi.track_id AND t.is_missing = 0 " +
            "GROUP BY p.id ORDER BY p.name COLLATE NOCASE"
    )
    fun observePlaylists(): Flow<List<PlaylistRow>>

    @Query(
        "SELECT t.*, a.name AS artist_name FROM playlist_items pi JOIN tracks t ON pi.track_id = t.id " +
            "LEFT JOIN artists a ON t.artist_id = a.id " +
            "WHERE pi.playlist_id = :playlistId AND t.is_missing = 0 ORDER BY pi.position"
    )
    fun observeTracks(playlistId: Long): Flow<List<TrackWithArtist>>

    @Query("SELECT COUNT(*) FROM playlists WHERE name = :name")
    suspend fun countByName(name: String): Int

    @Insert
    suspend fun insert(playlist: PlaylistEntity): Long

    @Query("UPDATE playlists SET name = :name, updated_at = :now WHERE id = :id")
    suspend fun rename(id: Long, name: String, now: Long)

    @Query("DELETE FROM playlists WHERE id = :id")
    suspend fun delete(id: Long)

    @Query("SELECT COALESCE(MAX(position) + 1, 0) FROM playlist_items WHERE playlist_id = :playlistId")
    suspend fun nextPosition(playlistId: Long): Int

    @Insert(onConflict = androidx.room.OnConflictStrategy.IGNORE)
    suspend fun insertItem(item: PlaylistItemEntity): Long

    @Query("DELETE FROM playlist_items WHERE playlist_id = :playlistId AND track_id = :trackId")
    suspend fun removeItem(playlistId: Long, trackId: Long)
}

@Dao
interface BookmarkDao {
    @Query(
        "SELECT t.*, a.name AS artist_name, b.id AS bookmark_id, b.position_ms AS position_ms " +
            "FROM bookmarks b JOIN tracks t ON b.track_id = t.id LEFT JOIN artists a ON t.artist_id = a.id " +
            "WHERE t.is_missing = 0 ORDER BY b.created_at DESC"
    )
    fun observeAll(): Flow<List<BookmarkWithTrack>>

    @Insert
    suspend fun insert(bookmark: BookmarkEntity): Long

    @Query("DELETE FROM bookmarks WHERE id = :id")
    suspend fun delete(id: Long)
}
