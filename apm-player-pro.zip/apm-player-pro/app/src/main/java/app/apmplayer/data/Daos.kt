package app.apmplayer.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface ArtistDao {
    @Query("SELECT * FROM artists WHERE name = :name LIMIT 1")
    suspend fun findByName(name: String): ArtistEntity?

    @Insert
    suspend fun insert(artist: ArtistEntity): Long
}

@Dao
interface AlbumDao {
    @Query("SELECT * FROM albums WHERE title = :title AND ((:artistId IS NULL AND artist_id IS NULL) OR artist_id = :artistId) LIMIT 1")
    suspend fun find(title: String, artistId: Long?): AlbumEntity?

    @Insert
    suspend fun insert(album: AlbumEntity): Long
}

@Dao
interface FolderDao {
    @Query("SELECT * FROM folders WHERE path = :path LIMIT 1")
    suspend fun findByPath(path: String): FolderEntity?

    @Insert
    suspend fun insert(folder: FolderEntity): Long

    @Query("SELECT * FROM folders WHERE parent_id IS NULL ORDER BY name COLLATE NOCASE")
    fun observeRoots(): Flow<List<FolderEntity>>

    @Query(
        "SELECT c.* FROM folders c JOIN folders p ON c.parent_id = p.id " +
            "WHERE p.path = :path ORDER BY c.name COLLATE NOCASE"
    )
    fun observeChildren(path: String): Flow<List<FolderEntity>>
}

@Dao
interface TrackDao {
    @Query("SELECT * FROM tracks WHERE media_store_id = :mediaStoreId LIMIT 1")
    suspend fun findByMediaStoreId(mediaStoreId: Long): TrackEntity?

    @Insert
    suspend fun insert(track: TrackEntity): Long

    @Update
    suspend fun update(track: TrackEntity)

    @Query("UPDATE tracks SET is_missing = 1 WHERE scan_generation < :generation")
    suspend fun markMissing(generation: Long)

    @Query(
        "SELECT t.*, a.name AS artist_name FROM tracks t " +
            "JOIN folders f ON t.folder_id = f.id " +
            "LEFT JOIN artists a ON t.artist_id = a.id " +
            "WHERE f.path = :path AND t.is_missing = 0 ORDER BY t.title COLLATE NOCASE"
    )
    fun observeInFolder(path: String): Flow<List<TrackWithArtist>>

    @Query(
        "SELECT t.*, a.name AS artist_name FROM tracks t " +
            "LEFT JOIN artists a ON t.artist_id = a.id " +
            "WHERE t.is_missing = 0 AND (t.title LIKE '%' || :query || '%' OR a.name LIKE '%' || :query || '%') " +
            "ORDER BY t.title COLLATE NOCASE LIMIT 300"
    )
    fun search(query: String): Flow<List<TrackWithArtist>>

    @Query(
        "SELECT t.*, a.name AS artist_name, al.title AS album_title, f.path AS folder_path FROM tracks t " +
            "JOIN folders f ON t.folder_id = f.id " +
            "LEFT JOIN artists a ON t.artist_id = a.id " +
            "LEFT JOIN albums al ON t.album_id = al.id WHERE t.id = :id LIMIT 1"
    )
    fun observeDetail(id: Long): Flow<TrackDetail?>

    @Query("UPDATE tracks SET rating = :rating WHERE id = :id")
    suspend fun setRating(id: Long, rating: Int)
}

@Dao
interface WaveformDao {
    @Query("SELECT * FROM waveforms WHERE track_id = :trackId LIMIT 1")
    suspend fun find(trackId: Long): WaveformEntity?

    @Insert(onConflict = androidx.room.OnConflictStrategy.REPLACE)
    suspend fun save(waveform: WaveformEntity)
}

@Dao
interface QueueDao {
    @Query("DELETE FROM queue_items")
    suspend fun deleteAll()

    @Insert
    suspend fun insertAll(items: List<QueueItemEntity>)
}
