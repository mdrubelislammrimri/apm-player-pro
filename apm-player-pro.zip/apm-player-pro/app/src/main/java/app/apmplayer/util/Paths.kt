package app.apmplayer.util

import java.util.Locale

const val STORAGE_ROOT_NAME = "Storage"

/** "Music/Rock/" -> "Music/Rock". Files directly in the storage root get one shared name. */
fun normalizeFolderPath(raw: String?): String {
    val p = raw.orEmpty().trim().trim('/')
    return p.ifEmpty { STORAGE_ROOT_NAME }
}

/** "Music/Rock" -> "Music". A top level folder has no parent. */
fun parentFolderPath(path: String): String? {
    val i = path.lastIndexOf('/')
    return if (i <= 0) null else path.substring(0, i)
}

fun folderDisplayName(path: String): String = path.substringAfterLast('/')

/** Android 8 and 9 give a full file path, newer versions a relative folder. This makes both look alike. */
fun relativeFolderFromFilePath(filePath: String, storageRoot: String): String {
    val parent = filePath.substringBeforeLast('/', "")
    return if (parent.startsWith(storageRoot)) parent.removePrefix(storageRoot) else parent
}

/** 1:49 or 1:02:03. Locale.ROOT keeps digits identical on every phone so labels line up. */
fun formatDuration(ms: Long): String {
    val total = ms.coerceAtLeast(0) / 1000
    val h = total / 3600
    val m = (total % 3600) / 60
    val s = total % 60
    return if (h > 0) String.format(Locale.ROOT, "%d:%02d:%02d", h, m, s)
    else String.format(Locale.ROOT, "%d:%02d", m, s)
}
