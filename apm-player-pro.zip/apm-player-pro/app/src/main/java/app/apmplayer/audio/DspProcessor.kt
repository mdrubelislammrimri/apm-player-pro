package app.apmplayer.audio

import androidx.media3.common.C
import androidx.media3.common.audio.AudioProcessor.AudioFormat
import androidx.media3.common.audio.BaseAudioProcessor
import java.nio.ByteBuffer
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.pow
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * The sound chain, run on every audio buffer before it reaches the speaker:
 * preamp -> 10 band equalizer -> bass/treble -> stereo expand -> balance -> mono -> limiter.
 * Works on 16 bit and float audio with 1 or 2 channels. Anything else passes through untouched.
 */
class DspProcessor : BaseAudioProcessor() {

    private var channels = 0
    private var sampleRate = 0
    private var floatInput = false
    private var applied: DspParams? = null

    private val bandCoef = Array(EQ_BANDS) { DoubleArray(5) }
    private val bandActive = BooleanArray(EQ_BANDS)
    private val bandZ = Array(2) { Array(EQ_BANDS) { DoubleArray(2) } }

    private val toneCoef = Array(2) { DoubleArray(5) } // 0 = bass shelf, 1 = treble shelf
    private val toneActive = BooleanArray(2)
    private val toneZ = Array(2) { Array(2) { DoubleArray(2) } }

    private var reverb: ReverbEngine? = null
    private var reverbOn = false
    private var dryGain = 1.0
    private var wetGain = 0.0

    private var eqOn = true
    private var preGain = 1.0
    private var gainL = 1.0
    private var gainR = 1.0
    private var sideGain = 1.0
    private var mono = false
    private var limiterOn = true
    private var limiterGain = 1.0
    private var releaseCoef = 0.0

    override fun onConfigure(inputAudioFormat: AudioFormat): AudioFormat {
        val supported = (inputAudioFormat.encoding == C.ENCODING_PCM_16BIT ||
            inputAudioFormat.encoding == C.ENCODING_PCM_FLOAT) &&
            (inputAudioFormat.channelCount == 1 || inputAudioFormat.channelCount == 2)
        if (!supported) return AudioFormat.NOT_SET // processor stays off, audio is not changed
        channels = inputAudioFormat.channelCount
        sampleRate = inputAudioFormat.sampleRate
        floatInput = inputAudioFormat.encoding == C.ENCODING_PCM_FLOAT
        AudioSpectrum.sampleRate = sampleRate
        reverb = ReverbEngine(sampleRate)
        releaseCoef = 1.0 - exp(-1.0 / (0.2 * sampleRate)) // 200 ms release
        limiterGain = 1.0
        for (c in 0 until 2) {
            for (b in 0 until EQ_BANDS) bandZ[c][b].fill(0.0)
            for (t in 0 until 2) toneZ[c][t].fill(0.0)
        }
        applied = null
        return inputAudioFormat
    }

    override fun queueInput(inputBuffer: ByteBuffer) {
        val bytesPerSample = if (floatInput) 4 else 2
        val frameBytes = channels * bytesPerSample
        val frames = inputBuffer.remaining() / frameBytes
        if (frames == 0) {
            inputBuffer.position(inputBuffer.limit())
            return
        }
        val params = SoundEngine.params
        if (params !== applied) applyParams(params)

        val out = replaceOutputBuffer(frames * frameBytes)
        val stereo = channels == 2
        for (i in 0 until frames) {
            var l = readSample(inputBuffer)
            var r = if (stereo) readSample(inputBuffer) else l

            if (eqOn) {
                l *= preGain
                r *= preGain
                for (b in 0 until EQ_BANDS) {
                    if (!bandActive[b]) continue
                    l = biquad(bandCoef[b], bandZ[0][b], l)
                    if (stereo) r = biquad(bandCoef[b], bandZ[1][b], r)
                }
                if (!stereo) r = l
            }
            for (t in 0 until 2) {
                if (!toneActive[t]) continue
                l = biquad(toneCoef[t], toneZ[0][t], l)
                if (stereo) r = biquad(toneCoef[t], toneZ[1][t], r)
            }
            if (!stereo) r = l

            if (stereo) {
                if (sideGain != 1.0) {
                    val mid = (l + r) * 0.5
                    val side = (l - r) * 0.5 * sideGain
                    l = mid + side
                    r = mid - side
                }
                l *= gainL
                r *= gainR
                if (mono) {
                    val m = (l + r) * 0.5
                    l = m
                    r = m
                }
            }

            if (reverbOn) {
                val rv = reverb
                if (rv != null) {
                    rv.process(l, r)
                    l = l * dryGain + rv.wetL * wetGain
                    r = r * dryGain + rv.wetR * wetGain
                }
            }

            if (limiterOn) {
                val peak = max(abs(l), abs(r))
                val target = if (peak > CEILING) CEILING / peak else 1.0
                limiterGain = if (target < limiterGain) target
                else limiterGain + (target - limiterGain) * releaseCoef
                l *= limiterGain
                r *= limiterGain
            }

            AudioSpectrum.push(((l + r) * 0.5).toFloat())
            writeSample(out, l)
            if (stereo) writeSample(out, r)
        }
        inputBuffer.position(inputBuffer.limit())
        out.flip()
    }

    private fun readSample(buf: ByteBuffer): Double =
        if (floatInput) buf.getFloat().toDouble() else buf.getShort() / 32768.0

    private fun writeSample(buf: ByteBuffer, v: Double) {
        if (floatInput) {
            buf.putFloat(v.toFloat())
        } else {
            buf.putShort((v * 32767.0).roundToInt().coerceIn(-32768, 32767).toShort())
        }
    }

    private fun biquad(c: DoubleArray, z: DoubleArray, x: Double): Double {
        val y = c[0] * x + z[0]
        z[0] = c[1] * x - c[3] * y + z[1]
        z[1] = c[2] * x - c[4] * y
        return y
    }

    private fun applyParams(p: DspParams) {
        applied = p
        eqOn = p.eqOn
        preGain = 10.0.pow(p.preampDb / 20.0)
        for (b in 0 until EQ_BANDS) {
            if (p.parametric) {
                val band = p.paramBands.getOrNull(b)
                bandActive[b] = band != null && abs(band.gainDb) >= 0.05f && band.freq < sampleRate * 0.45
                if (band != null && bandActive[b]) Biquads.forBand(band, sampleRate.toDouble(), bandCoef[b])
            } else {
                val db = p.bandsDb.getOrElse(b) { 0f }.toDouble()
                val f = EQ_FREQS[b].toDouble()
                bandActive[b] = abs(db) >= 0.05 && f < sampleRate * 0.45
                if (bandActive[b]) Biquads.peaking(f, db, 1.41, sampleRate.toDouble(), bandCoef[b])
            }
        }
        val bassDb = if (p.toneOn) p.bassPct / 100.0 * 12.0 else 0.0
        val trebleDb = if (p.toneOn) p.treblePct / 100.0 * 12.0 else 0.0
        toneActive[0] = abs(bassDb) >= 0.05
        toneActive[1] = abs(trebleDb) >= 0.05 && 6000.0 < sampleRate * 0.45
        if (toneActive[0]) Biquads.shelf(100.0, bassDb, sampleRate.toDouble(), low = true, out = toneCoef[0])
        if (toneActive[1]) Biquads.shelf(6000.0, trebleDb, sampleRate.toDouble(), low = false, out = toneCoef[1])

        sideGain = 1.0 + p.stereoExpandPct / 100.0
        val bal = p.balance.toDouble()
        gainL = 1.0 - max(0.0, bal)
        gainR = 1.0 - max(0.0, -bal)
        mono = p.mono
        limiterOn = p.limiterOn

        reverbOn = p.reverbOn
        reverb?.configure(p.reverb)
        dryGain = 1.0 - p.reverb.mix * 0.5
        wetGain = p.reverb.mix * 1.4
    }

    private companion object {
        const val CEILING = 0.98
    }
}
