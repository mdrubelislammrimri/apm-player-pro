package app.apmplayer.audio

import android.content.Context
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.net.Uri
import app.apmplayer.data.ApmDatabase
import app.apmplayer.data.WaveformEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import java.nio.ByteOrder
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.sqrt

/** Gives the seek bar its waveform: from the cache, or decoded once and then cached. */
class WaveformProvider(private val context: Context, private val db: ApmDatabase) {

    suspend fun get(trackId: Long, uri: String, durationMs: Long): ByteArray? {
        db.waveformDao().find(trackId)?.takeIf { it.version == VERSION }?.let { return it.peaks }
        val peaks = try {
            decode(Uri.parse(uri), durationMs)
        } catch (e: kotlinx.coroutines.CancellationException) {
            throw e
        } catch (e: Exception) {
            null
        } ?: return null
        try {
            db.waveformDao().save(WaveformEntity(trackId, POINTS, peaks, VERSION, System.currentTimeMillis()))
        } catch (e: Exception) {
            // the track may have been removed while decoding, the picture is still fine to show
        }
        return peaks
    }

    /** Decodes the file to sound and keeps the loudest value of each small slice of time. */
    private suspend fun decode(uri: Uri, durationMs: Long): ByteArray? = withContext(Dispatchers.Default) {
        val extractor = MediaExtractor()
        var codec: MediaCodec? = null
        try {
            extractor.setDataSource(context, uri, null)
            var index = -1
            for (i in 0 until extractor.trackCount) {
                if (extractor.getTrackFormat(i).getString(MediaFormat.KEY_MIME)?.startsWith("audio/") == true) {
                    index = i
                    break
                }
            }
            if (index < 0) return@withContext null
            extractor.selectTrack(index)
            val format = extractor.getTrackFormat(index)
            val mime = format.getString(MediaFormat.KEY_MIME) ?: return@withContext null
            val totalUs = when {
                format.containsKey(MediaFormat.KEY_DURATION) -> format.getLong(MediaFormat.KEY_DURATION)
                durationMs > 0 -> durationMs * 1000
                else -> return@withContext null
            }.coerceAtLeast(1L)

            codec = MediaCodec.createDecoderByType(mime)
            codec.configure(format, null, null, 0)
            codec.start()

            val peaks = DoubleArray(POINTS)
            val info = MediaCodec.BufferInfo()
            var inputDone = false
            var outputDone = false
            while (!outputDone) {
                currentCoroutineContext().ensureActive()
                if (!inputDone) {
                    val inIndex = codec.dequeueInputBuffer(10_000)
                    if (inIndex >= 0) {
                        val buffer = codec.getInputBuffer(inIndex)!!
                        val size = extractor.readSampleData(buffer, 0)
                        if (size < 0) {
                            codec.queueInputBuffer(inIndex, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inputDone = true
                        } else {
                            codec.queueInputBuffer(inIndex, 0, size, extractor.sampleTime, 0)
                            extractor.advance()
                        }
                    }
                }
                val outIndex = codec.dequeueOutputBuffer(info, 10_000)
                if (outIndex >= 0) {
                    if (info.size > 0) {
                        val out = codec.getOutputBuffer(outIndex)!!
                        out.position(info.offset)
                        out.limit(info.offset + info.size)
                        val shorts = out.order(ByteOrder.nativeOrder()).asShortBuffer()
                        val bucket = ((info.presentationTimeUs.toDouble() / totalUs) * POINTS).toInt().coerceIn(0, POINTS - 1)
                        var peak = 0
                        while (shorts.hasRemaining()) peak = max(peak, abs(shorts.get().toInt()))
                        peaks[bucket] = max(peaks[bucket], peak / 32768.0)
                    }
                    codec.releaseOutputBuffer(outIndex, false)
                    if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) outputDone = true
                }
            }
            // square root keeps quiet parts visible, then scale so the loudest slice fills the height
            val loudest = peaks.max().coerceAtLeast(1e-6)
            ByteArray(POINTS) { i -> (sqrt(peaks[i] / loudest) * 255.0).toInt().coerceIn(0, 255).toByte() }
        } finally {
            try { codec?.stop() } catch (e: Exception) { }
            codec?.release()
            extractor.release()
        }
    }

    companion object {
        const val POINTS = 200
        const val VERSION = 1
    }
}
