package app.apmplayer.lyrics

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import app.apmplayer.settings.Settings

/** Apps that can be chosen to look lyrics up, when installed. The browser is always there. */
val LyricsApps = listOf(
    "Genius" to "com.genius.android",
    "Musixmatch" to "com.musixmatch.android.lyrify",
    "Google" to "com.google.android.googlequicksearchbox",
)

const val DEFAULT_LYRICS_URL = "https://www.google.com/search?q=lyrics %ARTIST% %TITLE%"

/** The text encodings that can be picked for old files that are not Unicode. */
val LyricsCharsets = listOf("Windows-1252", "ISO-8859-1", "Windows-1251", "GBK", "Shift_JIS", "EUC-KR", "Windows-1256")

fun lyricsCharset(index: Int): java.nio.charset.Charset =
    try {
        java.nio.charset.Charset.forName(LyricsCharsets.getOrElse(index) { "Windows-1252" })
    } catch (e: Exception) {
        Charsets.ISO_8859_1
    }

/** Opens a web search for the lyrics, in the chosen app if it is installed, else in the browser. */
fun openLyricsSearch(context: Context, settings: Settings, artist: String?, title: String) {
    val template = settings.lyricsUrl.trim().ifEmpty { DEFAULT_LYRICS_URL }.replace(" ", "+")
    val url = template.replace("%ARTIST%", Uri.encode(artist.orEmpty())).replace("%TITLE%", Uri.encode(title))
        .let { if (it.startsWith("http")) it else "https://$it" }
    val view = Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    if (settings.lyricsApp.isNotBlank()) {
        try {
            context.startActivity(Intent(view).setPackage(settings.lyricsApp))
            return
        } catch (e: Exception) {
            // the app is not there or cannot open it, use the browser
        }
    }
    try {
        context.startActivity(view)
    } catch (e: Exception) {
        Toast.makeText(context, "No browser found", Toast.LENGTH_SHORT).show()
    }
}
