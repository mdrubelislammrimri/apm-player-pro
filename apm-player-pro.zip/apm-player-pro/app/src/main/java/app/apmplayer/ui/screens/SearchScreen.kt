package app.apmplayer.ui.screens

import app.apmplayer.ui.theme.n
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.flowOf
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Shuffle
import androidx.compose.material3.Icon
import app.apmplayer.ui.components.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import app.apmplayer.AppContainer
import app.apmplayer.ui.components.OutlinePill
import app.apmplayer.ui.components.focusRing
import app.apmplayer.ui.theme.Apm
import app.apmplayer.ui.theme.ApmShape
import app.apmplayer.ui.theme.ApmSpace

private val chipNames = listOf("All", "Albums", "Artists", "Album Artists", "Folders", "Genres")

/** S09. Search box, filter chips and results. All finds songs, the other chips find albums, artists, folders and genres. */
@Composable
fun SearchScreen(container: AppContainer, onOpenNowPlaying: () -> Unit, onNavigate: (String) -> Unit) {
    var query by rememberSaveable { mutableStateOf("") }
    var chip by rememberSaveable { mutableStateOf(0) }
    val colors = Apm.colors
    val results by remember(query) { container.repository.search(query) }
        .collectAsStateWithLifecycle(initialValue = emptyList())

    // for the other chips the search looks in names of albums, artists and so on
    val groupFlow = remember(query, chip) {
        val q = query.trim()
        val browse = container.repository.browse
        if (q.isEmpty() || chip == 0) {
            flowOf(emptyList())
        } else when (chip) {
            1 -> browse.searchAlbums(q).map { rows ->
                rows.map { GroupItem("songs/album-${it.id}?title=" + Uri.encode(it.title), it.title, listOfNotNull(it.artistName, "${it.trackCount} songs").joinToString(" · "), it.id) }
            }
            2 -> browse.searchArtists(q).map { rows ->
                rows.map { GroupItem("songs/artist-${it.id}?title=" + Uri.encode(it.name), it.name, "${it.trackCount} songs", it.id) }
            }
            3 -> browse.searchAlbumArtists(q).map { rows ->
                rows.map { GroupItem("songs/albumartist?title=" + Uri.encode(it.name) + "&arg=" + Uri.encode(it.name), it.name, "${it.trackCount} songs", it.name.hashCode().toLong()) }
            }
            4 -> browse.searchFolders(q).map { rows ->
                rows.map { GroupItem("folders?path=" + Uri.encode(it.path), it.name, "${it.trackCount} songs", it.path.hashCode().toLong()) }
            }
            else -> browse.searchGenres(q).map { rows ->
                rows.map { GroupItem("songs/genre?title=" + Uri.encode(it.name) + "&arg=" + Uri.encode(it.name), it.name, "${it.trackCount} songs", it.name.hashCode().toLong()) }
            }
        }
    }
    val groups by groupFlow.collectAsStateWithLifecycle(initialValue = emptyList())

    Column(Modifier.fillMaxSize().padding(horizontal = ApmSpace.s2, vertical = ApmSpace.s2)) {
        Row(
            Modifier.fillMaxWidth().height(60.dp).clip(ApmShape.pill).background(n(Color(0xFF333333)))
                .padding(horizontal = ApmSpace.s4),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(ApmSpace.s3),
        ) {
            Icon(Icons.Rounded.Search, contentDescription = null, tint = n(Color.White), modifier = Modifier.size(28.dp))
            Box(Modifier.weight(1f)) {
                if (query.isEmpty()) {
                    Text("Search", style = Apm.type.title.copy(fontWeight = FontWeight.SemiBold), color = n(Color(0xFF9A9A9A)))
                }
                BasicTextField(
                    value = query, onValueChange = { query = it }, singleLine = true,
                    textStyle = Apm.type.title.copy(color = n(Color.White), fontWeight = FontWeight.SemiBold),
                    cursorBrush = SolidColor(Color.White), modifier = Modifier.fillMaxWidth(),
                )
            }
            if (query.isNotEmpty()) {
                Box(
                    Modifier.size(48.dp).clip(ApmShape.round).focusRing(ApmShape.round)
                        .clickable(role = Role.Button) { query = "" },
                    contentAlignment = Alignment.Center,
                ) { Icon(Icons.Rounded.Close, contentDescription = "Clear", tint = n(Color.White)) }
            }
        }

        Row(
            Modifier.fillMaxWidth().padding(top = ApmSpace.s3).horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(ApmSpace.s2),
        ) {
            chipNames.forEachIndexed { i, name ->
                Box(
                    Modifier.height(48.dp).clip(ApmShape.pill)
                        .background(if (i == chip) n(Color(0xFF3A3A3A)) else n(Color(0xFF222222)))
                        .focusRing(ApmShape.pill).clickable(role = Role.Tab) { chip = i }
                        .padding(horizontal = ApmSpace.s4),
                    contentAlignment = Alignment.Center,
                ) { Text(name, style = Apm.type.body.copy(fontWeight = FontWeight.Bold), color = n(Color.White)) }
            }
        }

        Row(
            Modifier.fillMaxWidth().padding(top = ApmSpace.s2),
            horizontalArrangement = Arrangement.spacedBy(ApmSpace.s2),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            IconPill(Icons.Rounded.Shuffle, "Shuffle results", results.isNotEmpty()) {
                container.play(results, 0, shuffle = true); onOpenNowPlaying()
            }
            IconPill(Icons.Rounded.PlayArrow, "Play results", results.isNotEmpty()) {
                container.play(results, 0, shuffle = false); onOpenNowPlaying()
            }
            OutlinePill("Select", {}, enabled = false)
            Box(Modifier.weight(1f))
            Box(
                Modifier.size(48.dp).clip(ApmShape.round).border(1.5.dp, n(Color(0xFF8A8A8A)), ApmShape.round),
                contentAlignment = Alignment.Center,
            ) { Icon(Icons.Rounded.MoreVert, contentDescription = "More", tint = n(Color.White)) }
        }

        when {
            query.isBlank() -> Message("Type a name to search.")
            chip != 0 && groups.isEmpty() -> Message("Nothing found in ${chipNames[chip].lowercase()}.")
            chip != 0 -> LazyColumn(Modifier.fillMaxSize().padding(top = ApmSpace.s2)) {
                // the route to open is kept in the item's key
                itemsIndexed(groups, key = { _, g -> g.key }) { _, g -> GroupRow(g) { onNavigate(it.key) } }
            }
            results.isEmpty() -> Message("Nothing found.")
            else -> LazyColumn(Modifier.fillMaxSize().padding(top = ApmSpace.s2)) {
                itemsIndexed(results, key = { _, t -> t.track.id }) { index, item ->
                    TrackRow(item) { container.play(results, index, shuffle = false); onOpenNowPlaying() }
                }
            }
        }
    }
}

@Composable
private fun IconPill(icon: androidx.compose.ui.graphics.vector.ImageVector, description: String, enabled: Boolean, onClick: () -> Unit) {
    Box(
        Modifier.height(48.dp).width(68.dp).clip(ApmShape.pill)
            .border(1.5.dp, if (enabled) n(Color(0xFF8A8A8A)) else n(Color(0xFF444444)), ApmShape.pill)
            .focusRing(ApmShape.pill).clickable(enabled = enabled, role = Role.Button, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) { Icon(icon, contentDescription = description, tint = if (enabled) n(Color.White) else n(Color(0xFF666666))) }
}

@Composable
private fun Message(text: String) {
    Box(Modifier.fillMaxWidth().padding(ApmSpace.s5)) {
        Text(text, style = Apm.type.bodySm, color = Apm.colors.textMuted)
    }
}
