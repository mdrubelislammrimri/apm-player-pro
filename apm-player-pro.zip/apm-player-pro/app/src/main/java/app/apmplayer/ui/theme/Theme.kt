package app.apmplayer.ui.theme

import app.apmplayer.settings.Settings
import androidx.compose.ui.platform.LocalContext
import androidx.compose.runtime.setValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.SideEffect
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.ReadOnlyComposable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color

val LocalApmType = staticCompositionLocalOf { ApmTypography() }

/** A colour skin: the accent colour of buttons, switches and highlights, and the text colour that sits on it. */
data class Skin(val name: String, val accent: Color, val onAccent: Color)

val ApmSkins = listOf(
    Skin("Teal", Color(0xFF4FD1C5), Color(0xFF04211E)),
    Skin("Blue", Color(0xFF5AA9FF), Color(0xFF031A33)),
    Skin("Green", Color(0xFF5BD17A), Color(0xFF05260F)),
    Skin("Orange", Color(0xFFFFA24D), Color(0xFF331A00)),
    Skin("Pink", Color(0xFFFF7AB6), Color(0xFF33081F)),
    Skin("Purple", Color(0xFFB58CFF), Color(0xFF1A0A38)),
    Skin("Red", Color(0xFFFF6B6B), Color(0xFF330909)),
    Skin("Gold", Color(0xFFF2C94C), Color(0xFF2E2400)),
)

/** True while the light theme is on. Fixed greys in the screens go through [n], which flips them. */
object ThemeMode {
    var light by mutableStateOf(false)
}

/** A fixed grey, white or black from the dark design, turned over for the light theme. */
fun n(c: Color): Color = if (!ThemeMode.light) c else Color(1f - c.red, 1f - c.green, 1f - c.blue, c.alpha)

/**
 * Wrap the app in this. The theme (dark, light, follow the phone), the skin colour, the Material You colour
 * and the rounding of corners come from the settings.
 */
@Composable
fun ApmTheme(settings: Settings, content: @Composable () -> Unit) {
    val systemDark = isSystemInDarkTheme()
    val dark = when (settings.themeMode) {
        1 -> false
        3 -> systemDark
        else -> true
    }
    val context = LocalContext.current
    val skins = allSkins(settings)
    val picked = skins[settings.skin.coerceIn(0, skins.lastIndex)]
    var accent = picked.accent
    var onAccent = picked.onAccent
    if (settings.materialYou > 0 && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
        // the colours of the phone's wallpaper
        val dyn = if (dark) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        if (settings.materialYou == 1) { accent = dyn.primary; onAccent = dyn.onPrimary } else { accent = dyn.secondary; onAccent = dyn.onSecondary }
    } else if (!dark) {
        accent = darkened(accent)
        onAccent = readableOn(accent)
    }
    val base = if (dark) DarkApmColors else LightApmColors
    val c = base.copy(accent = accent, onAccent = onAccent, focusRing = accent)
    SideEffect {
        ThemeMode.light = !dark
        ApmShape.roundness = if (settings.lessRounded) 0.35f else 1f
    }
    // Material components (slider, switch, dialogs) read this scheme, built from the same colours.
    val scheme = if (dark) {
        darkColorScheme(
            primary = c.accent, onPrimary = c.onAccent, background = c.bg, onBackground = c.text,
            surface = c.surface, onSurface = c.text, surfaceVariant = c.surfaceRaised,
            onSurfaceVariant = c.textMuted, outline = c.borderInput, outlineVariant = c.border, error = c.danger,
        )
    } else {
        lightColorScheme(
            primary = c.accent, onPrimary = c.onAccent, background = c.bg, onBackground = c.text,
            surface = c.surface, onSurface = c.text, surfaceVariant = c.surfaceRaised,
            onSurfaceVariant = c.textMuted, outline = c.borderInput, outlineVariant = c.border, error = c.danger,
        )
    }
    CompositionLocalProvider(
        LocalApmColors provides c,
        LocalApmType provides ApmTypography(),
    ) {
        MaterialTheme(colorScheme = scheme, content = content)
    }
}

object Apm {
    val colors: ApmColors @Composable @ReadOnlyComposable get() = LocalApmColors.current
    val type: ApmTypography @Composable @ReadOnlyComposable get() = LocalApmType.current
}
// Rule for every component: colours come from Apm.colors, text from Apm.type, sizes from ApmSpace / ApmShape / ApmLayout.
