package app.apmplayer.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.ReadOnlyComposable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color

val LocalApmType = staticCompositionLocalOf { ApmTypography() }

/** A colour skin: the accent colour of buttons, switches and highlights, and the text colour that sits on it. */
data class Skin(val name: String, val accent: Color, val onAccent: Color)

val ApmSkins = listOf(
    Skin("Teal", Color(0xFF4FD1C5), Color(0xFF04211E)),
    Skin("Blue", Color(0xFF5AA9FF), Color(0xFF031A33)),
    Skin("Green", Color(0xFF5BD17A), Color(0xFF05260F)),
    Skin("Orange", Color(0xFFFFA24D), Color(0xFF331A00)),
    Skin("Pink", Color(0xFFFF7AB6), Color(0xFF33081F)),
    Skin("Purple", Color(0xFFB58CFF), Color(0xFF1A0A38)),
    Skin("Red", Color(0xFFFF6B6B), Color(0xFF330909)),
    Skin("Gold", Color(0xFFF2C94C), Color(0xFF2E2400)),
)

/** Wrap the app in this. Follows the system dark/light setting for now. [skin] is an index into [ApmSkins]. */
@Composable
fun ApmTheme(dark: Boolean = isSystemInDarkTheme(), skin: Int = 0, content: @Composable () -> Unit) {
    val picked = ApmSkins[skin.coerceIn(0, ApmSkins.lastIndex)]
    val base = if (dark) DarkApmColors else LightApmColors
    val c = base.copy(accent = picked.accent, onAccent = picked.onAccent, focusRing = picked.accent)
    // Material components (slider, ...) read this scheme, built from the same tokens.
    val scheme = if (dark) {
        darkColorScheme(
            primary = c.accent, onPrimary = c.onAccent, background = c.bg, onBackground = c.text,
            surface = c.surface, onSurface = c.text, surfaceVariant = c.surfaceRaised,
            onSurfaceVariant = c.textMuted, outline = c.borderInput, outlineVariant = c.border, error = c.danger,
        )
    } else {
        lightColorScheme(
            primary = c.accent, onPrimary = c.onAccent, background = c.bg, onBackground = c.text,
            surface = c.surface, onSurface = c.text, surfaceVariant = c.surfaceRaised,
            onSurfaceVariant = c.textMuted, outline = c.borderInput, outlineVariant = c.border, error = c.danger,
        )
    }
    CompositionLocalProvider(
        LocalApmColors provides c,
        LocalApmType provides ApmTypography(),
    ) {
        MaterialTheme(colorScheme = scheme, content = content)
    }
}

object Apm {
    val colors: ApmColors @Composable @ReadOnlyComposable get() = LocalApmColors.current
    val type: ApmTypography @Composable @ReadOnlyComposable get() = LocalApmType.current
}
// Rule for every component: colours come from Apm.colors, text from Apm.type, sizes from ApmSpace / ApmShape / ApmLayout.
