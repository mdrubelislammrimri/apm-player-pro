package app.apmplayer.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.ReadOnlyComposable
import androidx.compose.runtime.staticCompositionLocalOf

val LocalApmType = staticCompositionLocalOf { ApmTypography() }

/** Wrap the app in this. Follows the system dark/light setting for now. A user choice comes with settings. */
@Composable
fun ApmTheme(dark: Boolean = isSystemInDarkTheme(), content: @Composable () -> Unit) {
    val c = if (dark) DarkApmColors else LightApmColors
    // Material components (slider, ...) read this scheme, built from the same tokens.
    val scheme = if (dark) {
        darkColorScheme(
            primary = c.accent, onPrimary = c.onAccent, background = c.bg, onBackground = c.text,
            surface = c.surface, onSurface = c.text, surfaceVariant = c.surfaceRaised,
            onSurfaceVariant = c.textMuted, outline = c.borderInput, outlineVariant = c.border, error = c.danger,
        )
    } else {
        lightColorScheme(
            primary = c.accent, onPrimary = c.onAccent, background = c.bg, onBackground = c.text,
            surface = c.surface, onSurface = c.text, surfaceVariant = c.surfaceRaised,
            onSurfaceVariant = c.textMuted, outline = c.borderInput, outlineVariant = c.border, error = c.danger,
        )
    }
    CompositionLocalProvider(
        LocalApmColors provides c,
        LocalApmType provides ApmTypography(),
    ) {
        MaterialTheme(colorScheme = scheme, content = content)
    }
}

object Apm {
    val colors: ApmColors @Composable @ReadOnlyComposable get() = LocalApmColors.current
    val type: ApmTypography @Composable @ReadOnlyComposable get() = LocalApmType.current
}
// Rule for every component: colours come from Apm.colors, text from Apm.type, sizes from ApmSpace / ApmShape / ApmLayout.
