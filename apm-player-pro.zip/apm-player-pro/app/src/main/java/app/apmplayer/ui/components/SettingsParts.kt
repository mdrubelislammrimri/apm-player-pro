package app.apmplayer.ui.components

import kotlin.math.sin
import kotlin.math.cos
import app.apmplayer.ui.components.focusRing
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.geometry.Offset
import androidx.compose.runtime.setValue
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.remember
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.getValue
import androidx.compose.material3.TextButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.AlertDialog
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.ExperimentalLayoutApi
import androidx.compose.ui.draw.alpha
import app.apmplayer.ui.theme.n
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.selection.toggleable
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import app.apmplayer.ui.components.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import app.apmplayer.ui.theme.Apm
import app.apmplayer.ui.theme.ApmShape
import app.apmplayer.ui.theme.ApmSpace

/** Small pieces the settings pages are built from. Same look as the original: cyan headings, switches, step sliders. */

@Composable
fun SettingSection(title: String) {
    Text(
        title, style = Apm.type.bodySm.copy(fontWeight = FontWeight.Bold), color = Apm.colors.accent,
        modifier = Modifier.padding(start = ApmSpace.s4, end = ApmSpace.s4, top = ApmSpace.s4, bottom = ApmSpace.s1),
    )
}

/** An information note: a light bar on the left and the text next to it. A blank line starts a new paragraph. */
@Composable
fun SettingNote(text: String, onClick: (() -> Unit)? = null) {
    Row(
        Modifier
            .fillMaxWidth()
            .then(if (onClick != null) Modifier.clickable(role = Role.Button, onClick = onClick) else Modifier)
            .padding(horizontal = ApmSpace.s4, vertical = ApmSpace.s3)
            .height(IntrinsicSize.Min),
        horizontalArrangement = Arrangement.spacedBy(ApmSpace.s4),
    ) {
        Box(Modifier.width(5.dp).fillMaxHeight().clip(ApmShape.pill).background(n(Color(0xFFB9C3BE))))
        Column(verticalArrangement = Arrangement.spacedBy(ApmSpace.s3)) {
            text.split("\n\n").forEach { Text(it, style = Apm.type.bodySm, color = n(Color(0xFFD0D0D0))) }
        }
    }
}

/** A small plain line of text under a setting, like "Some firmwares may not support this option". */
@Composable
fun SettingHint(text: String) {
    Text(
        text, style = Apm.type.caption, color = n(Color(0xFF9A9A9A)),
        modifier = Modifier.fillMaxWidth().padding(horizontal = ApmSpace.s4, vertical = ApmSpace.s2),
    )
}

@Composable
fun SettingSwitch(title: String, subtitle: String?, checked: Boolean, enabled: Boolean = true, onChange: (Boolean) -> Unit) {
    val colors = Apm.colors
    Row(
        Modifier
            .fillMaxWidth()
            .alpha(if (enabled) 1f else 0.4f)
            .heightIn(min = 64.dp)
            .focusRing(ApmShape.md)
            .toggleable(value = checked, enabled = enabled, role = Role.Switch, onValueChange = onChange)
            .padding(horizontal = ApmSpace.s4, vertical = ApmSpace.s2),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(ApmSpace.s3),
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, style = Apm.type.body.copy(fontWeight = FontWeight.Medium), color = colors.text)
            if (subtitle != null) Text(subtitle, style = Apm.type.caption, color = n(Color(0xFF9A9A9A)))
        }
        Switch(
            checked = checked, onCheckedChange = null,
            colors = SwitchDefaults.colors(
                checkedThumbColor = colors.accent, checkedTrackColor = colors.accent.copy(alpha = 0.35f),
                uncheckedThumbColor = n(Color(0xFF9A9A9A)), uncheckedTrackColor = n(Color(0xFF3A3A3A)),
                uncheckedBorderColor = n(Color(0xFF3A3A3A)),
            ),
        )
    }
}

/**
 * A title, a line under it, the value, and a thin slider with a round thumb, like the original.
 * [endLabels] are small words under the value, spread along the slider (like None, Normal, More).
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingSlider(
    title: String,
    subtitle: String?,
    valueText: String,
    value: Float,
    range: ClosedFloatingPointRange<Float>,
    onChange: (Float) -> Unit,
    steps: Int = 0,
    endLabels: List<String>? = null,
    enabled: Boolean = true,
) {
    val accent = Apm.colors.accent
    Column(Modifier.fillMaxWidth().alpha(if (enabled) 1f else 0.4f).padding(horizontal = ApmSpace.s4, vertical = ApmSpace.s3)) {
        Text(title, style = Apm.type.body.copy(fontWeight = FontWeight.Medium), color = Apm.colors.text)
        if (subtitle != null) Text(subtitle, style = Apm.type.caption, color = n(Color(0xFF9A9A9A)))
        Text(valueText, style = Apm.type.bodySm, color = Apm.colors.text, modifier = Modifier.padding(top = ApmSpace.s1))
        if (endLabels != null) {
            Row(Modifier.fillMaxWidth().padding(horizontal = ApmSpace.s2), horizontalArrangement = Arrangement.SpaceBetween) {
                endLabels.forEach { Text(it, style = Apm.type.caption, color = n(Color(0xFFB0B0B0))) }
            }
        }
        Slider(
            value = value.coerceIn(range.start, range.endInclusive), onValueChange = onChange, valueRange = range, steps = steps, enabled = enabled,
            thumb = { Box(Modifier.size(16.dp).clip(ApmShape.round).background(accent)) },
            track = { state ->
                val off = n(Color(0xFF3A3A3A))
                Canvas(Modifier.fillMaxWidth().height(28.dp)) {
                    val y = size.height / 2
                    val frac = ((state.value - range.start) / (range.endInclusive - range.start)).coerceIn(0f, 1f)
                    drawLine(off, Offset(0f, y), Offset(size.width, y), 4.dp.toPx(), StrokeCap.Round)
                    drawLine(accent, Offset(0f, y), Offset(size.width * frac, y), 4.dp.toPx(), StrokeCap.Round)
                    // small dots at every step, when there are not too many
                    if (steps in 1..20) {
                        for (i in 0..steps + 1) drawCircle(accent.copy(alpha = 0.75f), 2.dp.toPx(), Offset(size.width * i / (steps + 1), y))
                    }
                }
            },
        )
    }
}

/** A few round choices in a row, the chosen one filled. */
/** A title and a row of round choices. The choices wrap to the next line when they do not fit, like the original. */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SettingChoices(
    title: String,
    subtitle: String?,
    options: List<String>,
    selected: Int,
    enabled: Boolean = true,
    subtitle2: String? = null,
    onSelect: (Int) -> Unit,
) {
    val colors = Apm.colors
    Column(
        Modifier.fillMaxWidth().alpha(if (enabled) 1f else 0.4f).padding(horizontal = ApmSpace.s4, vertical = ApmSpace.s3),
        verticalArrangement = Arrangement.spacedBy(ApmSpace.s2),
    ) {
        Column {
            Text(title, style = Apm.type.body.copy(fontWeight = FontWeight.Medium), color = colors.text)
            if (subtitle != null) Text(subtitle, style = Apm.type.caption, color = n(Color(0xFF9A9A9A)))
            if (subtitle2 != null) Text(subtitle2, style = Apm.type.caption, color = n(Color(0xFF7A7A7A)))
        }
        FlowRow(horizontalArrangement = Arrangement.spacedBy(ApmSpace.s2), verticalArrangement = Arrangement.spacedBy(ApmSpace.s2)) {
            options.forEachIndexed { i, label ->
                val on = i == selected
                Box(
                    Modifier
                        .heightIn(min = 48.dp)
                        .clip(ApmShape.pill)
                        .background(if (on) colors.accent else Color.Transparent)
                        .border(1.5.dp, if (on) colors.accent else n(Color(0xFF8A8A8A)), ApmShape.pill)
                        .focusRing(ApmShape.pill)
                        .then(if (enabled) Modifier.clickable(role = Role.RadioButton) { onSelect(i) } else Modifier)
                        .padding(horizontal = ApmSpace.s4),
                    contentAlignment = Alignment.Center,
                ) {
                    Text(
                        label, style = Apm.type.body.copy(fontWeight = FontWeight.Medium),
                        color = if (on) colors.onAccent else colors.text,
                    )
                }
            }
        }
    }
}

@Composable
fun SettingAction(title: String, subtitle: String?, enabled: Boolean = true, onClick: () -> Unit) {
    Column(
        Modifier
            .fillMaxWidth()
            .alpha(if (enabled) 1f else 0.4f)
            .heightIn(min = 64.dp)
            .focusRing(ApmShape.md)
            .clickable(enabled = enabled, role = Role.Button, onClick = onClick)
            .padding(horizontal = ApmSpace.s4, vertical = ApmSpace.s2),
        verticalArrangement = Arrangement.Center,
    ) {
        Text(title, style = Apm.type.body.copy(fontWeight = FontWeight.Medium), color = Apm.colors.text)
        if (subtitle != null) Text(subtitle, style = Apm.type.caption, color = n(Color(0xFF9A9A9A)))
    }
}

/** A round radio mark, a title and a line under it. Used for skins and layouts. */
@Composable
fun SettingRadio(title: String, subtitle: String?, selected: Boolean, onClick: () -> Unit) {
    val colors = Apm.colors
    Row(
        Modifier
            .fillMaxWidth()
            .heightIn(min = 64.dp)
            .focusRing(ApmShape.md)
            .clickable(role = Role.RadioButton, onClick = onClick)
            .padding(horizontal = ApmSpace.s4, vertical = ApmSpace.s2),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(ApmSpace.s3),
    ) {
        androidx.compose.material3.RadioButton(
            selected = selected, onClick = null,
            colors = androidx.compose.material3.RadioButtonDefaults.colors(selectedColor = colors.accent, unselectedColor = n(Color(0xFF8A8A8A))),
        )
        Column(Modifier.weight(1f)) {
            Text(title, style = Apm.type.body.copy(fontWeight = FontWeight.Medium), color = colors.text)
            if (subtitle != null) Text(subtitle, style = Apm.type.caption, color = n(Color(0xFF9A9A9A)))
        }
    }
}

/** A title on the left and a knob with its value under it on the right. Long press the knob's value to go back to the start value. */
/**
 * A title on the left and a thin round knob on the right with its value under it, like the original.
 * Drag the knob up or down to change the value, double tap it to go back to the start value, press and hold the value to type one.
 */
@Composable
fun SettingKnobRow(
    title: String,
    subtitle: String?,
    value: Float,
    min: Float,
    max: Float,
    defaultValue: Float,
    valueText: String,
    enabled: Boolean = true,
    hint: String? = null,
    onChange: (Float) -> Unit,
) {
    var editing by remember { mutableStateOf(false) }
    val current by rememberUpdatedState(value)
    val accent = Apm.colors.accent
    val ring = n(Color(0xFFEDEDED))
    val tick = if (enabled) accent else n(Color(0xFF8A8A8A))
    Row(
        Modifier.fillMaxWidth().padding(horizontal = ApmSpace.s4, vertical = ApmSpace.s4),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f).padding(end = ApmSpace.s3)) {
            Text(title, style = Apm.type.body.copy(fontWeight = FontWeight.Medium), color = if (enabled) Apm.colors.text else n(Color(0xFF8A8A8A)))
            if (subtitle != null) Text(subtitle, style = Apm.type.caption, color = n(Color(0xFF9A9A9A)))
            if (hint != null) Text(hint, style = Apm.type.caption, color = n(Color(0xFF7A7A7A)), modifier = Modifier.padding(top = ApmSpace.s2))
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Canvas(
                Modifier
                    .size(88.dp)
                    .pointerInput(enabled) {
                        if (enabled) detectVerticalDragGestures { change, dy ->
                            change.consume()
                            onChange((current - dy / 400.dp.toPx() * (max - min)).coerceIn(min, max))
                        }
                    }
                    .pointerInput(enabled) {
                        if (enabled) detectTapGestures(onDoubleTap = { onChange(defaultValue) })
                    }
                    .semantics { contentDescription = "$title, $valueText" },
            ) {
                val r = size.minDimension / 2 - 3.dp.toPx()
                drawCircle(ring.copy(alpha = if (enabled) 1f else 0.5f), r, style = Stroke(2.dp.toPx()))
                val frac = ((current - min) / (max - min)).coerceIn(0f, 1f)
                val angle = Math.toRadians((-135.0 + 270.0 * frac))
                val dx = sin(angle).toFloat()
                val dy = -cos(angle).toFloat()
                val c = center
                drawLine(tick, Offset(c.x + dx * r * 0.58f, c.y + dy * r * 0.58f), Offset(c.x + dx * r * 0.86f, c.y + dy * r * 0.86f), 4.dp.toPx(), StrokeCap.Round)
            }
            Text(
                valueText, style = Apm.type.bodySm, color = Apm.colors.textMuted,
                modifier = Modifier.then(if (enabled) Modifier.combinedClickable(onClick = {}, onLongClick = { editing = true }) else Modifier).padding(top = ApmSpace.s1),
            )
        }
    }
    if (editing) {
        var text by remember { mutableStateOf(String.format(java.util.Locale.ROOT, "%.1f", value)) }
        AlertDialog(
            onDismissRequest = { editing = false },
            title = { Text(title) },
            text = {
                OutlinedTextField(
                    value = text, onValueChange = { text = it }, singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    label = { Text("From " + min.toString() + " to " + max.toString()) },
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    text.replace(',', '.').toFloatOrNull()?.let { onChange(it.coerceIn(min, max)) }
                    editing = false
                }) { Text("OK") }
            },
            dismissButton = { TextButton(onClick = { editing = false }) { Text("Cancel") } },
        )
    }
}
