package app.apmplayer.ui.components

import app.apmplayer.ui.theme.n
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.selection.toggleable
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import app.apmplayer.ui.components.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import app.apmplayer.ui.theme.Apm
import app.apmplayer.ui.theme.ApmShape
import app.apmplayer.ui.theme.ApmSpace

/** Small pieces the settings pages are built from. Same look as the original: cyan headings, switches, step sliders. */

@Composable
fun SettingSection(title: String) {
    Text(
        title, style = Apm.type.bodySm.copy(fontWeight = FontWeight.Bold), color = Apm.colors.accent,
        modifier = Modifier.padding(start = ApmSpace.s4, end = ApmSpace.s4, top = ApmSpace.s4, bottom = ApmSpace.s1),
    )
}

@Composable
fun SettingNote(text: String) {
    Text(
        text, style = Apm.type.caption, color = n(Color(0xFF9A9A9A)),
        modifier = Modifier.padding(horizontal = ApmSpace.s4, vertical = ApmSpace.s2),
    )
}

@Composable
fun SettingSwitch(title: String, subtitle: String?, checked: Boolean, onChange: (Boolean) -> Unit) {
    val colors = Apm.colors
    Row(
        Modifier
            .fillMaxWidth()
            .heightIn(min = 64.dp)
            .focusRing(ApmShape.md)
            .toggleable(value = checked, role = Role.Switch, onValueChange = onChange)
            .padding(horizontal = ApmSpace.s4, vertical = ApmSpace.s2),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(ApmSpace.s3),
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, style = Apm.type.body.copy(fontWeight = FontWeight.Medium), color = colors.text)
            if (subtitle != null) Text(subtitle, style = Apm.type.caption, color = n(Color(0xFF9A9A9A)))
        }
        Switch(
            checked = checked, onCheckedChange = null,
            colors = SwitchDefaults.colors(
                checkedThumbColor = colors.accent, checkedTrackColor = colors.accent.copy(alpha = 0.35f),
                uncheckedThumbColor = n(Color(0xFF9A9A9A)), uncheckedTrackColor = n(Color(0xFF3A3A3A)),
                uncheckedBorderColor = n(Color(0xFF3A3A3A)),
            ),
        )
    }
}

@Composable
fun SettingSlider(
    title: String,
    subtitle: String?,
    valueText: String,
    value: Float,
    range: ClosedFloatingPointRange<Float>,
    onChange: (Float) -> Unit,
    steps: Int = 0,
) {
    val colors = Apm.colors
    Column(Modifier.fillMaxWidth().padding(horizontal = ApmSpace.s4, vertical = ApmSpace.s2)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(title, Modifier.weight(1f), style = Apm.type.body.copy(fontWeight = FontWeight.Medium), color = colors.text)
            Text(valueText, style = Apm.type.bodySm.copy(fontWeight = FontWeight.Bold), color = colors.accent)
        }
        if (subtitle != null) Text(subtitle, style = Apm.type.caption, color = n(Color(0xFF9A9A9A)))
        Slider(
            value = value.coerceIn(range.start, range.endInclusive), onValueChange = onChange,
            valueRange = range, steps = steps,
            colors = SliderDefaults.colors(
                thumbColor = colors.accent, activeTrackColor = colors.accent, inactiveTrackColor = n(Color(0xFF3A3A3A)),
            ),
        )
    }
}

/** A few round choices in a row, the chosen one filled. */
@Composable
fun SettingChoices(title: String, subtitle: String?, options: List<String>, selected: Int, onSelect: (Int) -> Unit) {
    val colors = Apm.colors
    Column(Modifier.fillMaxWidth().padding(horizontal = ApmSpace.s4, vertical = ApmSpace.s2)) {
        Text(title, style = Apm.type.body.copy(fontWeight = FontWeight.Medium), color = colors.text)
        if (subtitle != null) Text(subtitle, style = Apm.type.caption, color = n(Color(0xFF9A9A9A)))
        Row(
            Modifier.padding(top = ApmSpace.s2).horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(ApmSpace.s2),
        ) {
            options.forEachIndexed { i, label ->
                val on = i == selected
                Box(
                    Modifier
                        .heightIn(min = 40.dp)
                        .clip(ApmShape.pill)
                        .background(if (on) colors.accent else Color.Transparent)
                        .border(1.5.dp, if (on) colors.accent else n(Color(0xFF8A8A8A)), ApmShape.pill)
                        .focusRing(ApmShape.pill)
                        .clickable(role = Role.RadioButton) { onSelect(i) }
                        .padding(horizontal = ApmSpace.s4),
                    contentAlignment = Alignment.Center,
                ) {
                    Text(
                        label, style = Apm.type.bodySm.copy(fontWeight = FontWeight.Bold),
                        color = if (on) colors.onAccent else colors.text,
                    )
                }
            }
        }
    }
}

@Composable
fun SettingAction(title: String, subtitle: String?, onClick: () -> Unit) {
    Column(
        Modifier
            .fillMaxWidth()
            .heightIn(min = 64.dp)
            .focusRing(ApmShape.md)
            .clickable(role = Role.Button, onClick = onClick)
            .padding(horizontal = ApmSpace.s4, vertical = ApmSpace.s2),
        verticalArrangement = Arrangement.Center,
    ) {
        Text(title, style = Apm.type.body.copy(fontWeight = FontWeight.Medium), color = Apm.colors.text)
        if (subtitle != null) Text(subtitle, style = Apm.type.caption, color = n(Color(0xFF9A9A9A)))
    }
}

/** A round radio mark, a title and a line under it. Used for skins and layouts. */
@Composable
fun SettingRadio(title: String, subtitle: String?, selected: Boolean, onClick: () -> Unit) {
    val colors = Apm.colors
    Row(
        Modifier
            .fillMaxWidth()
            .heightIn(min = 64.dp)
            .focusRing(ApmShape.md)
            .clickable(role = Role.RadioButton, onClick = onClick)
            .padding(horizontal = ApmSpace.s4, vertical = ApmSpace.s2),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(ApmSpace.s3),
    ) {
        androidx.compose.material3.RadioButton(
            selected = selected, onClick = null,
            colors = androidx.compose.material3.RadioButtonDefaults.colors(selectedColor = colors.accent, unselectedColor = n(Color(0xFF8A8A8A))),
        )
        Column(Modifier.weight(1f)) {
            Text(title, style = Apm.type.body.copy(fontWeight = FontWeight.Medium), color = colors.text)
            if (subtitle != null) Text(subtitle, style = Apm.type.caption, color = n(Color(0xFF9A9A9A)))
        }
    }
}
