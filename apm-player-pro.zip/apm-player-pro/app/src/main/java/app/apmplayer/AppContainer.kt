package app.apmplayer

import android.content.Context
import app.apmplayer.art.ArtLoader
import app.apmplayer.audio.SoundController
import app.apmplayer.audio.WaveformProvider
import app.apmplayer.data.ApmDatabase
import app.apmplayer.lyrics.LyricsStore
import app.apmplayer.data.LibraryRepository
import app.apmplayer.data.LibraryScanner
import app.apmplayer.data.TrackWithArtist
import app.apmplayer.playback.PlayerConnection
import app.apmplayer.settings.SettingsStore
import app.apmplayer.tags.TagEditsStore
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.launch
import kotlin.random.Random

/** Builds the few long-lived objects once. Plain constructor wiring for now, Hilt can replace it later. */
class AppContainer(context: Context) {
    private val appContext = context.applicationContext
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    /** Small things the screens remember, like grid or list on the library home. */
    val uiPrefs = appContext.getSharedPreferences("ui", Context.MODE_PRIVATE)

    val database: ApmDatabase = ApmDatabase.create(appContext)
    val settings = SettingsStore(appContext)
    val tagEdits = TagEditsStore(appContext)
    val repository = LibraryRepository(database, LibraryScanner(appContext, database, settings, tagEdits), scope)
    private val progressPrefs = appContext.getSharedPreferences("progress", Context.MODE_PRIVATE)
    val player = PlayerConnection(appContext)
    val art = ArtLoader(appContext)
    val lyrics = LyricsStore(appContext)

    /** True while the visualizer has hidden the buttons, so the bottom dock hides too. */
    val fullScreenViz = MutableStateFlow(false)
    init {
        player.onCounted = { id -> scope.launch(Dispatchers.IO) { repository.markPlayed(id) } }
        player.onProgress = { id, position, length ->
            val s = settings.state.value
            if (s.rememberProgress && length >= s.rememberMinMinutes * 60_000L) {
                // near the end counts as finished, so the next play starts from the top
                progressPrefs.edit().putLong("p$id", if (position > length - 10_000L) 0L else position).apply()
            }
        }
        scope.launch {
            settings.state.collect { s ->
                player.fadeMs = s.fadeMs
                player.countPercent = s.countPlayedPct
            }
        }
    }

    val sound = SoundController(appContext, player)
    val waveforms = WaveformProvider(appContext, database)

    /** Start playing a list. With shuffle on, the first song is picked at random. */
    fun play(tracks: List<TrackWithArtist>, startIndex: Int = 0, shuffle: Boolean = false, startPositionMs: Long = 0L) {
        if (tracks.isEmpty()) return
        val start = if (shuffle) Random.nextInt(tracks.size) else startIndex.coerceIn(0, tracks.lastIndex)
        var from = startPositionMs
        val s = settings.state.value
        val track = tracks[start].track
        if (from == 0L && s.rememberProgress && track.durationMs >= s.rememberMinMinutes * 60_000L) {
            // a long song starts where it stopped last time
            val saved = progressPrefs.getLong("p${track.id}", 0L)
            if (saved > 0L && saved < track.durationMs - 10_000L) from = saved
        }
        player.play(tracks, start, shuffle, from)
        scope.launch(Dispatchers.IO) { repository.replaceQueue(tracks.map { it.track.id }) }
    }
}
