package app.apmplayer

import app.apmplayer.audio.Outputs
import app.apmplayer.audio.OutputKind
import app.apmplayer.audio.SoundEngine
import app.apmplayer.audio.RgInfo
import app.apmplayer.audio.ReplayGainTags
import app.apmplayer.audio.ReplayGainMath
import app.apmplayer.lyrics.LyricsTools
import kotlinx.coroutines.flow.first
import android.content.Context
import app.apmplayer.art.ArtLoader
import app.apmplayer.audio.SoundController
import app.apmplayer.audio.WaveformProvider
import app.apmplayer.data.ApmDatabase
import app.apmplayer.lyrics.LyricsStore
import app.apmplayer.data.LibraryRepository
import app.apmplayer.data.LibraryScanner
import app.apmplayer.data.TrackWithArtist
import app.apmplayer.playback.PlayerConnection
import app.apmplayer.settings.SettingsStore
import app.apmplayer.tags.TagEditsStore
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.launch
import kotlin.random.Random

/** Builds the few long-lived objects once. Plain constructor wiring for now, Hilt can replace it later. */
class AppContainer(context: Context) {
    private val appContext = context.applicationContext
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    /** Small things the screens remember, like grid or list on the library home. */
    val uiPrefs = appContext.getSharedPreferences("ui", Context.MODE_PRIVATE)

    val database: ApmDatabase = ApmDatabase.create(appContext)
    val settings = SettingsStore(appContext)
    val tagEdits = TagEditsStore(appContext)
    val repository = LibraryRepository(database, LibraryScanner(appContext, database, settings, tagEdits), scope)
    val progressPrefs = appContext.getSharedPreferences("progress", Context.MODE_PRIVATE)
    val player = PlayerConnection(appContext)
    val art = ArtLoader(appContext)
    val lyrics = LyricsStore(appContext)
    val lyricsTools = LyricsTools(appContext, lyrics, settings) { repository.browse.observeAll().first() }

    /** The group the playing songs came from, like an album or a folder. */
    val playbackSource = MutableStateFlow<PlaybackSource?>(null)

    /**
     * Goes to the next (or the previous) group of the same kind and plays its first song: the next album, artist, folder...
     * Returns false when there is no group to go to.
     */
    suspend fun jumpCategory(delta: Int): Boolean {
        val src = playbackSource.value ?: return false
        val browse = repository.browse
        val groups: List<Pair<String, String>> = when (src.kind) {
            "album" -> browse.observeAlbums().first().map { it.id.toString() to it.title }
            "artist" -> browse.observeArtists().first().map { it.id.toString() to it.name }
            "year" -> browse.observeYears().first().map { it.year.toString() to it.year.toString() }
            "folder" -> browse.observeFoldersWithMusic().first().map { it.path to it.name }
            "genre" -> browse.observeGenres().first().map { it.name to it.name }
            "composer" -> browse.observeComposers().first().map { it.name to it.name }
            "albumartist" -> browse.observeAlbumArtists().first().map { it.name to it.name }
            "playlist" -> repository.playlists.observePlaylists().first().map { it.id.toString() to it.name }
            else -> return false
        }
        val here = groups.indexOfFirst { it.first == src.key }
        if (here < 0 || groups.size < 2) return false
        val next = groups[(here + delta).mod(groups.size)]
        val tracks = when (src.kind) {
            "album" -> browse.observeAlbum(next.first.toLong()).first()
            "artist" -> browse.observeArtist(next.first.toLong()).first()
            "year" -> browse.observeYear(next.first.toInt()).first()
            "folder" -> repository.browse.observeFolderTracks(next.first).first()
            "genre" -> browse.observeGenre(next.first).first()
            "composer" -> browse.observeComposer(next.first).first()
            "albumartist" -> browse.observeAlbumArtist(next.first).first()
            else -> repository.playlists.observeTracks(next.first.toLong()).first()
        }
        if (tracks.isEmpty()) return false
        play(tracks, 0, false, 0L, PlaybackSource(src.kind, next.first, next.second))
        return true
    }

    /** Brings back the last queue at the last song and place, paused, so the player screen has a song to show. False when there is none. */
    suspend fun restoreLastQueue(waitForStorage: Boolean = false): Boolean {
        val tracks = repository.queue.observeTracks().first()
        if (tracks.isEmpty()) return false
        val lastId = progressPrefs.getLong("last_id", -1L)
        val lastPos = progressPrefs.getLong("last_pos", 0L)
        val index = tracks.indexOfFirst { it.track.id == lastId }.coerceAtLeast(0)
        if (waitForStorage) {
            // a card or a drive may still be mounting, wait for the song to be readable, for up to 30 seconds
            val uri = android.net.Uri.parse(tracks[index].track.uri)
            for (attempt in 0 until 30) {
                val readable = try {
                    appContext.contentResolver.openAssetFileDescriptor(uri, "r")?.use { true } ?: false
                } catch (e: Exception) {
                    false
                }
                if (readable) break
                kotlinx.coroutines.delay(1000)
            }
        }
        player.load(tracks, index, if (tracks[index].track.id == lastId) lastPos else 0L)
        return true
    }

    /** A touch on the notification asks the screens to open the player or the list the songs came from. */
    val openRequests = kotlinx.coroutines.channels.Channel<Unit>(kotlinx.coroutines.channels.Channel.CONFLATED)

    /** The screen of the list a group of songs came from. */
    fun routeFor(src: PlaybackSource): String = when (src.kind) {
        "album", "artist", "year", "playlist" -> "songs/${src.kind}-${src.key}?title=${android.net.Uri.encode(src.title)}"
        "folder" -> "folders?path=${android.net.Uri.encode(src.key)}"
        else -> "songs/${src.kind}?title=${android.net.Uri.encode(src.title)}&arg=${android.net.Uri.encode(src.key)}"
    }

    /** True while the visualizer has hidden the buttons, so the bottom dock hides too. */
    val fullScreenViz = MutableStateFlow(false)
    init {
        player.onCounted = { id -> scope.launch(Dispatchers.IO) { repository.markPlayed(id) } }
        player.onProgress = { id, position, length ->
            val s = settings.state.value
            // the last song and place, so the media notification can resume after the app was unloaded
            progressPrefs.edit().putLong("last_id", id).putLong("last_pos", if (position > length - 10_000L) 0L else position).apply()
            if (s.rememberProgress && length >= s.rememberMinMinutes * 60_000L) {
                // near the end counts as finished, so the next play starts from the top
                progressPrefs.edit().putLong("p$id", if (position > length - 10_000L) 0L else position).apply()
            }
        }
        scope.launch {
            settings.state.collect { s ->
                player.fadeMs = s.fadeMs
                player.countPercent = s.countPlayedPct
                player.prevResets = s.prevResets
            }
        }
        // lyrics files in the folder the user picked are matched to songs a few seconds after the app starts
        scope.launch(Dispatchers.IO) {
            kotlinx.coroutines.delay(6000)
            val s = settings.state.value
            if (s.scanLrc && s.lrcFolderUri.isNotBlank()) lyricsTools.scanFolder { _, _ -> }
        }
    }

    val sound = SoundController(appContext, player)

    /** True after the first screen of this run of the app has decided where to start. */
    @Volatile var startHandled = false

    // replay gain, fade between songs, the system volume knob and dither follow the Audio settings
    private val replayGains = HashMap<String, RgInfo?>()

    private fun updateReplayGain(uri: String?) {
        val s = settings.state.value
        if (s.rgApply == 0 || uri == null) {
            SoundEngine.replayGain = 1.0
            return
        }
        scope.launch(Dispatchers.IO) {
            val known = synchronized(replayGains) { replayGains.containsKey(uri) }
            val info = if (known) {
                synchronized(replayGains) { replayGains[uri] }
            } else {
                ReplayGainTags.read(appContext, android.net.Uri.parse(uri)).also { found ->
                    synchronized(replayGains) {
                        if (replayGains.size > 800) replayGains.clear()
                        replayGains[uri] = found
                    }
                }
            }
            // the screen lists Album first, the maths takes 1 for the album gain
            val db = ReplayGainMath.gainDb(info, if (s.rgSource == 0) 1 else 0, s.rgPreampWith, s.rgPreampWithout, s.rgApply == 2)
            SoundEngine.replayGain = ReplayGainMath.toLinear(db)
        }
    }

    init {
        player.onSongChanged = { uri -> updateReplayGain(uri) }
        scope.launch {
            settings.state.collect { s ->
                player.songFadeMs = s.songFadeMs
                SoundEngine.ditherType = s.ditherType
                updateVolumeMode()
                updateReplayGain(player.state.value.uri)
            }
        }
        // the output can change when a headset, a Bluetooth device or a USB device comes or goes
        val handler = android.os.Handler(android.os.Looper.getMainLooper())
        appContext.getSystemService(android.media.AudioManager::class.java).registerAudioDeviceCallback(
            object : android.media.AudioDeviceCallback() {
                override fun onAudioDevicesAdded(addedDevices: Array<out android.media.AudioDeviceInfo>) = updateVolumeMode()
                override fun onAudioDevicesRemoved(removedDevices: Array<out android.media.AudioDeviceInfo>) = updateVolumeMode()
            },
            handler,
        )
    }

    /**
     * Direct Volume Control is on when it is switched on and the output now in use allows it
     * (a Bluetooth device usually has absolute volume, then it is left off). When it is off the sound is
     * lowered by the "No DVC - Preamp Reduction" so the equalizer has room.
     */
    private fun updateVolumeMode() {
        val s = settings.state.value
        val out = Outputs.active(appContext)
        val blocked = when (out) {
            OutputKind.WIRED -> s.noDvcWired
            OutputKind.SPEAKER -> s.noDvcSpeaker
            OutputKind.BLUETOOTH -> s.noDvcBt || s.noDvcBtAbs
            OutputKind.USB -> s.noDvcUsb
            OutputKind.OTHER -> s.noDvcOther
        }
        val active = s.dvc && !blocked
        SoundEngine.headroom = if (active) 1.0 else ReplayGainMath.toLinear(s.preampReductionDb)
        SoundEngine.dvcActive.value = active
        if (player.useSystemVolume != active) {
            player.useSystemVolume = active
            player.setVolume(sound.state.value.volume)
        }
    }
    val waveforms = WaveformProvider(appContext, database)

    /** Start playing a list. With shuffle on, the first song is picked at random. */
    fun play(
        tracks: List<TrackWithArtist>,
        startIndex: Int = 0,
        shuffle: Boolean = false,
        startPositionMs: Long = 0L,
        source: PlaybackSource? = null,
    ) {
        playbackSource.value = source
        if (tracks.isEmpty()) return
        val start = if (shuffle) Random.nextInt(tracks.size) else startIndex.coerceIn(0, tracks.lastIndex)
        var from = startPositionMs
        val s = settings.state.value
        val track = tracks[start].track
        if (from == 0L && s.rememberProgress && track.durationMs >= s.rememberMinMinutes * 60_000L) {
            // a long song starts where it stopped last time
            val saved = progressPrefs.getLong("p${track.id}", 0L)
            if (saved > 0L && saved < track.durationMs - 10_000L) from = saved
        }
        player.play(tracks, start, shuffle, from)
        scope.launch(Dispatchers.IO) { repository.replaceQueue(tracks.map { it.track.id }) }
    }
}

/** Where the songs that are playing came from. kind is album, artist, year, folder, genre, composer, albumartist or playlist. */
data class PlaybackSource(val kind: String, val key: String, val title: String)
