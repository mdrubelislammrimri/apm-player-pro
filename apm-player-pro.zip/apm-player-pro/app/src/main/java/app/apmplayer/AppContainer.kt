package app.apmplayer

import android.content.Context
import app.apmplayer.audio.SoundController
import app.apmplayer.audio.WaveformProvider
import app.apmplayer.data.ApmDatabase
import app.apmplayer.data.LibraryRepository
import app.apmplayer.data.LibraryScanner
import app.apmplayer.data.TrackWithArtist
import app.apmplayer.playback.PlayerConnection
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlin.random.Random

/** Builds the few long-lived objects once. Plain constructor wiring for now, Hilt can replace it later. */
class AppContainer(context: Context) {
    private val appContext = context.applicationContext
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    /** Small things the screens remember, like grid or list on the library home. */
    val uiPrefs = appContext.getSharedPreferences("ui", Context.MODE_PRIVATE)

    val database: ApmDatabase = ApmDatabase.create(appContext)
    val repository = LibraryRepository(database, LibraryScanner(appContext, database), scope)
    val player = PlayerConnection(appContext)
    val sound = SoundController(appContext, player)
    val waveforms = WaveformProvider(appContext, database)

    /** Start playing a list. With shuffle on, the first song is picked at random. */
    fun play(tracks: List<TrackWithArtist>, startIndex: Int = 0, shuffle: Boolean = false) {
        if (tracks.isEmpty()) return
        val start = if (shuffle) Random.nextInt(tracks.size) else startIndex.coerceIn(0, tracks.lastIndex)
        player.play(tracks, start, shuffle)
        scope.launch(Dispatchers.IO) { repository.replaceQueue(tracks.map { it.track.id }) }
    }
}
