package app.apmplayer.net

import java.net.HttpURLConnection
import java.net.URL

/** Reads a small text from a web address. Only https, a short wait, and a size limit. Null when it fails. */
fun fetchText(address: String, maxBytes: Int = 64_000): String? {
    if (!address.startsWith("https://")) return null
    return try {
        val conn = URL(address).openConnection() as HttpURLConnection
        conn.connectTimeout = 10_000
        conn.readTimeout = 10_000
        conn.instanceFollowRedirects = true
        conn.setRequestProperty("User-Agent", "ApmPlayerPro")
        try {
            if (conn.responseCode !in 200..299) return null
            conn.inputStream.use { input ->
                val buffer = ByteArray(maxBytes + 1)
                var total = 0
                while (total < buffer.size) {
                    val n = input.read(buffer, total, buffer.size - total)
                    if (n < 0) break
                    total += n
                }
                if (total > maxBytes) null else String(buffer, 0, total, Charsets.UTF_8)
            }
        } finally {
            conn.disconnect()
        }
    } catch (e: Exception) {
        null
    }
}
