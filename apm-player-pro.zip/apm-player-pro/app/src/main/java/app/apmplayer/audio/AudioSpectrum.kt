package app.apmplayer.audio

import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.log10
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * What the visualizer listens to. The sound chain pushes the sound it plays into a small ring,
 * and the screen asks for the strength of each pitch range about every frame.
 * It only records while a visualizer is on screen.
 */
object AudioSpectrum {
    private const val N = 1024
    private val ring = FloatArray(N)

    @Volatile private var pos = 0
    @Volatile var enabled = false
    @Volatile var sampleRate = 44100

    private val re = FloatArray(N)
    private val im = FloatArray(N)
    private val window = FloatArray(N) { (0.5 - 0.5 * cos(2.0 * PI * it / (N - 1))).toFloat() }

    /** Called from the audio thread for every frame of sound. */
    fun push(sample: Float) {
        if (!enabled) return
        val p = pos
        ring[p and (N - 1)] = sample
        pos = p + 1
    }

    /** Fills [out] with 0..1 strengths from low to high pitch (log spaced from 40 Hz). Call from one thread only. */
    fun bands(out: FloatArray) {
        val start = pos
        for (i in 0 until N) {
            re[i] = ring[(start + i) and (N - 1)] * window[i]
            im[i] = 0f
        }
        fft()
        val nyquist = sampleRate / 2f
        val low = 40f
        val high = min(16000f, nyquist * 0.95f)
        val binHz = sampleRate.toFloat() / N
        val count = out.size
        for (b in 0 until count) {
            val f0 = low * (high / low).pow(b.toFloat() / count)
            val f1 = low * (high / low).pow((b + 1f) / count)
            val i0 = max(1, (f0 / binHz).toInt())
            val i1 = max(i0, min(N / 2 - 1, (f1 / binHz).toInt()))
            var peak = 0f
            for (i in i0..i1) peak = max(peak, sqrt(re[i] * re[i] + im[i] * im[i]))
            val amplitude = peak / (N / 4f)
            val db = 20f * log10(amplitude + 1e-6f)
            out[b] = ((db + 62f) / 56f).coerceIn(0f, 1f) // -62 dB is silence, -6 dB is full
        }
    }

    private fun fft() {
        // bit reversal
        var j = 0
        for (i in 1 until N) {
            var bit = N shr 1
            while (j and bit != 0) {
                j = j xor bit
                bit = bit shr 1
            }
            j = j xor bit
            if (i < j) {
                val tr = re[i]; re[i] = re[j]; re[j] = tr
                val ti = im[i]; im[i] = im[j]; im[j] = ti
            }
        }
        var len = 2
        while (len <= N) {
            val ang = -2.0 * PI / len
            val wr = cos(ang).toFloat()
            val wi = sin(ang).toFloat()
            var i = 0
            while (i < N) {
                var cr = 1f
                var ci = 0f
                for (k in 0 until len / 2) {
                    val ur = re[i + k]
                    val ui = im[i + k]
                    val vr = re[i + k + len / 2] * cr - im[i + k + len / 2] * ci
                    val vi = re[i + k + len / 2] * ci + im[i + k + len / 2] * cr
                    re[i + k] = ur + vr
                    im[i + k] = ui + vi
                    re[i + k + len / 2] = ur - vr
                    im[i + k + len / 2] = ui - vi
                    val ncr = cr * wr - ci * wi
                    ci = cr * wi + ci * wr
                    cr = ncr
                }
                i += len
            }
            len = len shl 1
        }
    }
}
