package app.apmplayer.lyrics

import android.net.Uri
import app.apmplayer.net.fetchText
import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.abs

/** Looks lyrics up on LRCLIB (a free lyrics database, no account needed). Timed lyrics are preferred. */
object LyricsOnline {
    private const val BASE = "https://lrclib.net/api/"

    /** Blocking, call it from a background thread. Null when nothing was found or the network failed. */
    fun fetch(artist: String?, title: String, album: String?, durationMs: Long): String? {
        val exact = StringBuilder(BASE + "get?track_name=" + Uri.encode(title))
        if (!artist.isNullOrBlank()) exact.append("&artist_name=").append(Uri.encode(artist))
        if (!album.isNullOrBlank()) exact.append("&album_name=").append(Uri.encode(album))
        if (durationMs > 0) exact.append("&duration=").append(durationMs / 1000)
        fetchText(exact.toString(), 400_000)?.let { body ->
            try {
                pick(JSONObject(body))?.let { return it }
            } catch (e: Exception) {
                // fall through to the wider search
            }
        }
        val wide = StringBuilder(BASE + "search?track_name=" + Uri.encode(title))
        if (!artist.isNullOrBlank()) wide.append("&artist_name=").append(Uri.encode(artist))
        val body = fetchText(wide.toString(), 400_000) ?: return null
        return try {
            val arr = JSONArray(body)
            val items = (0 until arr.length()).map { arr.getJSONObject(it) }
            val close = items.filter { durationMs <= 0 || abs(it.optDouble("duration", 0.0) * 1000 - durationMs) < 5000 }
            (close.firstNotNullOfOrNull { text(it, "syncedLyrics") } ?: close.firstNotNullOfOrNull { text(it, "plainLyrics") })
        } catch (e: Exception) {
            null
        }
    }

    private fun text(o: JSONObject, key: String): String? =
        if (o.isNull(key)) null else o.optString(key).takeIf { it.isNotBlank() }

    private fun pick(o: JSONObject): String? = text(o, "syncedLyrics") ?: text(o, "plainLyrics")
}
