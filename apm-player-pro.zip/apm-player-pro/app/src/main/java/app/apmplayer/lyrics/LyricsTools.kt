package app.apmplayer.lyrics

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.provider.OpenableColumns
import app.apmplayer.data.TrackWithArtist
import app.apmplayer.settings.SettingsStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Everything that finds lyrics for a song, in this order: lyrics already saved, lyrics written inside the song file,
 * lyrics files in the folder the user picked, and lyrics from the internet.
 */
class LyricsTools(
    private val context: Context,
    private val store: LyricsStore,
    private val settings: SettingsStore,
    private val allTracks: suspend () -> List<TrackWithArtist>,
) {
    private val noTags = HashSet<Long>()

    private fun fallback() = settings.state.value.let { if (it.lyricsUtf8) Charsets.ISO_8859_1 else lyricsCharset(it.lyricsCharset) }

    /** Saved lyrics, else lyrics from inside the file (kept for next time). Null when there are none. */
    suspend fun local(trackId: Long, uri: String): String? = withContext(Dispatchers.IO) {
        store.get(trackId)?.let { return@withContext it }
        if (trackId in noTags) return@withContext null
        val tag = LyricsTags.read(context, Uri.parse(uri), fallback())
        if (tag != null) {
            store.save(trackId, tag)
            tag
        } else {
            noTags.add(trackId)
            null
        }
    }

    /** Looks the song up on the internet and keeps what it finds. */
    suspend fun online(trackId: Long, artist: String?, title: String, album: String?, durationMs: Long): String? =
        withContext(Dispatchers.IO) {
            val found = LyricsOnline.fetch(artist, title, album, durationMs)
            if (found != null) store.save(trackId, found)
            found
        }

    fun onWifi(): Boolean {
        val cm = context.getSystemService(ConnectivityManager::class.java) ?: return false
        val caps = cm.getNetworkCapabilities(cm.activeNetwork) ?: return false
        return caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) || caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET)
    }

    fun hasInternet(): Boolean {
        val cm = context.getSystemService(ConnectivityManager::class.java) ?: return false
        val caps = cm.getNetworkCapabilities(cm.activeNetwork) ?: return false
        return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }

    /** True when a song without lyrics should be looked up online by itself. */
    fun canAutoDownload(): Boolean {
        val s = settings.state.value
        return s.lyricsAuto && hasInternet() && (!s.lyricsWifiOnly || onWifi())
    }

    /** Reads lyrics tags of every song that has no saved lyrics. Returns how many were found. */
    suspend fun rescanTags(onProgress: (done: Int, total: Int) -> Unit): Int = withContext(Dispatchers.IO) {
        noTags.clear()
        val tracks = allTracks()
        var found = 0
        tracks.forEachIndexed { i, t ->
            if (store.get(t.track.id) == null) {
                val tag = LyricsTags.read(context, Uri.parse(t.track.uri), fallback())
                if (tag != null) {
                    store.save(t.track.id, tag)
                    found++
                } else {
                    noTags.add(t.track.id)
                }
            }
            if (i % 25 == 0) onProgress(i, tracks.size)
        }
        found
    }

    /** Matches the .lrc and .txt files of the picked folder to songs by file name. Returns how many were added, or -1 without a folder. */
    suspend fun scanFolder(onProgress: (done: Int, total: Int) -> Unit): Int = withContext(Dispatchers.IO) {
        val s = settings.state.value
        if (s.lrcFolderUri.isBlank()) return@withContext -1
        val files = try {
            LrcFolder.index(context, Uri.parse(s.lrcFolderUri))
        } catch (e: Exception) {
            return@withContext -1
        }
        if (files.isEmpty()) return@withContext 0
        val tracks = allTracks()
        var added = 0
        tracks.forEachIndexed { i, t ->
            if (store.get(t.track.id) == null) {
                val name = displayName(t.track.uri)?.substringBeforeLast('.')?.lowercase()
                val keys = listOfNotNull(
                    name,
                    t.artistName?.let { "${it.lowercase()} - ${t.track.title.lowercase()}" },
                    t.track.title.lowercase(),
                )
                val hit = keys.firstNotNullOfOrNull { files[it] }
                if (hit != null) {
                    val text = LrcFolder.readText(context, hit, s.lyricsUtf8, lyricsCharset(s.lyricsCharset))
                    if (text != null) {
                        store.save(t.track.id, text)
                        added++
                    }
                }
            }
            if (i % 50 == 0) onProgress(i, tracks.size)
        }
        added
    }

    private fun displayName(uri: String): String? = try {
        context.contentResolver.query(Uri.parse(uri), arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
            if (it.moveToFirst()) it.getString(0) else null
        }
    } catch (e: Exception) {
        null
    }
}
