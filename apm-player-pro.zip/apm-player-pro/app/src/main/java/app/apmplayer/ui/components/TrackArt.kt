package app.apmplayer.ui.components

import android.graphics.Bitmap
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.RectangleShape
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import app.apmplayer.art.ArtLoader
import app.apmplayer.settings.Settings
import app.apmplayer.ui.theme.ApmShape

/** Set once at the top of the app so every screen can load covers. */
val LocalArtLoader = compositionLocalOf<ArtLoader?> { null }

/** The settings, so any screen can read them and redraw when they change. */
val LocalSettings = compositionLocalOf { Settings() }

/** Loads the cover of a song, or null while loading and when the song has no picture. */
@Composable
fun rememberArt(trackId: Long?, uri: String?, sizePx: Int): Bitmap? {
    val loader = LocalArtLoader.current
    val forceDefault = LocalSettings.current.forceDefaultArt
    val bitmap by produceState<Bitmap?>(initialValue = null, trackId, uri, sizePx, forceDefault) {
        value = if (!forceDefault && loader != null && trackId != null && !uri.isNullOrEmpty()) loader.load(trackId, uri, sizePx) else null
    }
    return bitmap
}

/** The cover of a song, cropped to fill. Songs without a picture get the generated colours. */
@Composable
fun TrackArt(
    trackId: Long,
    uri: String?,
    modifier: Modifier = Modifier,
    shape: Shape = ApmShape.md,
    sizePx: Int = 192,
) {
    val bitmap = rememberArt(trackId, uri, sizePx)
    Box(modifier.clip(shape)) {
        if (bitmap != null) {
            Image(
                bitmap = bitmap.asImageBitmap(), contentDescription = null,
                contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize(),
            )
        } else {
            GeneratedArt(seed = trackId, modifier = Modifier.fillMaxSize(), shape = RectangleShape)
        }
    }
}
