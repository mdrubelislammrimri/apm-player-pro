package app.apmplayer.lyrics

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

/** Lyrics the user added, one small text file per song. Kept in the app's own folder, so no database change. */
class LyricsStore(context: Context) {
    private val dir = File(context.filesDir, "lyrics").apply { mkdirs() }

    private fun file(trackId: Long) = File(dir, "$trackId.txt")

    suspend fun get(trackId: Long): String? = withContext(Dispatchers.IO) {
        val f = file(trackId)
        if (f.exists()) f.readText(Charsets.UTF_8).takeIf { it.isNotBlank() } else null
    }

    suspend fun save(trackId: Long, text: String) = withContext(Dispatchers.IO) {
        file(trackId).writeText(text.take(MAX_CHARS), Charsets.UTF_8)
    }

    suspend fun delete(trackId: Long) = withContext(Dispatchers.IO) { file(trackId).delete() }

    private companion object {
        const val MAX_CHARS = 200_000
    }
}
