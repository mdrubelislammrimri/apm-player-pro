package app.apmplayer.ui.screens

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.QueueMusic
import app.apmplayer.ui.components.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import app.apmplayer.AppContainer
import app.apmplayer.ui.theme.Apm
import app.apmplayer.ui.theme.ApmSpace

/** What plays next. Tap a song to jump to it. The song that is playing is shown in the accent colour. */
@Composable
fun QueueScreen(container: AppContainer, onUp: () -> Unit) {
    val queue by remember { container.repository.queue.observeTracks() }.collectAsStateWithLifecycle(initialValue = null)
    val playing by container.player.state.collectAsStateWithLifecycle()
    Column(Modifier.fillMaxSize()) {
        ListHeader("Queue", Icons.AutoMirrored.Rounded.QueueMusic, Color(0xFFB8A23A), onUp)
        val items = queue
        when {
            items == null -> SkeletonList()
            items.isEmpty() -> Text(
                "Nothing is queued. Play a song and the list shows up here.",
                style = Apm.type.bodySm, color = Apm.colors.textMuted, modifier = Modifier.padding(ApmSpace.s5),
            )
            else -> LazyColumn(Modifier.fillMaxSize()) {
                itemsIndexed(items, key = { _, t -> t.track.id }) { index, item ->
                    SongRow(item, item.track.id.toString() == playing.mediaId) { container.player.seekToItem(index) }
                }
            }
        }
    }
}
