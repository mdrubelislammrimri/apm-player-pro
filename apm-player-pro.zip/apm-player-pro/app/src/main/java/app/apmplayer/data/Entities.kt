package app.apmplayer.data

import androidx.room.ColumnInfo
import androidx.room.Embedded
import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

// Mirrors replica/schema.sql for the tables the first slice needs.

@Entity(tableName = "artists", indices = [Index(value = ["name"], unique = true)])
data class ArtistEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    @ColumnInfo(collate = ColumnInfo.NOCASE) val name: String,
    @ColumnInfo(name = "created_at") val createdAt: Long,
    @ColumnInfo(name = "updated_at") val updatedAt: Long,
)

@Entity(
    tableName = "albums",
    foreignKeys = [ForeignKey(ArtistEntity::class, ["id"], ["artist_id"], onDelete = ForeignKey.SET_NULL)],
    indices = [
        Index(value = ["title", "artist_id"], unique = true),
        Index("artist_id"), Index("year"), Index("date_added_ms"),
    ],
)
data class AlbumEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    @ColumnInfo(collate = ColumnInfo.NOCASE) val title: String,
    @ColumnInfo(name = "artist_id") val artistId: Long?,
    val year: Int?,
    @ColumnInfo(name = "artwork_uri") val artworkUri: String?,
    @ColumnInfo(name = "date_added_ms") val dateAddedMs: Long,
    @ColumnInfo(name = "created_at") val createdAt: Long,
    @ColumnInfo(name = "updated_at") val updatedAt: Long,
)

@Entity(
    tableName = "folders",
    foreignKeys = [ForeignKey(FolderEntity::class, ["id"], ["parent_id"], onDelete = ForeignKey.CASCADE)],
    indices = [Index(value = ["path"], unique = true), Index("parent_id")],
)
data class FolderEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val path: String,
    val name: String,
    @ColumnInfo(name = "parent_id") val parentId: Long?,
    @ColumnInfo(name = "artwork_track_id") val artworkTrackId: Long?,
    @ColumnInfo(name = "created_at") val createdAt: Long,
    @ColumnInfo(name = "updated_at") val updatedAt: Long,
)

@Entity(
    tableName = "tracks",
    foreignKeys = [
        ForeignKey(ArtistEntity::class, ["id"], ["artist_id"], onDelete = ForeignKey.SET_NULL),
        ForeignKey(AlbumEntity::class, ["id"], ["album_id"], onDelete = ForeignKey.SET_NULL),
        ForeignKey(FolderEntity::class, ["id"], ["folder_id"], onDelete = ForeignKey.CASCADE),
    ],
    indices = [
        Index(value = ["media_store_id"], unique = true),
        Index("artist_id"),
        Index("album_id", "disc_no", "track_no"),
        Index("folder_id", "title"),
        Index("date_added_ms"),
        Index("genre"),
        Index("scan_generation"),
    ],
)
data class TrackEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    @ColumnInfo(name = "media_store_id") val mediaStoreId: Long,
    val uri: String,
    @ColumnInfo(collate = ColumnInfo.NOCASE) val title: String,
    @ColumnInfo(name = "artist_id") val artistId: Long?,
    @ColumnInfo(name = "album_id") val albumId: Long?,
    @ColumnInfo(name = "folder_id") val folderId: Long,
    @ColumnInfo(name = "duration_ms") val durationMs: Long,
    @ColumnInfo(name = "track_no") val trackNo: Int?,
    @ColumnInfo(name = "disc_no") val discNo: Int?,
    val year: Int?,
    val genre: String?,
    val rating: Int,
    @ColumnInfo(name = "mime_type") val mimeType: String?,
    @ColumnInfo(name = "size_bytes") val sizeBytes: Long?,
    val bitrate: Int?,
    @ColumnInfo(name = "sample_rate") val sampleRate: Int?,
    @ColumnInfo(name = "bit_depth") val bitDepth: Int?,
    @ColumnInfo(name = "date_added_ms") val dateAddedMs: Long,
    @ColumnInfo(name = "is_missing") val isMissing: Boolean,
    @ColumnInfo(name = "scan_generation") val scanGeneration: Long,
    @ColumnInfo(name = "created_at") val createdAt: Long,
    @ColumnInfo(name = "updated_at") val updatedAt: Long,
    val composer: String? = null,
    @ColumnInfo(name = "album_artist") val albumArtist: String? = null,
    @ColumnInfo(name = "play_count") val playCount: Int = 0,
    @ColumnInfo(name = "last_played_ms") val lastPlayedMs: Long = 0,
)

@Entity(
    tableName = "queue_items",
    foreignKeys = [ForeignKey(TrackEntity::class, ["id"], ["track_id"], onDelete = ForeignKey.CASCADE)],
    indices = [Index(value = ["position"], unique = true), Index("track_id")],
)
data class QueueItemEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val position: Int,
    @ColumnInfo(name = "track_id") val trackId: Long,
    val played: Boolean = false,
)

/** A track plus the artist name, for list rows. */
data class TrackWithArtist(
    @Embedded val track: TrackEntity,
    @ColumnInfo(name = "artist_name") val artistName: String?,
)

/** Waveform for the seek bar. A cache: safe to delete, rebuilt in the background. */
@Entity(
    tableName = "waveforms",
    foreignKeys = [ForeignKey(TrackEntity::class, ["id"], ["track_id"], onDelete = ForeignKey.CASCADE)],
)
class WaveformEntity(
    @PrimaryKey @ColumnInfo(name = "track_id") val trackId: Long,
    val points: Int,
    val peaks: ByteArray,
    val version: Int,
    @ColumnInfo(name = "created_at") val createdAt: Long,
)

/** One track with the names the player screen and track menu need. */
data class TrackDetail(
    @Embedded val track: TrackEntity,
    @ColumnInfo(name = "artist_name") val artistName: String?,
    @ColumnInfo(name = "album_title") val albumTitle: String?,
    @ColumnInfo(name = "folder_path") val folderPath: String,
)

// Rows for the library browse screens.
data class AlbumRow(
    val id: Long,
    val title: String,
    @ColumnInfo(name = "artist_name") val artistName: String?,
    @ColumnInfo(name = "track_count") val trackCount: Int,
)

data class ArtistRow(
    val id: Long,
    val name: String,
    @ColumnInfo(name = "track_count") val trackCount: Int,
)

data class YearRow(
    val year: Int,
    @ColumnInfo(name = "track_count") val trackCount: Int,
)

data class FolderRow(
    val path: String,
    val name: String,
    @ColumnInfo(name = "track_count") val trackCount: Int,
)

@Entity(tableName = "playlists", indices = [Index(value = ["name"], unique = true)])
data class PlaylistEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    @ColumnInfo(collate = ColumnInfo.NOCASE) val name: String,
    @ColumnInfo(name = "created_at") val createdAt: Long,
    @ColumnInfo(name = "updated_at") val updatedAt: Long,
)

@Entity(
    tableName = "playlist_items",
    foreignKeys = [
        ForeignKey(PlaylistEntity::class, ["id"], ["playlist_id"], onDelete = ForeignKey.CASCADE),
        ForeignKey(TrackEntity::class, ["id"], ["track_id"], onDelete = ForeignKey.CASCADE),
    ],
    indices = [
        Index(value = ["playlist_id", "track_id"], unique = true),
        Index(value = ["playlist_id", "position"]),
        Index("track_id"),
    ],
)
data class PlaylistItemEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    @ColumnInfo(name = "playlist_id") val playlistId: Long,
    @ColumnInfo(name = "track_id") val trackId: Long,
    val position: Int,
    @ColumnInfo(name = "created_at") val createdAt: Long,
)

/** A saved place in a song, like a bookmark in a long track. */
@Entity(
    tableName = "bookmarks",
    foreignKeys = [ForeignKey(TrackEntity::class, ["id"], ["track_id"], onDelete = ForeignKey.CASCADE)],
    indices = [Index("track_id")],
)
data class BookmarkEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    @ColumnInfo(name = "track_id") val trackId: Long,
    @ColumnInfo(name = "position_ms") val positionMs: Long,
    @ColumnInfo(name = "created_at") val createdAt: Long,
)

data class PlaylistRow(
    val id: Long,
    val name: String,
    @ColumnInfo(name = "track_count") val trackCount: Int,
)

/** A genre, composer or album artist with how many songs have it. */
data class NameCountRow(
    val name: String,
    @ColumnInfo(name = "track_count") val trackCount: Int,
)

data class BookmarkWithTrack(
    @Embedded val track: TrackEntity,
    @ColumnInfo(name = "artist_name") val artistName: String?,
    @ColumnInfo(name = "bookmark_id") val bookmarkId: Long,
    @ColumnInfo(name = "position_ms") val positionMs: Long,
)
