package app.apmplayer.ui.theme

import android.graphics.Color as AndroidColor
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import app.apmplayer.settings.Settings
import org.json.JSONArray
import org.json.JSONObject

/** "#RRGGBB" or "RRGGBB" to a colour, or null when the text is not a colour. */
fun parseHexColor(text: String): Color? {
    val t = text.trim().removePrefix("#")
    if (t.length != 6) return null
    val v = t.toLongOrNull(16) ?: return null
    return Color(0xFF000000L or v)
}

fun Color.toHex(): String {
    val argb = (alpha * 255).toInt() shl 24 or ((red * 255).toInt() shl 16) or ((green * 255).toInt() shl 8) or (blue * 255).toInt()
    return String.format("#%06X", argb and 0xFFFFFF)
}

/** Dark text on a bright accent, white text on a dark one. */
fun readableOn(accent: Color): Color = if (accent.luminance() > 0.42f) Color(0xFF101010) else Color.White

/** The accent made deeper, so it can be read on a light background. */
fun darkened(c: Color): Color {
    val hsv = FloatArray(3)
    AndroidColor.RGBToHSV((c.red * 255).toInt(), (c.green * 255).toInt(), (c.blue * 255).toInt(), hsv)
    hsv[2] = (hsv[2] * 0.62f).coerceIn(0f, 1f)
    return Color(AndroidColor.HSVToColor(hsv))
}

/** Skins the user imported. The text is a list like [{"name":"Ocean","accent":"#3DA5F4"}]. */
fun customSkinsFrom(json: String): List<Skin> = try {
    val arr = JSONArray(json)
    (0 until arr.length()).mapNotNull { i ->
        val o = arr.getJSONObject(i)
        val accent = parseHexColor(o.optString("accent")) ?: return@mapNotNull null
        val name = o.optString("name").trim().ifEmpty { return@mapNotNull null }
        Skin(name, accent, readableOn(accent))
    }
} catch (e: Exception) {
    emptyList()
}

fun customSkinsToJson(skins: List<Skin>): String {
    val arr = JSONArray()
    skins.forEach { arr.put(JSONObject().put("name", it.name).put("accent", it.accent.toHex())) }
    return arr.toString()
}

/** The built-in skins followed by the imported ones. */
fun allSkins(s: Settings): List<Skin> = ApmSkins + customSkinsFrom(s.customSkins)

/** Reads a skin file: one skin like {"name":"Ocean","accent":"#3DA5F4"}, or a list of them. */
fun parseSkinsText(text: String): List<Skin> {
    val t = text.trim()
    return if (t.startsWith("[")) customSkinsFrom(t) else customSkinsFrom("[$t]")
}
