package app.apmplayer.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.Notes
import androidx.compose.material.icons.automirrored.rounded.PlaylistAdd
import androidx.compose.material.icons.automirrored.rounded.QueueMusic
import androidx.compose.material.icons.rounded.ArrowDownward
import androidx.compose.material.icons.rounded.ArrowUpward
import androidx.compose.material.icons.rounded.BookmarkBorder
import androidx.compose.material.icons.rounded.Folder
import androidx.compose.material.icons.rounded.FormatListNumbered
import androidx.compose.material.icons.rounded.GraphicEq
import androidx.compose.material.icons.rounded.Image
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.Repeat
import androidx.compose.material.icons.rounded.Schedule
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material.icons.rounded.Shuffle
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Checkbox
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import app.apmplayer.ui.components.Text
import app.apmplayer.ui.theme.Apm
import app.apmplayer.ui.theme.n

/** One button that can sit in the row under the cover. */
data class PlayerButtonDef(val id: String, val label: String, val icon: ImageVector)

val PlayerButtonCatalog = listOf(
    PlayerButtonDef("viz", "Visualizer", Icons.Rounded.GraphicEq),
    PlayerButtonDef("sleep", "Sleep timer", Icons.Rounded.Schedule),
    PlayerButtonDef("repeat", "Repeat", Icons.Rounded.Repeat),
    PlayerButtonDef("shuffle", "Shuffle", Icons.Rounded.Shuffle),
    PlayerButtonDef("lyrics", "Lyrics", Icons.AutoMirrored.Rounded.Notes),
    PlayerButtonDef("queue", "Queue", Icons.AutoMirrored.Rounded.QueueMusic),
    PlayerButtonDef("eq", "Equalizer", Icons.Rounded.Tune),
    PlayerButtonDef("playlist", "Add to playlist", Icons.AutoMirrored.Rounded.PlaylistAdd),
    PlayerButtonDef("bookmark", "Bookmark", Icons.Rounded.BookmarkBorder),
    PlayerButtonDef("share", "Share", Icons.Rounded.Share),
    PlayerButtonDef("info", "Track info", Icons.Rounded.Info),
    PlayerButtonDef("folder", "Folder", Icons.Rounded.Folder),
    PlayerButtonDef("art", "Album Art", Icons.Rounded.Image),
    PlayerButtonDef("counter", "Track counter", Icons.Rounded.FormatListNumbered),
)

const val DEFAULT_PLAYER_BUTTONS = "viz,sleep,repeat,shuffle"

fun parsePlayerButtons(text: String): List<String> {
    val known = PlayerButtonCatalog.map { it.id }.toSet()
    return text.split(",").map { it.trim() }.filter { it in known }.distinct()
}

/** What pressing and holding the menu button can do. The first is "nothing". The names are what doAction understands. */
val MenuLongPressLabels = listOf(
    "Disabled", "Delete", "Add to Playlist", "Info/Tags", "Album Art", "Artist", "Album", "Folder", "Genre", "Share", "Like", "Unlike",
)
val MenuLongPressActions = listOf("", "delete", "playlist", "info", "art", "artist", "album", "folder", "genre", "share", "like", "unlike")

/** What pressing the second text line (the artist line) can do. */
val Line2Labels = listOf("Disabled", "Artist", "Album", "Folder", "Genre")
val Line2Actions = listOf("", "artist", "album", "folder", "genre")

/** Pick the buttons under the cover and their order. */
@Composable
fun PlayerButtonsEditor(current: List<String>, onChange: (List<String>) -> Unit, onDismiss: () -> Unit) {
    val others = PlayerButtonCatalog.map { it.id }.filter { it !in current }
    fun def(id: String) = PlayerButtonCatalog.first { it.id == id }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Player screen buttons") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                Text("Tick the buttons you want and move them up or down.", style = Apm.type.caption, color = Apm.colors.textMuted)
                current.forEachIndexed { i, id ->
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        Checkbox(checked = true, onCheckedChange = { onChange(current - id) })
                        Icon(def(id).icon, contentDescription = null, tint = n(Color.White), modifier = Modifier.size(22.dp))
                        Text(def(id).label, style = Apm.type.body, color = Apm.colors.text, modifier = Modifier.weight(1f))
                        IconButton(enabled = i > 0, onClick = { onChange(current.toMutableList().also { it.add(i - 1, it.removeAt(i)) }) }) {
                            Icon(Icons.Rounded.ArrowUpward, contentDescription = "Move up")
                        }
                        IconButton(enabled = i < current.lastIndex, onClick = { onChange(current.toMutableList().also { it.add(i + 1, it.removeAt(i)) }) }) {
                            Icon(Icons.Rounded.ArrowDownward, contentDescription = "Move down")
                        }
                    }
                }
                others.forEach { id ->
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        Checkbox(checked = false, onCheckedChange = { onChange(current + id) })
                        Icon(def(id).icon, contentDescription = null, tint = Apm.colors.textMuted, modifier = Modifier.size(22.dp))
                        Text(def(id).label, style = Apm.type.body, color = Apm.colors.textMuted)
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Done") } },
        dismissButton = { TextButton(onClick = { onChange(parsePlayerButtons(DEFAULT_PLAYER_BUTTONS)) }) { Text("Restore") } },
    )
}
