package app.apmplayer.ui.theme

import androidx.compose.runtime.Immutable
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

// Inter (SIL Open Font Licence) is bundled as res/font/inter_*.ttf.
// Scripts Inter does not cover fall back to the system font automatically.
// val InterFamily = FontFamily(Font(R.font.inter_regular, FontWeight.Normal), ...)
val ApmFont: FontFamily = FontFamily.Default // replace with InterFamily once the font files are added

@Immutable
data class ApmTypography(
    val label: TextStyle = TextStyle(fontFamily = ApmFont, fontSize = 11.sp, lineHeight = 14.sp, fontWeight = FontWeight.Medium),
    val caption: TextStyle = TextStyle(fontFamily = ApmFont, fontSize = 12.sp, lineHeight = 16.sp, fontWeight = FontWeight.Normal),
    val bodySm: TextStyle = TextStyle(fontFamily = ApmFont, fontSize = 14.sp, lineHeight = 20.sp, fontWeight = FontWeight.Normal),
    val body: TextStyle = TextStyle(fontFamily = ApmFont, fontSize = 16.sp, lineHeight = 24.sp, fontWeight = FontWeight.Normal),
    val title: TextStyle = TextStyle(fontFamily = ApmFont, fontSize = 20.sp, lineHeight = 28.sp, fontWeight = FontWeight.SemiBold),
    val headline: TextStyle = TextStyle(fontFamily = ApmFont, fontSize = 28.sp, lineHeight = 34.sp, fontWeight = FontWeight.Bold),
) {
    // Time labels and dB / Hz values: same sizes, tabular digits so numbers do not jitter.
    val numeric: TextStyle get() = caption.copy(fontFeatureSettings = "tnum")
}
