package app.apmplayer.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Album
import androidx.compose.material.icons.rounded.CalendarMonth
import androidx.compose.material.icons.rounded.Folder
import androidx.compose.material.icons.rounded.Mic
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import app.apmplayer.AppContainer
import app.apmplayer.ui.components.GeneratedArt
import app.apmplayer.ui.components.focusRing
import app.apmplayer.ui.theme.Apm
import app.apmplayer.ui.theme.ApmShape
import app.apmplayer.ui.theme.ApmSpace

data class GroupItem(val key: String, val title: String, val subtitle: String, val seed: Long)

/** Albums, artists, years or folders: a list of groups, tap one to open it. */
@Composable
fun GroupListScreen(
    title: String,
    icon: ImageVector,
    tint: Color,
    items: List<GroupItem>?,
    onUp: () -> Unit,
    onOpen: (GroupItem) -> Unit,
    emptyText: String,
) {
    Column(Modifier.fillMaxSize()) {
        ListHeader(title, icon, tint, onUp)
        when {
            items == null -> SkeletonList()
            items.isEmpty() -> Text(
                emptyText, style = Apm.type.bodySm, color = Apm.colors.textMuted,
                modifier = Modifier.padding(ApmSpace.s5),
            )
            else -> LazyColumn(Modifier.fillMaxSize()) {
                items(items, key = { it.key }) { g ->
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .heightIn(min = 76.dp)
                            .focusRing(ApmShape.md)
                            .clickable(role = Role.Button) { onOpen(g) }
                            .padding(horizontal = ApmSpace.s4, vertical = ApmSpace.s1),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(ApmSpace.s4),
                    ) {
                        GeneratedArt(seed = g.seed, modifier = Modifier.size(60.dp), shape = ApmShape.sm)
                        Column(Modifier.weight(1f)) {
                            Text(
                                g.title, style = Apm.type.body.copy(fontWeight = FontWeight.Bold), color = Apm.colors.text,
                                maxLines = 2, overflow = TextOverflow.Ellipsis,
                            )
                            Text(
                                g.subtitle, style = Apm.type.bodySm.copy(fontWeight = FontWeight.SemiBold),
                                color = Color(0xFFB0B0B0), maxLines = 1, overflow = TextOverflow.Ellipsis,
                            )
                        }
                    }
                }
            }
        }
    }
}

private fun songsLabel(n: Int) = if (n == 1) "1 song" else "$n songs"

@Composable
fun AlbumsScreen(container: AppContainer, onUp: () -> Unit, onOpen: (GroupItem) -> Unit) {
    val rows by remember { container.repository.browse.observeAlbums() }.collectAsStateWithLifecycle(initialValue = null)
    val items = rows?.map {
        GroupItem(it.id.toString(), it.title, listOfNotNull(it.artistName, songsLabel(it.trackCount)).joinToString(" · "), it.id)
    }
    GroupListScreen("Albums", Icons.Rounded.Album, Color(0xFF7E6BA8), items, onUp, onOpen, "No albums found.")
}

@Composable
fun ArtistsScreen(container: AppContainer, onUp: () -> Unit, onOpen: (GroupItem) -> Unit) {
    val rows by remember { container.repository.browse.observeArtists() }.collectAsStateWithLifecycle(initialValue = null)
    val items = rows?.map { GroupItem(it.id.toString(), it.name, songsLabel(it.trackCount), it.id) }
    GroupListScreen("Artists", Icons.Rounded.Mic, Color(0xFF6F6F9A), items, onUp, onOpen, "No artists found.")
}

@Composable
fun YearsScreen(container: AppContainer, onUp: () -> Unit, onOpen: (GroupItem) -> Unit) {
    val rows by remember { container.repository.browse.observeYears() }.collectAsStateWithLifecycle(initialValue = null)
    val items = rows?.map { GroupItem(it.year.toString(), it.year.toString(), songsLabel(it.trackCount), it.year.toLong()) }
    GroupListScreen("Years", Icons.Rounded.CalendarMonth, Color(0xFF4A9AA8), items, onUp, onOpen, "No songs have a year in their tags.")
}

/** The "Folders" category: only folders that directly hold music, as one flat list. */
@Composable
fun FoldersFlatScreen(container: AppContainer, onUp: () -> Unit, onOpen: (GroupItem) -> Unit) {
    val rows by remember { container.repository.browse.observeFoldersWithMusic() }.collectAsStateWithLifecycle(initialValue = null)
    val items = rows?.map { GroupItem(it.path, it.name, songsLabel(it.trackCount), it.path.hashCode().toLong()) }
    GroupListScreen("Folders", Icons.Rounded.Folder, Color(0xFF4F7BD9), items, onUp, onOpen, "No folders with music found.")
}
