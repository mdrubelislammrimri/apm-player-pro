package app.apmplayer.playback

import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.media.AudioDeviceCallback
import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import androidx.core.app.NotificationManagerCompat
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.ForwardingPlayer
import androidx.media3.common.Player
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.audio.AudioSink
import androidx.media3.exoplayer.audio.DefaultAudioSink
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService
import androidx.media3.session.SessionCommand
import androidx.media3.session.SessionResult
import app.apmplayer.ApmApp
import app.apmplayer.MainActivity
import app.apmplayer.art.ArtBitmapLoader
import app.apmplayer.art.ArtLoader
import app.apmplayer.audio.DspProcessor
import com.google.common.util.concurrent.Futures
import com.google.common.util.concurrent.ListenableFuture
import com.google.common.util.concurrent.SettableFuture
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

/**
 * Owns the real player. Runs as a foreground media service so music keeps playing with the screen off,
 * and gives the notification, lock screen controls and headset buttons through the media session.
 * The Notifications settings decide how long the notification stays and what it looks like.
 */
@androidx.annotation.OptIn(androidx.media3.common.util.UnstableApi::class)
class PlaybackService : MediaSessionService() {

    private var session: MediaSession? = null
    private var prefListener: android.content.SharedPreferences.OnSharedPreferenceChangeListener? = null
    private var deviceCallback: AudioDeviceCallback? = null
    private val handler = Handler(Looper.getMainLooper())
    private var hideNotification = false
    private val prefs get() = getSharedPreferences("settings", MODE_PRIVATE)

    override fun onCreate() {
        super.onCreate()
        // The sound chain (equalizer, tone, limiter...) is plugged into the audio output here.
        val renderers = object : DefaultRenderersFactory(this) {
            override fun buildAudioSink(
                context: Context,
                enableFloatOutput: Boolean,
                enableAudioTrackPlaybackParams: Boolean,
            ): AudioSink? = DefaultAudioSink.Builder(context)
                .setEnableFloatOutput(enableFloatOutput)
                .setEnableAudioTrackPlaybackParams(enableAudioTrackPlaybackParams)
                .setAudioProcessors(arrayOf(DspProcessor()))
                .build()
        }
        val player = ExoPlayer.Builder(this, renderers)
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(C.USAGE_MEDIA)
                    .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
                    .build(),
                /* handleAudioFocus = */ true,
            )
            .setHandleAudioBecomingNoisy(true) // pause when headphones are unplugged
            .setSeekBackIncrementMs(10_000)
            .setSeekForwardIncrementMs(10_000)
            .setWakeMode(C.WAKE_MODE_LOCAL)
            .build()
        // the previous button of the notification and of headsets follows the "<< Button Resets Current Track" choice
        val front = object : ForwardingPlayer(player) {
            override fun seekToPrevious() {
                if (prefs.getBoolean("prevResets", false)) super.seekToPrevious() else seekToPreviousMediaItem()
            }
        }
        val art = ArtLoader(this)
        // a touch on the notification opens the app, on the player or on the list, as the settings say
        val open = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java)
                .putExtra("open_from_notification", true)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        session = MediaSession.Builder(this, front)
            .setBitmapLoader(ArtBitmapLoader(art))
            .setSessionActivity(open)
            .setCallback(callback)
            .build()
        setMediaNotificationProvider(ApmNotificationProvider(this, art))

        // "Pause when headphones are unplugged" is a setting, and it can change while the service runs
        player.setHandleAudioBecomingNoisy(prefs.getBoolean("pauseOnUnplug", true))
        prefListener = android.content.SharedPreferences.OnSharedPreferenceChangeListener { p, key ->
            if (key == "pauseOnUnplug") player.setHandleAudioBecomingNoisy(p.getBoolean("pauseOnUnplug", true))
        }
        prefs.registerOnSharedPreferenceChangeListener(prefListener)

        // Keep Notification off: the notification goes when the queue ends or after a long pause
        val removeLater = Runnable { hideNow() }
        player.addListener(object : Player.Listener {
            override fun onPlaybackStateChanged(playbackState: Int) {
                if (playbackState == Player.STATE_ENDED && !prefs.getBoolean("keepNotification", true)) hideNow()
            }

            override fun onIsPlayingChanged(isPlaying: Boolean) {
                handler.removeCallbacks(removeLater)
                if (isPlaying) {
                    hideNotification = false
                } else if (!prefs.getBoolean("keepNotification", true) && player.playbackState != Player.STATE_IDLE) {
                    handler.postDelayed(removeLater, 5 * 60_000L)
                }
            }
        })

        // Remove Notification on Disconnection: a headset, a Bluetooth device or a USB device went away while paused
        val audio = getSystemService(AudioManager::class.java)
        val onDevices = object : AudioDeviceCallback() {
            override fun onAudioDevicesRemoved(removedDevices: Array<out AudioDeviceInfo>) {
                if (!prefs.getBoolean("removeOnDisconnect", false)) return
                val outputs = setOf(
                    AudioDeviceInfo.TYPE_WIRED_HEADSET, AudioDeviceInfo.TYPE_WIRED_HEADPHONES, AudioDeviceInfo.TYPE_BLUETOOTH_A2DP,
                    AudioDeviceInfo.TYPE_BLUETOOTH_SCO, AudioDeviceInfo.TYPE_USB_HEADSET, AudioDeviceInfo.TYPE_USB_DEVICE,
                )
                if (removedDevices.any { it.type in outputs }) {
                    // wait a moment, the player pauses itself first
                    handler.postDelayed({ if (session?.player?.isPlaying != true) hideNow() }, 1500)
                }
            }
        }
        deviceCallback = onDevices
        audio.registerAudioDeviceCallback(onDevices, handler)
    }

    /** Takes the notification away until the player plays again. */
    private fun hideNow() {
        val s = session ?: return
        hideNotification = true
        onUpdateNotification(s, false)
    }

    override fun onUpdateNotification(session: MediaSession, startInForegroundRequired: Boolean) {
        if (hideNotification && !session.player.isPlaying) {
            stopForeground(STOP_FOREGROUND_REMOVE)
            NotificationManagerCompat.from(this).cancel(1001)
        } else {
            super.onUpdateNotification(session, startInForegroundRequired)
        }
    }

    private val callback = object : MediaSession.Callback {
        override fun onConnect(session: MediaSession, controller: MediaSession.ControllerInfo): MediaSession.ConnectionResult {
            // the extra notification buttons are commands of our own
            val commands = MediaSession.ConnectionResult.DEFAULT_SESSION_COMMANDS.buildUpon()
                .add(SessionCommand(ACTION_SHUFFLE, Bundle.EMPTY))
                .add(SessionCommand(ACTION_REPEAT, Bundle.EMPTY))
                .add(SessionCommand(ACTION_LIKE, Bundle.EMPTY))
                .build()
            return MediaSession.ConnectionResult.AcceptedResultBuilder(session).setAvailableSessionCommands(commands).build()
        }

        override fun onCustomCommand(
            session: MediaSession,
            controller: MediaSession.ControllerInfo,
            customCommand: SessionCommand,
            args: Bundle,
        ): ListenableFuture<SessionResult> {
            val p = session.player
            when (customCommand.customAction) {
                ACTION_SHUFFLE -> p.shuffleModeEnabled = !p.shuffleModeEnabled
                ACTION_REPEAT -> p.repeatMode = when (p.repeatMode) {
                    Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
                    Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
                    else -> Player.REPEAT_MODE_OFF
                }
                ACTION_LIKE -> toggleLike(p.currentMediaItem?.mediaId?.toLongOrNull())
            }
            return Futures.immediateFuture(SessionResult(SessionResult.RESULT_SUCCESS))
        }

        /** Keep Inactive Media Notification: when Android asks to resume, the saved queue comes back at the last place. */
        override fun onPlaybackResumption(
            mediaSession: MediaSession,
            controller: MediaSession.ControllerInfo,
        ): ListenableFuture<MediaSession.MediaItemsWithStartPosition> {
            if (!prefs.getBoolean("keepInactiveNotification", false)) {
                return Futures.immediateFailedFuture(UnsupportedOperationException())
            }
            val future = SettableFuture.create<MediaSession.MediaItemsWithStartPosition>()
            val container = (application as ApmApp).container
            CoroutineScope(Dispatchers.IO).launch {
                try {
                    val tracks = container.repository.queue.observeTracks().first()
                    if (tracks.isEmpty()) {
                        future.setException(IllegalStateException("No saved queue"))
                    } else {
                        val lastId = container.progressPrefs.getLong("last_id", -1L)
                        val lastPos = container.progressPrefs.getLong("last_pos", 0L)
                        val index = tracks.indexOfFirst { it.track.id == lastId }.coerceAtLeast(0)
                        future.set(
                            MediaSession.MediaItemsWithStartPosition(
                                tracks.map { it.toMediaItem(Uri.parse(it.track.uri)) }, index,
                                if (tracks[index].track.id == lastId) lastPos else 0L,
                            ),
                        )
                    }
                } catch (e: Exception) {
                    future.setException(e)
                }
            }
            return future
        }
    }

    private fun toggleLike(trackId: Long?) {
        if (trackId == null) return
        val container = (application as ApmApp).container
        CoroutineScope(Dispatchers.IO).launch {
            val rating = container.repository.observeTrack(trackId).first()?.track?.rating ?: 0
            container.repository.setRating(trackId, if (rating == 5) 0 else 5)
        }
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? = session

    override fun onTaskRemoved(rootIntent: Intent?) {
        val player = session?.player
        val stopAlways = prefs.getBoolean("stopOnSwipe", false)
        val keep = prefs.getBoolean("keepService", false)
        // Keep Service: a paused player stays loaded after the app is closed from recent apps
        if (stopAlways || (!keep && (player == null || !player.playWhenReady || player.mediaItemCount == 0))) stopSelf()
    }

    override fun onDestroy() {
        prefListener?.let { prefs.unregisterOnSharedPreferenceChangeListener(it) }
        deviceCallback?.let { getSystemService(AudioManager::class.java).unregisterAudioDeviceCallback(it) }
        handler.removeCallbacksAndMessages(null)
        session?.run {
            player.release()
            release()
        }
        session = null
        super.onDestroy()
    }
}
