package app.apmplayer.playback

import android.content.Intent
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import android.content.Context
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.audio.AudioSink
import androidx.media3.exoplayer.audio.DefaultAudioSink
import app.apmplayer.audio.DspProcessor
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService

/**
 * Owns the real player. Runs as a foreground media service so music keeps playing with the screen off,
 * and gives the notification, lock screen controls and headset buttons through the media session.
 */
class PlaybackService : MediaSessionService() {

    private var session: MediaSession? = null
    private var prefListener: android.content.SharedPreferences.OnSharedPreferenceChangeListener? = null

    override fun onCreate() {
        super.onCreate()
        // The sound chain (equalizer, tone, limiter...) is plugged into the audio output here.
        val renderers = object : DefaultRenderersFactory(this) {
            override fun buildAudioSink(
                context: Context,
                enableFloatOutput: Boolean,
                enableAudioTrackPlaybackParams: Boolean,
            ): AudioSink? = DefaultAudioSink.Builder(context)
                .setEnableFloatOutput(enableFloatOutput)
                .setEnableAudioTrackPlaybackParams(enableAudioTrackPlaybackParams)
                .setAudioProcessors(arrayOf(DspProcessor()))
                .build()
        }
        val player = ExoPlayer.Builder(this, renderers)
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(C.USAGE_MEDIA)
                    .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
                    .build(),
                /* handleAudioFocus = */ true,
            )
            .setHandleAudioBecomingNoisy(true) // pause when headphones are unplugged
            .setWakeMode(C.WAKE_MODE_LOCAL)
            .build()
        session = MediaSession.Builder(this, player).build()

        // "Pause when headphones are unplugged" is a setting, and it can change while the service runs
        val prefs = getSharedPreferences("settings", MODE_PRIVATE)
        player.setHandleAudioBecomingNoisy(prefs.getBoolean("pauseOnUnplug", true))
        prefListener = android.content.SharedPreferences.OnSharedPreferenceChangeListener { p, key ->
            if (key == "pauseOnUnplug") player.setHandleAudioBecomingNoisy(p.getBoolean("pauseOnUnplug", true))
        }
        prefs.registerOnSharedPreferenceChangeListener(prefListener)
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? = session

    override fun onTaskRemoved(rootIntent: Intent?) {
        val player = session?.player
        if (player == null || !player.playWhenReady || player.mediaItemCount == 0) stopSelf()
    }

    override fun onDestroy() {
        prefListener?.let { getSharedPreferences("settings", MODE_PRIVATE).unregisterOnSharedPreferenceChangeListener(it) }
        session?.run {
            player.release()
            release()
        }
        session = null
        super.onDestroy()
    }
}
