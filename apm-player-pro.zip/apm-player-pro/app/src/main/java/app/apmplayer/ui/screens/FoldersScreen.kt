package app.apmplayer.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowUpward
import androidx.compose.material.icons.rounded.Folder
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.Shuffle
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import app.apmplayer.AppContainer
import app.apmplayer.data.FolderContent
import app.apmplayer.data.FolderEntity
import app.apmplayer.data.TrackWithArtist
import app.apmplayer.ui.components.GeneratedArt
import app.apmplayer.ui.components.PillButton
import app.apmplayer.ui.components.focusRing
import app.apmplayer.ui.theme.Apm
import app.apmplayer.ui.theme.ApmLayout
import app.apmplayer.ui.theme.ApmShape
import app.apmplayer.ui.theme.ApmSpace
import app.apmplayer.util.folderDisplayName
import app.apmplayer.util.formatDuration

/** S04. Browse music by folder. path = "" is the top level. */
@Composable
fun FoldersScreen(
    path: String,
    container: AppContainer,
    onOpenFolder: (String) -> Unit,
    onUp: () -> Unit,
    onOpenNowPlaying: () -> Unit,
    onOpenSettings: () -> Unit,
) {
    val content by remember(path) { container.repository.observeFolder(path) }
        .collectAsStateWithLifecycle(initialValue = null)
    val scanning by container.repository.isScanning.collectAsStateWithLifecycle()
    val scanFailed by container.repository.scanFailed.collectAsStateWithLifecycle()
    val colors = Apm.colors

    Column(Modifier.fillMaxWidth()) {
        Header(path = path, onUp = onUp, onOpenSettings = onOpenSettings)
        val data: FolderContent? = content
        when {
            data == null -> SkeletonRows()
            data.folders.isEmpty() && data.tracks.isEmpty() -> EmptyState(
                path = path,
                scanning = scanning,
                failed = scanFailed,
                onScan = { container.repository.startScan() },
            )
            else -> LazyColumn(Modifier.fillMaxWidth()) {
                if (data.tracks.isNotEmpty()) {
                    item(key = "actions") {
                        Row(
                            Modifier.padding(horizontal = ApmSpace.s4, vertical = ApmSpace.s2),
                            horizontalArrangement = Arrangement.spacedBy(ApmSpace.s2),
                        ) {
                            PillButton("Play all", Icons.Rounded.PlayArrow, filled = true) {
                                container.play(data.tracks, 0, shuffle = false)
                                onOpenNowPlaying()
                            }
                            PillButton("Shuffle", Icons.Rounded.Shuffle, filled = false) {
                                container.play(data.tracks, 0, shuffle = true)
                                onOpenNowPlaying()
                            }
                        }
                    }
                }
                items(data.folders, key = { "f" + it.id }) { folder ->
                    FolderRow(folder) { onOpenFolder(folder.path) }
                }
                items(data.tracks.size, key = { "t" + data.tracks[it].track.id }) { index ->
                    TrackRow(data.tracks[index]) {
                        container.play(data.tracks, index, shuffle = false)
                        onOpenNowPlaying()
                    }
                }
            }
        }
    }
}

@Composable
private fun Header(path: String, onUp: () -> Unit, onOpenSettings: () -> Unit) {
    val colors = Apm.colors
    Row(
        Modifier.fillMaxWidth().heightIn(min = ApmLayout.header).padding(horizontal = ApmSpace.s4),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (path.isNotEmpty()) {
            Row(
                Modifier
                    .heightIn(min = ApmLayout.touchTargetMin)
                    .clip(ApmShape.pill)
                    .background(colors.surfaceRaised)
                    .focusRing(ApmShape.pill)
                    .clickable(role = Role.Button, onClick = onUp)
                    .padding(horizontal = ApmSpace.s3),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(ApmSpace.s1),
            ) {
                Icon(Icons.Rounded.ArrowUpward, contentDescription = "Up", tint = colors.text, modifier = Modifier.size(18.dp))
                Text(
                    folderDisplayName(path),
                    style = Apm.type.bodySm,
                    color = colors.text,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.widthIn(max = 220.dp),
                )
            }
        } else {
            Text("Folders", style = Apm.type.title, color = colors.text)
        }
        Spacer(Modifier.weight(1f))
        IconButton(onClick = onOpenSettings) {
            Icon(Icons.Rounded.Settings, contentDescription = "Settings", tint = colors.textMuted)
        }
    }
}

@Composable
private fun FolderRow(folder: FolderEntity, onClick: () -> Unit) {
    val colors = Apm.colors
    Row(
        Modifier
            .fillMaxWidth()
            .heightIn(min = ApmLayout.rowNormal)
            .focusRing(ApmShape.md)
            .clickable(role = Role.Button, onClick = onClick)
            .padding(horizontal = ApmSpace.s4, vertical = ApmSpace.s1),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(ApmSpace.s3),
    ) {
        Box(
            Modifier.size(40.dp).clip(ApmShape.sm).background(colors.surfaceRaised),
            contentAlignment = Alignment.Center,
        ) { Icon(Icons.Rounded.Folder, contentDescription = null, tint = colors.textMuted) }
        Text(
            folder.name,
            style = Apm.type.body,
            color = colors.text,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
        )
    }
}

@Composable
internal fun TrackRow(item: TrackWithArtist, onClick: () -> Unit) {
    val colors = Apm.colors
    val subtitle = listOfNotNull(item.artistName, formatDuration(item.track.durationMs)).joinToString(" · ")
    Row(
        Modifier
            .fillMaxWidth()
            .heightIn(min = ApmLayout.rowNormal)
            .focusRing(ApmShape.md)
            .clickable(role = Role.Button, onClick = onClick)
            .padding(horizontal = ApmSpace.s4, vertical = ApmSpace.s1),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(ApmSpace.s3),
    ) {
        GeneratedArt(seed = item.track.id, modifier = Modifier.size(40.dp), shape = ApmShape.sm)
        Column(Modifier.weight(1f)) {
            Text(item.track.title, style = Apm.type.body, color = colors.text, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(subtitle, style = Apm.type.caption, color = colors.textMuted, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
    }
}

@Composable
private fun SkeletonRows() {
    val colors = Apm.colors
    Column(Modifier.fillMaxWidth().padding(ApmSpace.s4), verticalArrangement = Arrangement.spacedBy(ApmSpace.s3)) {
        repeat(6) {
            Row(horizontalArrangement = Arrangement.spacedBy(ApmSpace.s3), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(40.dp).clip(ApmShape.sm).background(colors.surfaceRaised))
                Box(Modifier.fillMaxWidth(0.6f).height(16.dp).clip(ApmShape.sm).background(colors.surfaceRaised))
            }
        }
    }
}

@Composable
private fun EmptyState(path: String, scanning: Boolean, failed: Boolean, onScan: () -> Unit) {
    val colors = Apm.colors
    if (scanning) {
        SkeletonRows()
        Text(
            "Looking for music on this phone…",
            style = Apm.type.bodySm,
            color = colors.textMuted,
            modifier = Modifier.padding(horizontal = ApmSpace.s4),
        )
        return
    }
    Column(
        Modifier.fillMaxWidth().padding(ApmSpace.s5),
        verticalArrangement = Arrangement.spacedBy(ApmSpace.s3),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        val (title, note) = when {
            failed -> "The scan did not finish" to "Something went wrong while reading your music. Try again."
            path.isEmpty() -> "No music found" to "Copy some audio files onto this phone, then scan again."
            else -> "Nothing in this folder" to "The files may have been moved or deleted."
        }
        Text(title, style = Apm.type.title, color = colors.text)
        Text(note, style = Apm.type.bodySm, color = colors.textMuted)
        PillButton("Scan again", icon = null, filled = true, onClick = onScan)
    }
}
