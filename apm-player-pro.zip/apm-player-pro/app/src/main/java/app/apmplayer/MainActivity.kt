package app.apmplayer

import android.content.pm.ActivityInfo
import android.os.Build
import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.getValue
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import app.apmplayer.settings.Settings
import app.apmplayer.ui.AppRoot
import app.apmplayer.ui.theme.ApmTheme
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val container = (application as ApmApp).container
        if (intent?.getBooleanExtra("open_from_notification", false) == true) container.openRequests.trySend(Unit)
        setContent {
            val settings by container.settings.state.collectAsStateWithLifecycle()
            ApmTheme(settings) { AppRoot(container) }
        }
        // the window follows the choices on the settings pages
        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                container.settings.state.collect { applySettings(it) }
            }
        }
    }

    override fun onStart() {
        super.onStart()
        // Resume On Reopen: the app was already running and is opened again from the launcher
        val container = (application as ApmApp).container
        val s = container.settings.state.value
        if (container.startHandled && s.resumeOnReopen && !container.player.state.value.isPlaying) container.player.resume()
    }

    override fun onNewIntent(intent: android.content.Intent) {
        super.onNewIntent(intent)
        if (intent.getBooleanExtra("open_from_notification", false)) (application as ApmApp).container.openRequests.trySend(Unit)
    }

    private fun applySettings(s: Settings) {
        requestedOrientation = when (s.orientation) {
            1 -> ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
            2 -> ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
            else -> ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        }
        val bars = WindowCompat.getInsetsController(window, window.decorView)
        // dark icons on the light theme, light icons on the dark theme
        val phoneDark = (resources.configuration.uiMode and android.content.res.Configuration.UI_MODE_NIGHT_MASK) ==
            android.content.res.Configuration.UI_MODE_NIGHT_YES
        val light = s.themeMode == 1 || (s.themeMode == 3 && !phoneDark)
        bars.isAppearanceLightStatusBars = light
        bars.isAppearanceLightNavigationBars = light
        if (s.hideStatusBar) {
            bars.hide(WindowInsetsCompat.Type.statusBars())
            bars.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        } else {
            bars.show(WindowInsetsCompat.Type.statusBars())
        }
        if (s.keepScreenOn) window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        else window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) setShowWhenLocked(s.showOnLock)
    }
}
