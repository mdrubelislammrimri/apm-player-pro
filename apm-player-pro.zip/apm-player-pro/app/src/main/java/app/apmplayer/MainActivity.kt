package app.apmplayer

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import app.apmplayer.ui.AppRoot
import app.apmplayer.ui.theme.ApmTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val container = (application as ApmApp).container
        setContent {
            ApmTheme { AppRoot(container) }
        }
    }
}
