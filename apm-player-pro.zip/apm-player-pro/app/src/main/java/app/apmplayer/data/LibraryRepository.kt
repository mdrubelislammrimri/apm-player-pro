package app.apmplayer.data

import androidx.room.withTransaction
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.launch

data class FolderContent(val folders: List<FolderEntity>, val tracks: List<TrackWithArtist>)

/** The only door to the library data. Screens never touch the database directly. */
class LibraryRepository(
    private val db: ApmDatabase,
    private val scanner: LibraryScanner,
    private val scope: CoroutineScope,
) {
    private val _isScanning = MutableStateFlow(false)
    val isScanning: StateFlow<Boolean> = _isScanning.asStateFlow()

    private val _scanFailed = MutableStateFlow(false)
    val scanFailed: StateFlow<Boolean> = _scanFailed.asStateFlow()

    val browse: BrowseDao get() = db.browseDao()
    val queue: QueueDao get() = db.queueDao()
    val playlists: PlaylistDao get() = db.playlistDao()
    val bookmarks: BookmarkDao get() = db.bookmarkDao()

    private var scanJob: Job? = null

    /** Safe to call often: a scan already running is not started twice. */
    fun startScan() {
        if (scanJob?.isActive == true) return
        scanJob = scope.launch(Dispatchers.IO) {
            _isScanning.value = true
            _scanFailed.value = false
            try {
                scanner.scan()
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _scanFailed.value = true
            } finally {
                _isScanning.value = false
            }
        }
    }

    /** Path "" means the top level: the list of folders that hold music. */
    fun observeFolder(path: String): Flow<FolderContent> = combine(
        if (path.isEmpty()) db.folderDao().observeRoots() else db.folderDao().observeChildren(path),
        if (path.isEmpty()) flowOf(emptyList()) else db.trackDao().observeInFolder(path),
    ) { folders, tracks -> FolderContent(folders, tracks) }

    fun search(query: String): Flow<List<TrackWithArtist>> =
        if (query.isBlank()) flowOf(emptyList()) else db.trackDao().search(query.trim())

    fun observeTrack(id: Long): Flow<TrackDetail?> = db.trackDao().observeDetail(id)

    suspend fun setRating(id: Long, rating: Int) = db.trackDao().setRating(id, rating)

    suspend fun markPlayed(id: Long) = db.trackDao().markPlayed(id, System.currentTimeMillis())

    /** Makes a playlist. Returns its id, or null when the name is empty or already used. */
    suspend fun createPlaylist(name: String): Long? {
        val clean = name.trim()
        if (clean.isEmpty() || db.playlistDao().countByName(clean) > 0) return null
        val now = System.currentTimeMillis()
        return db.playlistDao().insert(PlaylistEntity(name = clean, createdAt = now, updatedAt = now))
    }

    suspend fun renamePlaylist(id: Long, name: String): Boolean {
        val clean = name.trim()
        if (clean.isEmpty() || db.playlistDao().countByName(clean) > 0) return false
        db.playlistDao().rename(id, clean, System.currentTimeMillis())
        return true
    }

    suspend fun addToPlaylist(playlistId: Long, trackId: Long) {
        db.withTransaction {
            val position = db.playlistDao().nextPosition(playlistId)
            db.playlistDao().insertItem(PlaylistItemEntity(0, playlistId, trackId, position, System.currentTimeMillis()))
        }
    }

    suspend fun addBookmark(trackId: Long, positionMs: Long) {
        db.bookmarkDao().insert(BookmarkEntity(trackId = trackId, positionMs = positionMs, createdAt = System.currentTimeMillis()))
    }

    suspend fun replaceQueue(trackIds: List<Long>) {
        db.withTransaction {
            db.queueDao().deleteAll()
            db.queueDao().insertAll(trackIds.mapIndexed { i, id -> QueueItemEntity(position = i, trackId = id) })
        }
    }
}
