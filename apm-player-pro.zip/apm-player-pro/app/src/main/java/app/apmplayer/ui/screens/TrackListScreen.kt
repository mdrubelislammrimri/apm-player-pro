package app.apmplayer.ui.screens

import app.apmplayer.ui.components.TrackArt
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.QueueMusic
import androidx.compose.material.icons.rounded.AccessTime
import androidx.compose.material.icons.rounded.AddCircle
import androidx.compose.material.icons.rounded.ArrowUpward
import androidx.compose.material.icons.rounded.MoreHoriz
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Shuffle
import androidx.compose.material.icons.rounded.ThumbDown
import androidx.compose.material.icons.rounded.ThumbUp
import androidx.compose.material.icons.automirrored.rounded.PlaylistPlay
import androidx.compose.material.icons.rounded.Category
import androidx.compose.material.icons.rounded.History
import androidx.compose.material.icons.rounded.Mic
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material.icons.rounded.PlayCircle
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.TextButton
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import app.apmplayer.AppContainer
import app.apmplayer.data.TrackWithArtist
import app.apmplayer.ui.components.ActionIconPill
import app.apmplayer.ui.components.GeneratedArt
import app.apmplayer.ui.components.OutlinePill
import app.apmplayer.ui.components.RoundIcon
import app.apmplayer.ui.components.focusRing
import app.apmplayer.ui.theme.Apm
import app.apmplayer.ui.theme.ApmShape
import app.apmplayer.ui.theme.ApmSpace
import app.apmplayer.util.formatDuration
import app.apmplayer.util.indexLetter
import app.apmplayer.util.mimeToExtension
import kotlinx.coroutines.launch

/** Tracks of 45 minutes or more are listed under "Long". */
const val LONG_TRACK_MS = 45L * 60_000L

/**
 * One kind of song list. [kind] is all, top, low, recent, long, most, played, album-ID, artist-ID, year-N or playlist-ID.
 * For genre, composer and albumartist the name comes in [argOverride].
 */
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun SongsKindScreen(
    kind: String,
    titleOverride: String,
    argOverride: String,
    container: AppContainer,
    onUp: () -> Unit,
    onSearch: () -> Unit,
    onOpenNowPlaying: () -> Unit,
) {
    val browse = container.repository.browse
    val type = kind.substringBefore('-')
    val arg = kind.substringAfter('-', "")
    val scope = rememberCoroutineScope()
    var removeFrom by remember { mutableStateOf<TrackWithArtist?>(null) }
    val (defaultTitle, icon, tint) = when (type) {
        "top" -> Triple("Top Rated", Icons.Rounded.ThumbUp, Color(0xFF5E8A86))
        "low" -> Triple("Low Rated", Icons.Rounded.ThumbDown, Color(0xFF7A7A7A))
        "recent" -> Triple("Recently Added", Icons.Rounded.AddCircle, Color(0xFF4E8F4E))
        "long" -> Triple("Long", Icons.Rounded.MoreHoriz, Color(0xFF6A5ACD))
        "most" -> Triple("Most Played", Icons.Rounded.PlayCircle, Color(0xFFB59A3A))
        "played" -> Triple("Recently Played", Icons.Rounded.History, Color(0xFF4F63C8))
        "genre" -> Triple(argOverride, Icons.Rounded.Category, Color(0xFF9A5878))
        "composer" -> Triple(argOverride, Icons.Rounded.Person, Color(0xFF3F8F5F))
        "albumartist" -> Triple(argOverride, Icons.Rounded.Mic, Color(0xFF7C6AA6))
        "playlist" -> Triple("Playlist", Icons.AutoMirrored.Rounded.PlaylistPlay, Color(0xFF9A5A52))
        else -> Triple("All Songs", Icons.Rounded.MusicNote, Color(0xFF5B6EE1))
    }
    val flow = remember(kind, argOverride) {
        when (type) {
            "top" -> browse.observeByRating(5)
            "low" -> browse.observeByRating(1)
            "recent" -> browse.observeRecentlyAdded()
            "long" -> browse.observeLong(LONG_TRACK_MS)
            "most" -> browse.observeMostPlayed()
            "played" -> browse.observeRecentlyPlayed()
            "genre" -> browse.observeGenre(argOverride)
            "composer" -> browse.observeComposer(argOverride)
            "albumartist" -> browse.observeAlbumArtist(argOverride)
            "playlist" -> container.repository.playlists.observeTracks(arg.toLongOrNull() ?: -1L)
            "album" -> browse.observeAlbum(arg.toLongOrNull() ?: -1L)
            "artist" -> browse.observeArtist(arg.toLongOrNull() ?: -1L)
            "year" -> browse.observeYear(arg.toIntOrNull() ?: -1)
            else -> browse.observeAll()
        }
    }
    val tracks by flow.collectAsStateWithLifecycle(initialValue = null)
    TrackListScreen(
        title = titleOverride.ifBlank { if (type == "year") arg else defaultTitle },
        icon = icon, tint = tint, tracks = tracks, container = container,
        onUp = onUp, onSearch = onSearch, onOpenNowPlaying = onOpenNowPlaying,
        letterIndex = type == "all",
        emptyText = when (type) {
            "top" -> "Songs you like show up here."
            "low" -> "Songs you dislike show up here."
            "most" -> "Songs you play to the middle or more show up here."
            "played" -> "Songs you have played show up here."
            "playlist" -> "This playlist is empty. Add songs from the track menu on the player screen."
            else -> "No songs here."
        },
        onLongClick = if (type == "playlist") ({ t: TrackWithArtist -> removeFrom = t }) else null,
    )
    val target = removeFrom
    if (target != null) {
        AlertDialog(
            onDismissRequest = { removeFrom = null },
            title = { Text("Remove from playlist") },
            text = { Text(target.track.title) },
            confirmButton = {
                TextButton(onClick = {
                    val playlistId = arg.toLongOrNull()
                    if (playlistId != null) {
                        scope.launch { container.repository.playlists.removeItem(playlistId, target.track.id) }
                    }
                    removeFrom = null
                }) { Text("Remove") }
            },
            dismissButton = { TextButton(onClick = { removeFrom = null }) { Text("Cancel") } },
        )
    }
}

/** A song list: header, shuffle / play / search pills, rows, and an A to Z index when asked. */
@Composable
fun TrackListScreen(
    title: String,
    icon: ImageVector,
    tint: Color,
    tracks: List<TrackWithArtist>?,
    container: AppContainer,
    onUp: () -> Unit,
    onSearch: () -> Unit,
    onOpenNowPlaying: () -> Unit,
    letterIndex: Boolean,
    emptyText: String,
    onLongClick: ((TrackWithArtist) -> Unit)? = null,
) {
    val listState = rememberLazyListState()
    val scope = rememberCoroutineScope()
    val playing by container.player.state.collectAsStateWithLifecycle()
    val hasTracks = !tracks.isNullOrEmpty()

    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize()) {
            ListHeader(title, icon, tint, onUp)
            Row(
                Modifier.fillMaxWidth().padding(horizontal = ApmSpace.s3, vertical = ApmSpace.s2),
                horizontalArrangement = Arrangement.spacedBy(ApmSpace.s2),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                ActionIconPill(Icons.Rounded.Shuffle, "Shuffle", {
                    tracks?.let { container.play(it, 0, shuffle = true); onOpenNowPlaying() }
                }, enabled = hasTracks)
                ActionIconPill(Icons.Rounded.PlayArrow, "Play all", {
                    tracks?.let { container.play(it, 0, shuffle = false); onOpenNowPlaying() }
                }, enabled = hasTracks)
                ActionIconPill(Icons.Rounded.Search, "Search", onSearch)
                OutlinePill("Select", {}, enabled = false)
                Spacer(Modifier.weight(1f))
                Box(Modifier.alpha(0.4f).size(48.dp), contentAlignment = Alignment.Center) {
                    Icon(Icons.Rounded.MoreVert, contentDescription = null, tint = Color.White)
                }
            }
            when {
                tracks == null -> SkeletonList()
                tracks.isEmpty() -> Text(
                    emptyText, style = Apm.type.bodySm, color = Apm.colors.textMuted,
                    modifier = Modifier.padding(ApmSpace.s5),
                )
                else -> LazyColumn(Modifier.fillMaxSize(), state = listState) {
                    itemsIndexed(tracks, key = { _, t -> t.track.id }) { index, item ->
                        SongRow(
                            item, item.track.id.toString() == playing.mediaId,
                            onLongClick = onLongClick?.let { handler -> { handler(item) } },
                        ) {
                            container.play(tracks, index, shuffle = false)
                            onOpenNowPlaying()
                        }
                    }
                }
            }
        }
        if (letterIndex && !tracks.isNullOrEmpty()) {
            AlphabetIndex(
                onLetter = { letter ->
                    val i = tracks.indexOfFirst { indexLetter(it.track.title) == letter }
                    if (i >= 0) scope.launch { listState.scrollToItem(i) }
                },
                modifier = Modifier.align(Alignment.CenterEnd),
            )
        }
    }
}

/** Small up button to the library, then the round icon and the big title. */
@Composable
fun ListHeader(title: String, icon: ImageVector, tint: Color, onUp: () -> Unit, upLabel: String = "Library") {
    val colors = Apm.colors
    Column(Modifier.fillMaxWidth().padding(horizontal = ApmSpace.s3, vertical = ApmSpace.s2)) {
        Row(
            Modifier
                .heightIn(min = 44.dp)
                .clip(ApmShape.pill)
                .background(Color(0xFF1F1F1F))
                .focusRing(ApmShape.pill)
                .clickable(role = Role.Button, onClick = onUp)
                .padding(horizontal = ApmSpace.s3),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(ApmSpace.s1),
        ) {
            Icon(Icons.Rounded.ArrowUpward, contentDescription = null, tint = colors.text, modifier = Modifier.size(18.dp))
            Text(upLabel, style = Apm.type.bodySm.copy(fontWeight = FontWeight.Bold), color = colors.text)
        }
        Row(
            Modifier.padding(top = ApmSpace.s3),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(ApmSpace.s3),
        ) {
            RoundIcon(icon, tint, size = 48.dp)
            Text(
                title, style = Apm.type.headline.copy(fontWeight = FontWeight.Bold), color = colors.text,
                maxLines = 1, overflow = TextOverflow.Ellipsis,
            )
        }
    }
}

/** Row with a thumbnail, bold title, artist, and "length | format". */
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun SongRow(
    item: TrackWithArtist,
    highlighted: Boolean,
    onLongClick: (() -> Unit)? = null,
    extraInfo: String? = null,
    onClick: () -> Unit,
) {
    val colors = Apm.colors
    val t = item.track
    Row(
        Modifier
            .fillMaxWidth()
            .heightIn(min = 76.dp)
            .focusRing(ApmShape.md)
            .combinedClickable(role = Role.Button, onLongClick = onLongClick, onClick = onClick)
            .padding(start = ApmSpace.s4, end = 36.dp, top = ApmSpace.s1, bottom = ApmSpace.s1),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(ApmSpace.s4),
    ) {
        TrackArt(trackId = t.id, uri = t.uri, modifier = Modifier.size(60.dp), shape = ApmShape.sm, sizePx = 160)
        Column(Modifier.weight(1f)) {
            Text(
                t.title, style = Apm.type.body.copy(fontWeight = FontWeight.Bold),
                color = if (highlighted) colors.accent else colors.text, maxLines = 2, overflow = TextOverflow.Ellipsis,
            )
            if (!item.artistName.isNullOrBlank()) {
                Text(
                    item.artistName, style = Apm.type.bodySm.copy(fontWeight = FontWeight.SemiBold),
                    color = Color(0xFFC8C8C8), maxLines = 1, overflow = TextOverflow.Ellipsis,
                )
            }
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(ApmSpace.s1)) {
                Icon(Icons.Rounded.AccessTime, contentDescription = null, tint = Color(0xFF8A8A8A), modifier = Modifier.size(12.dp))
                Text(
                    formatDuration(t.durationMs) + " | " + mimeToExtension(t.mimeType),
                    style = Apm.type.caption, color = Color(0xFF8A8A8A), maxLines = 1,
                )
            }
            if (extraInfo != null) {
                Text(extraInfo, style = Apm.type.caption.copy(fontWeight = FontWeight.Bold), color = Apm.colors.accent, maxLines = 1)
            }
        }
    }
}

/** A to Z and # down the right edge. Tap or drag to jump. */
@Composable
fun AlphabetIndex(onLetter: (Char) -> Unit, modifier: Modifier = Modifier) {
    val letters = remember { ('A'..'Z').toList() + '#' }
    Column(
        modifier
            .fillMaxHeight(0.9f)
            .width(28.dp)
            .semantics { contentDescription = "Alphabet index" }
            .pointerInput(Unit) {
                detectVerticalDragGestures { change, _ ->
                    change.consume()
                    val i = (change.position.y / size.height * letters.size).toInt().coerceIn(0, letters.lastIndex)
                    onLetter(letters[i])
                }
            }
            .pointerInput(Unit) {
                detectTapGestures { o ->
                    val i = (o.y / size.height * letters.size).toInt().coerceIn(0, letters.lastIndex)
                    onLetter(letters[i])
                }
            },
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceEvenly,
    ) {
        letters.forEach { Text(it.toString(), style = Apm.type.label, color = Color(0xFFB0B0B0)) }
    }
}

@Composable
fun SkeletonList() {
    Column(Modifier.fillMaxWidth().padding(ApmSpace.s4), verticalArrangement = Arrangement.spacedBy(ApmSpace.s3)) {
        repeat(6) {
            Row(horizontalArrangement = Arrangement.spacedBy(ApmSpace.s3), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(60.dp).clip(ApmShape.sm).background(Apm.colors.surfaceRaised))
                Box(Modifier.fillMaxWidth(0.6f).heightIn(min = 16.dp).clip(ApmShape.sm).background(Apm.colors.surfaceRaised))
            }
        }
    }
}
