package app.apmplayer.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import app.apmplayer.ui.theme.Apm
import app.apmplayer.ui.theme.ApmLayout
import app.apmplayer.ui.theme.ApmShape
import app.apmplayer.ui.theme.ApmSpace

/** 2dp ring for keyboard, D-pad and switch access. Put it BEFORE clickable in the modifier chain. */
fun Modifier.focusRing(shape: Shape): Modifier = composed {
    var focused by remember { mutableStateOf(false) }
    val color = Apm.colors.focusRing
    this
        .onFocusChanged { focused = it.isFocused }
        .then(if (focused) Modifier.border(2.dp, color, shape) else Modifier)
}

/** Default artwork: a gradient picked from the id, so each album looks different. Drawn in code, no copied images. */
@Composable
fun GeneratedArt(seed: Long, modifier: Modifier = Modifier, shape: Shape = ApmShape.md) {
    val hue = (((seed * 47L) % 360L + 360L) % 360L).toFloat()
    val hue2 = (hue + 40f) % 360f
    Box(
        modifier = modifier
            .clip(shape)
            .background(Brush.linearGradient(listOf(Color.hsv(hue, 0.55f, 0.62f), Color.hsv(hue2, 0.6f, 0.32f)))),
        contentAlignment = Alignment.Center,
    ) {
        Icon(
            Icons.Rounded.MusicNote,
            contentDescription = null,
            tint = Color.White.copy(alpha = 0.7f),
            modifier = Modifier.fillMaxSize(0.4f),
        )
    }
}

/** filled = accent, otherwise the raised surface. */
@Composable
fun PillButton(text: String, icon: ImageVector?, filled: Boolean, onClick: () -> Unit) {
    val colors = Apm.colors
    val bg = if (filled) colors.accent else colors.surfaceRaised
    val fg = if (filled) colors.onAccent else colors.text
    Row(
        modifier = Modifier
            .heightIn(min = ApmLayout.touchTargetMin)
            .clip(ApmShape.pill)
            .background(bg)
            .focusRing(ApmShape.pill)
            .clickable(role = Role.Button, onClick = onClick)
            .padding(horizontal = ApmSpace.s4),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(ApmSpace.s2),
    ) {
        if (icon != null) Icon(icon, contentDescription = null, tint = fg, modifier = Modifier.size(18.dp))
        Text(text, style = Apm.type.bodySm.copy(fontWeight = FontWeight.SemiBold), color = fg)
    }
}
