package app.apmplayer.ui.theme

import androidx.compose.foundation.shape.CircleShape
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.setValue
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.unit.dp

object ApmSpace { val s0 = 0.dp; val s1 = 4.dp; val s2 = 8.dp; val s3 = 12.dp; val s4 = 16.dp; val s5 = 24.dp; val s6 = 32.dp; val s7 = 48.dp }

object ApmShape {
    /** 1 is the normal rounding, a smaller number gives squarer corners. Read in composition, so screens follow the change. */
    var roundness by mutableFloatStateOf(1f)
    val sm get() = RoundedCornerShape((6 * roundness).dp)
    val md get() = RoundedCornerShape((12 * roundness).dp)
    val lg get() = RoundedCornerShape((20 * roundness).dp)
    val pill = RoundedCornerShape(percent = 50)
    val round = CircleShape
}

object ApmLayout {
    val header = 56.dp
    val bottomNav = 56.dp
    val miniPlayer = 64.dp
    val touchTargetMin = 48.dp
    val rowCompact = 40.dp; val rowSmall = 48.dp; val rowNormal = 56.dp
    const val gridColumns = 2; const val gridSmallColumns = 3; const val gridExtraSmallColumns = 4
    val eqSliderHeight = 220.dp; val eqTrack = 4.dp; val eqThumb = 28.dp
    val knob = 96.dp; val knobSmall = 72.dp; val knobIndicator = 4.dp
}

object ApmMotion { const val fastMs = 100; const val baseMs = 200 } // use 0 when animations are off
