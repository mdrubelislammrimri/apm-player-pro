package app.apmplayer.ui.components

import app.apmplayer.ui.theme.n
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.semantics.ProgressBarRangeInfo
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.progressBarRangeInfo
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.semantics.setProgress
import androidx.compose.ui.semantics.stateDescription
import androidx.compose.ui.unit.dp
import kotlin.math.max

private val PlayedBar get() = n(Color(0xFFF2F2F2))
private val RemainingBar get() = n(Color(0xFF5A5A5A))

/**
 * The song drawn as vertical bars. Bars up to the playing position are bright.
 * Tap or drag anywhere to jump. [onPreview] follows the finger, [onCommit] is called once when the finger lifts.
 */
@Composable
fun WaveformSeek(
    peaks: ByteArray?,
    fraction: Float,
    onPreview: (Float) -> Unit,
    onCommit: (Float) -> Unit,
    positionText: String,
    modifier: Modifier = Modifier,
) {
    var last by remember { mutableFloatStateOf(0f) }
    Canvas(
        modifier
            .fillMaxSize()
            .semantics {
                contentDescription = "Seek"
                stateDescription = positionText
                progressBarRangeInfo = ProgressBarRangeInfo(fraction.coerceIn(0f, 1f), 0f..1f)
                setProgress { v -> onCommit(v.coerceIn(0f, 1f)); true }
            }
            .pointerInput(Unit) {
                detectTapGestures { o -> onCommit((o.x / size.width).coerceIn(0f, 1f)) }
            }
            .pointerInput(Unit) {
                detectHorizontalDragGestures(
                    onDragStart = { o -> last = (o.x / size.width).coerceIn(0f, 1f); onPreview(last) },
                    onDragEnd = { onCommit(last) },
                    onDragCancel = { onCommit(last) },
                ) { change, _ ->
                    change.consume()
                    last = (change.position.x / size.width).coerceIn(0f, 1f)
                    onPreview(last)
                }
            },
    ) {
        val barW = 4.dp.toPx()
        val gap = 3.dp.toPx()
        val count = (size.width / (barW + gap)).toInt().coerceAtLeast(1)
        val cy = size.height / 2f
        val minH = 6.dp.toPx()
        val data = peaks
        for (i in 0 until count) {
            val level = if (data == null || data.isEmpty()) {
                0.1f
            } else {
                // loudest value inside the slice of the song this bar stands for
                val from = i * data.size / count
                val to = max(from + 1, (i + 1) * data.size / count).coerceAtMost(data.size)
                var m = 0
                for (k in from until to) m = max(m, data[k].toInt() and 0xFF)
                m / 255f
            }
            val h = max(minH, level * size.height * 0.9f)
            val x = i * (barW + gap) + barW / 2f
            val played = (i + 0.5f) / count <= fraction
            drawLine(
                if (played) PlayedBar else RemainingBar,
                Offset(x, cy - h / 2f), Offset(x, cy + h / 2f),
                strokeWidth = barW, cap = StrokeCap.Round,
            )
        }
    }
}
