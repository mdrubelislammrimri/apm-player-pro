package app.apmplayer.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.border
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.PlaylistPlay
import androidx.compose.material.icons.automirrored.rounded.QueueMusic
import androidx.compose.material.icons.rounded.AddCircle
import androidx.compose.material.icons.rounded.Album
import androidx.compose.material.icons.rounded.Bookmark
import androidx.compose.material.icons.rounded.CalendarMonth
import androidx.compose.material.icons.rounded.Category
import androidx.compose.material.icons.rounded.Folder
import androidx.compose.material.icons.rounded.FolderOpen
import androidx.compose.material.icons.rounded.History
import androidx.compose.material.icons.rounded.Mic
import androidx.compose.material.icons.rounded.MoreHoriz
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material.icons.rounded.PlayCircle
import androidx.compose.material.icons.rounded.ThumbDown
import androidx.compose.material.icons.rounded.ThumbUp
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import app.apmplayer.AppContainer
import app.apmplayer.ui.components.RoundIcon
import app.apmplayer.ui.components.focusRing
import app.apmplayer.ui.theme.Apm
import app.apmplayer.ui.theme.ApmShape
import app.apmplayer.ui.theme.ApmSpace

private data class LibraryEntry(
    val id: String,
    val label: String,
    val icon: ImageVector,
    val color: Color,
    val ready: Boolean,
)

// Order and colours follow the original. An entry with ready = false would be drawn dimmed. Streams is left out on purpose.
private val entries = listOf(
    LibraryEntry("songs", "All Songs", Icons.Rounded.MusicNote, Color(0xFF5B6EE1), true),
    LibraryEntry("folders", "Folders", Icons.Rounded.Folder, Color(0xFF4F7BD9), true),
    LibraryEntry("hierarchy", "Folders Hierarchy", Icons.Rounded.FolderOpen, Color(0xFF4A6FC2), true),
    LibraryEntry("albums", "Albums", Icons.Rounded.Album, Color(0xFF7E6BA8), true),
    LibraryEntry("artists", "Artists", Icons.Rounded.Mic, Color(0xFF6F6F9A), true),
    LibraryEntry("albumartists", "Album Artists", Icons.Rounded.Mic, Color(0xFF7C6AA6), true),
    LibraryEntry("genres", "Genres", Icons.Rounded.Category, Color(0xFF9A5878), true),
    LibraryEntry("years", "Years", Icons.Rounded.CalendarMonth, Color(0xFF4A9AA8), true),
    LibraryEntry("composers", "Composers", Icons.Rounded.Person, Color(0xFF3F8F5F), true),
    LibraryEntry("playlists", "Playlists", Icons.AutoMirrored.Rounded.PlaylistPlay, Color(0xFF9A5A52), true),
    LibraryEntry("queue", "Queue", Icons.AutoMirrored.Rounded.QueueMusic, Color(0xFFB8A23A), true),
    LibraryEntry("bookmarks", "Bookmarks", Icons.Rounded.Bookmark, Color(0xFF4A6FC2), true),
    LibraryEntry("mostplayed", "Most Played", Icons.Rounded.PlayCircle, Color(0xFFB59A3A), true),
    LibraryEntry("toprated", "Top Rated", Icons.Rounded.ThumbUp, Color(0xFF5E8A86), true),
    LibraryEntry("lowrated", "Low Rated", Icons.Rounded.ThumbDown, Color(0xFF7A7A7A), true),
    LibraryEntry("recentlyplayed", "Recently Played", Icons.Rounded.History, Color(0xFF4F63C8), true),
    LibraryEntry("recentlyadded", "Recently Added", Icons.Rounded.AddCircle, Color(0xFF4E8F4E), true),
    LibraryEntry("long", "Long", Icons.Rounded.MoreHoriz, Color(0xFF6A5ACD), true),
)

private const val PREF_GRID = "libraryGrid"

/** The library home: every way to browse the music, as a two column grid or a list. */
@Composable
fun LibraryHomeScreen(container: AppContainer, onOpen: (String) -> Unit) {
    val colors = Apm.colors
    var grid by remember { mutableStateOf(container.uiPrefs.getBoolean(PREF_GRID, true)) }
    var menuOpen by remember { mutableStateOf(false) }
    val queueCount by remember { container.repository.queue.observeCount() }.collectAsStateWithLifecycle(initialValue = 0)

    Column(Modifier.fillMaxSize()) {
        Row(
            Modifier.fillMaxWidth().heightIn(min = 72.dp).padding(horizontal = ApmSpace.s4),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(
                "Library", style = Apm.type.headline.copy(fontWeight = FontWeight.Bold), color = colors.text,
                modifier = Modifier.weight(1f),
            )
            Box {
                Box(
                    Modifier.size(48.dp).clip(ApmShape.round).border(1.5.dp, Color(0xFF8A8A8A), ApmShape.round)
                        .focusRing(ApmShape.round).clickable(role = Role.Button) { menuOpen = true },
                    contentAlignment = Alignment.Center,
                ) { Icon(Icons.Rounded.MoreVert, contentDescription = "Library options", tint = Color.White) }
                DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                    DropdownMenuItem(text = { Text(if (grid) "Show as list" else "Show as grid") }, onClick = {
                        grid = !grid
                        container.uiPrefs.edit().putBoolean(PREF_GRID, grid).apply()
                        menuOpen = false
                    })
                }
            }
        }
        if (grid) {
            LazyVerticalGrid(
                columns = GridCells.Fixed(2),
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(ApmSpace.s1),
            ) {
                items(entries, key = { it.id }) { e -> EntryRow(e, queueCount, onOpen, compact = true) }
            }
        } else {
            LazyColumn(Modifier.fillMaxSize()) {
                items(entries, key = { it.id }) { e -> EntryRow(e, queueCount, onOpen, compact = false) }
            }
        }
    }
}

@Composable
private fun EntryRow(e: LibraryEntry, queueCount: Int, onOpen: (String) -> Unit, compact: Boolean) {
    Row(
        Modifier
            .fillMaxWidth()
            .heightIn(min = if (compact) 64.dp else 72.dp)
            .alpha(if (e.ready) 1f else 0.4f)
            .focusRing(ApmShape.md)
            .clickable(enabled = e.ready, role = Role.Button) { onOpen(e.id) }
            .padding(horizontal = ApmSpace.s4, vertical = ApmSpace.s1),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(ApmSpace.s3),
    ) {
        RoundIcon(e.icon, e.color, size = if (compact) 44.dp else 48.dp)
        Text(
            e.label,
            style = (if (compact) Apm.type.bodySm else Apm.type.body).copy(fontWeight = FontWeight.Bold),
            color = Apm.colors.text,
        )
        if (e.id == "queue" && queueCount == 0) {
            Text("empty", style = Apm.type.label, color = Color(0xFF8A8A8A))
        }
    }
}
