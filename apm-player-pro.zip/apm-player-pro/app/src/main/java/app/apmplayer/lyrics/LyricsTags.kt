package app.apmplayer.lyrics

import android.content.Context
import android.net.Uri
import java.io.ByteArrayInputStream
import java.io.InputStream
import java.io.SequenceInputStream
import java.nio.charset.Charset

/**
 * Reads lyrics written inside a song file: MP3 (ID3 USLT and SYLT), FLAC and OGG (Vorbis comments), M4A (the lyrics atom).
 * Timed lyrics (SYLT) are turned into the .lrc form, so the player can light the line being sung.
 */
object LyricsTags {
    private const val MAX_ID3 = 4_000_000
    private val latin1 = Charsets.ISO_8859_1

    /** [fallback] is used for text saved in the old single byte way. Null when the file has no lyrics. */
    fun read(context: Context, uri: Uri, fallback: Charset): String? = try {
        context.contentResolver.openInputStream(uri)?.use { raw ->
            val head = ByteArray(12)
            if (readFully(raw, head) < 12) {
                null
            } else {
                // put the 12 bytes back in front, so every reader starts at the first byte of the file
                val full = SequenceInputStream(ByteArrayInputStream(head), raw)
                val start4 = String(head, 0, 4, latin1)
                when {
                    start4.startsWith("ID3") -> id3(full, fallback)
                    start4 == "fLaC" -> flac(full)
                    start4 == "OggS" -> ogg(full)
                    String(head, 4, 4, latin1) == "ftyp" -> mp4(full)
                    else -> null
                }?.trim()?.takeIf { it.isNotBlank() }
            }
        }
    } catch (e: Exception) {
        null
    }

    // ---------------------------------------------------------------- MP3

    private fun id3(input: InputStream, fallback: Charset): String? {
        val header = ByteArray(10)
        if (readFully(input, header) < 10) return null
        val major = header[3].toInt()
        if (major != 3 && major != 4) return null
        val size = synchsafe(header, 6)
        if (size <= 0 || size > MAX_ID3) return null
        val body = ByteArray(size)
        readFully(input, body)
        var p = 0
        if (header[5].toInt() and 0x40 != 0 && size >= 4) {
            // an extended header comes first
            p = if (major == 4) synchsafe(body, 0) else 4 + be32(body, 0)
        }
        var plain: String? = null
        var timed: String? = null
        while (p + 10 <= body.size) {
            if (body[p].toInt() == 0) break
            val id = String(body, p, 4, latin1)
            val fsize = if (major == 4) synchsafe(body, p + 4) else be32(body, p + 4)
            val start = p + 10
            val end = start + fsize
            if (fsize <= 0 || end > body.size) break
            if (id == "USLT" && plain == null) plain = unsynced(body, start, end, fallback)
            if (id == "SYLT" && timed == null) timed = synced(body, start, end, fallback)
            p = end
        }
        return timed ?: plain
    }

    private fun unsynced(b: ByteArray, start: Int, end: Int, fallback: Charset): String? {
        if (end - start < 5) return null
        val enc = b[start].toInt()
        val afterLang = start + 4
        val term = findTerminator(b, afterLang, end, enc)
        val textStart = term + terminatorWidth(enc)
        if (textStart > end) return null
        return decode(b, textStart, end, enc, fallback)
    }

    /** SYLT with times in milliseconds becomes lines like [01:23.45]words. */
    private fun synced(b: ByteArray, start: Int, end: Int, fallback: Charset): String? {
        if (end - start < 7) return null
        val enc = b[start].toInt()
        val format = b[start + 4].toInt()
        if (format != 2) return null // times counted in music frames cannot be turned into time here
        val descEnd = findTerminator(b, start + 6, end, enc)
        var p = descEnd + terminatorWidth(enc)
        val out = StringBuilder()
        while (p < end) {
            val term = findTerminator(b, p, end, enc)
            if (term >= end) break
            val text = decode(b, p, term, enc, fallback).replace("\n", "").replace("\r", "")
            p = term + terminatorWidth(enc)
            if (p + 4 > end) break
            val ms = be32(b, p).toLong() and 0xFFFFFFFFL
            p += 4
            out.append('[').append(stamp(ms)).append(']').append(text).append('\n')
        }
        return out.toString().takeIf { it.isNotBlank() }
    }

    private fun stamp(ms: Long): String {
        val total = ms / 10
        val cs = total % 100
        val s = (total / 100) % 60
        val m = total / 6000
        return String.format("%02d:%02d.%02d", m, s, cs)
    }

    private fun terminatorWidth(enc: Int) = if (enc == 1 || enc == 2) 2 else 1

    private fun findTerminator(b: ByteArray, from: Int, end: Int, enc: Int): Int {
        var i = from
        if (enc == 1 || enc == 2) {
            while (i + 1 < end) {
                if (b[i].toInt() == 0 && b[i + 1].toInt() == 0) return i
                i += 2
            }
            return end
        }
        while (i < end) {
            if (b[i].toInt() == 0) return i
            i++
        }
        return end
    }

    private fun decode(b: ByteArray, from: Int, to: Int, enc: Int, fallback: Charset): String {
        val len = (to - from).coerceAtLeast(0)
        return when (enc) {
            0 -> String(b, from, len, fallback)
            1 -> String(b, from, len, Charsets.UTF_16)
            2 -> String(b, from, len, Charsets.UTF_16BE)
            else -> String(b, from, len, Charsets.UTF_8)
        }
    }

    // ---------------------------------------------------------------- FLAC and OGG

    private fun flac(input: InputStream): String? {
        skipFully(input, 4)
        repeat(64) {
            val h = ByteArray(4)
            if (readFully(input, h) < 4) return null
            val last = h[0].toInt() and 0x80 != 0
            val type = h[0].toInt() and 0x7F
            val len = ((h[1].toInt() and 0xFF) shl 16) or ((h[2].toInt() and 0xFF) shl 8) or (h[3].toInt() and 0xFF)
            if (type == 4 && len in 1..MAX_ID3) {
                val data = ByteArray(len)
                readFully(input, data)
                return vorbisComments(data, 0)
            }
            skipFully(input, len.toLong())
            if (last) return null
        }
        return null
    }

    private fun ogg(input: InputStream): String? {
        val buf = ByteArray(300_000)
        val n = readFully(input, buf)
        val opus = indexOf(buf, n, "OpusTags".toByteArray(latin1))
        if (opus >= 0) return vorbisComments(buf.copyOfRange(0, n), opus + 8)
        val vorbis = indexOf(buf, n, byteArrayOf(3) + "vorbis".toByteArray(latin1))
        if (vorbis >= 0) return vorbisComments(buf.copyOfRange(0, n), vorbis + 7)
        return null
    }

    private fun vorbisComments(d: ByteArray, from: Int): String? {
        var p = from
        if (p + 4 > d.size) return null
        p += 4 + le32(d, p)
        if (p + 4 > d.size) return null
        val count = le32(d, p)
        p += 4
        var plain: String? = null
        var timed: String? = null
        for (i in 0 until count) {
            if (p + 4 > d.size) break
            val len = le32(d, p)
            p += 4
            if (len < 0 || p + len > d.size) break
            val entry = String(d, p, len, Charsets.UTF_8)
            p += len
            val eq = entry.indexOf('=')
            if (eq <= 0) continue
            val value = entry.substring(eq + 1)
            when (entry.substring(0, eq).uppercase()) {
                "SYNCEDLYRICS" -> timed = value
                "LYRICS", "UNSYNCEDLYRICS", "UNSYNCED LYRICS" -> if (plain == null) plain = value
            }
        }
        return timed ?: plain
    }

    // ---------------------------------------------------------------- M4A

    private fun mp4(input: InputStream): String? {
        repeat(200) {
            val h = ByteArray(8)
            if (readFully(input, h) < 8) return null
            var size = be32(h, 0).toLong() and 0xFFFFFFFFL
            val type = String(h, 4, 4, latin1)
            var headerLen = 8L
            if (size == 1L) {
                val ext = ByteArray(8)
                if (readFully(input, ext) < 8) return null
                size = 0
                for (b in ext) size = (size shl 8) or (b.toLong() and 0xFF)
                headerLen = 16
            }
            if (size < headerLen) return null
            val payload = size - headerLen
            if (type == "moov") {
                if (payload > 16_000_000) return null
                val data = ByteArray(payload.toInt())
                readFully(input, data)
                return findLyricsAtom(data, 0, data.size)
            }
            skipFully(input, payload)
        }
        return null
    }

    private fun findLyricsAtom(d: ByteArray, from: Int, to: Int): String? {
        var p = from
        while (p + 8 <= to) {
            val size = be32(d, p)
            val type = String(d, p + 4, 4, latin1)
            if (size < 8 || p + size > to) return null
            when (type) {
                "udta", "ilst" -> findLyricsAtom(d, p + 8, p + size)?.let { return it }
                "meta" -> findLyricsAtom(d, p + 12, p + size)?.let { return it }
                "\u00A9lyr" -> {
                    var q = p + 8
                    while (q + 8 <= p + size) {
                        val ds = be32(d, q)
                        if (ds < 8) break
                        if (String(d, q + 4, 4, latin1) == "data" && ds >= 16 && q + ds <= p + size) {
                            return String(d, q + 16, ds - 16, Charsets.UTF_8).trim().takeIf { it.isNotBlank() }
                        }
                        q += ds
                    }
                }
            }
            p += size
        }
        return null
    }

    // ---------------------------------------------------------------- small helpers

    private fun readFully(input: InputStream, buf: ByteArray, off: Int = 0, len: Int = buf.size - off): Int {
        var total = 0
        while (total < len) {
            val n = input.read(buf, off + total, len - total)
            if (n < 0) break
            total += n
        }
        return total
    }

    private fun skipFully(input: InputStream, count: Long) {
        var left = count
        val sink = ByteArray(8192)
        while (left > 0) {
            val skipped = input.skip(left)
            if (skipped > 0) {
                left -= skipped
            } else {
                val n = input.read(sink, 0, minOf(left, sink.size.toLong()).toInt())
                if (n < 0) return
                left -= n
            }
        }
    }

    private fun indexOf(buf: ByteArray, len: Int, pattern: ByteArray): Int {
        outer@ for (i in 0..(len - pattern.size)) {
            for (j in pattern.indices) if (buf[i + j] != pattern[j]) continue@outer
            return i
        }
        return -1
    }

    private fun synchsafe(b: ByteArray, o: Int) =
        ((b[o].toInt() and 0x7F) shl 21) or ((b[o + 1].toInt() and 0x7F) shl 14) or ((b[o + 2].toInt() and 0x7F) shl 7) or (b[o + 3].toInt() and 0x7F)

    private fun be32(b: ByteArray, o: Int) =
        ((b[o].toInt() and 0xFF) shl 24) or ((b[o + 1].toInt() and 0xFF) shl 16) or ((b[o + 2].toInt() and 0xFF) shl 8) or (b[o + 3].toInt() and 0xFF)

    private fun le32(b: ByteArray, o: Int) =
        (b[o].toInt() and 0xFF) or ((b[o + 1].toInt() and 0xFF) shl 8) or ((b[o + 2].toInt() and 0xFF) shl 16) or ((b[o + 3].toInt() and 0xFF) shl 24)
}
