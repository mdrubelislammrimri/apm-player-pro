package app.apmplayer.playback

import android.content.ComponentName
import android.content.Context
import androidx.core.content.ContextCompat
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import app.apmplayer.data.TrackWithArtist
import app.apmplayer.util.codecLabel
import kotlinx.coroutines.Job
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

data class PlayerUiState(
    val hasMedia: Boolean = false,
    val mediaId: String? = null,
    val uri: String? = null,
    val title: String = "",
    val artist: String = "",
    val isPlaying: Boolean = false,
    val positionMs: Long = 0,
    val durationMs: Long = 0,
    val repeatMode: Int = Player.REPEAT_MODE_OFF,
    val shuffle: Boolean = false,
    val sampleRate: Int = 0,
    val channels: Int = 0,
    val queueIndex: Int = 0,
    val queueSize: Int = 0,
    val bitrateBps: Int = 0,
    val codec: String = "",
    val sleepEndsAtMs: Long = 0,
)

/** What the screens talk to. Hides the media session and exposes one state they can watch. */
class PlayerConnection(private val context: Context) {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private val _state = MutableStateFlow(PlayerUiState())
    val state: StateFlow<PlayerUiState> = _state.asStateFlow()

    private var controller: MediaController? = null
    /** Called once per song when enough of it has played (the "count as played" setting, half by default). */
    var onCounted: ((Long) -> Unit)? = null
    @Volatile var countPercent = 50

    /** Called about every 5 seconds with the song id, position and length, to remember where a long song stopped. */
    var onProgress: ((Long, Long, Long) -> Unit)? = null
    private var lastProgressAt = 0L

    /** Fade length for play and pause in milliseconds. 0 means no fade. */

    /** Called when another song starts, with its file address. */
    var onSongChanged: ((String?) -> Unit)? = null
    private var lastSongId: String? = null

    /** On: the volume knob is the phone's own volume, the player itself stays at full volume. */
    @Volatile var useSystemVolume = false

    /** On: the previous button first goes back to the start of the song, then to the song before. */
    @Volatile var prevResets = false
    private var baseVolume = 1f
    private var countedMediaId: String? = null
    private var sleepEndsAtMs = 0L
    private var sleepJob: Job? = null
    private val waiting = mutableListOf<(MediaController) -> Unit>()

    private val listener = object : Player.Listener {
        override fun onEvents(player: Player, events: Player.Events) = publish()
    }

    init {
        val token = SessionToken(context, ComponentName(context, PlaybackService::class.java))
        val future = MediaController.Builder(context, token).buildAsync()
        future.addListener({
            val c = future.get()
            controller = c
            c.addListener(listener)
            publish()
            waiting.forEach { it(c) }
            waiting.clear()
        }, ContextCompat.getMainExecutor(context))

        // Playback position does not send events, so look at it twice a second while playing.
        scope.launch {
            while (isActive) {
                delay(500)
                if (controller?.isPlaying == true) publish()
            }
        }
    }

    /** Puts songs in the player and stops there, at the place given, without playing. */
    fun load(tracks: List<TrackWithArtist>, startIndex: Int, startPositionMs: Long) = withController { c ->
        c.setMediaItems(tracks.map { it.toMediaItem(artworkFor(it.track.id, it.track.uri)) }, startIndex, startPositionMs)
        c.prepare()
    }

    fun play(tracks: List<TrackWithArtist>, startIndex: Int, shuffle: Boolean, startPositionMs: Long = 0L) = withController { c ->
        c.shuffleModeEnabled = shuffle
        c.setMediaItems(tracks.map { it.toMediaItem(artworkFor(it.track.id, it.track.uri)) }, startIndex, startPositionMs)
        c.prepare()
        c.play()
    }

    /** The cover address for the notification: a picture chosen by the user, or the song file itself. */
    private fun artworkFor(trackId: Long, trackUri: String): android.net.Uri {
        val mine = java.io.File(context.filesDir, "art/$trackId.jpg")
        return if (mine.exists()) android.net.Uri.fromFile(mine) else android.net.Uri.parse(trackUri)
    }

    /** Starts playing what is loaded, if anything is. */
    fun resume() = withController { c -> if (c.mediaItemCount > 0) c.play() }

    /** Play or pause. The fade in and out is done by the player service, so a headset or the notification fade too. */
    fun togglePlayPause() = withController { c ->
        if (c.isPlaying) c.pause() else c.play()
    }


    fun next() = withController { it.seekToNextMediaItem() }
    fun previous() = withController { if (prevResets) it.seekToPrevious() else it.seekToPreviousMediaItem() }
    fun seekTo(ms: Long) = withController { it.seekTo(ms) }
    fun setSpeed(speed: Float) = withController { it.setPlaybackSpeed(speed) }
    fun setVolume(volume: Float) {
        baseVolume = if (useSystemVolume) 1f else volume
        withController { it.volume = baseVolume }
    }
    fun seekBy(deltaMs: Long) = withController { c ->
        val target = (c.currentPosition + deltaMs).coerceAtLeast(0L)
        val duration = c.duration
        c.seekTo(if (duration != C.TIME_UNSET) target.coerceAtMost(duration) else target)
    }

    /** Takes the song that is playing out of the queue (after its file was deleted). */
    fun removeCurrent() = withController { c ->
        val i = c.currentMediaItemIndex
        if (i >= 0 && c.mediaItemCount > 0) c.removeMediaItem(i)
    }

    /** Pauses the music after the given minutes. Null cancels the timer. */
    fun setSleepTimer(minutes: Int?) {
        sleepJob?.cancel()
        sleepJob = null
        if (minutes == null) {
            sleepEndsAtMs = 0L
        } else {
            sleepEndsAtMs = System.currentTimeMillis() + minutes * 60_000L
            sleepJob = scope.launch {
                delay(minutes * 60_000L)
                withController { it.pause() }
                sleepEndsAtMs = 0L
                publish()
            }
        }
        publish()
    }

    /** Jumps to the given place in the queue and plays it. */
    fun seekToItem(index: Int) = withController { c ->
        if (index in 0 until c.mediaItemCount) {
            c.seekTo(index, 0L)
            c.play()
        }
    }

    fun toggleShuffle() = withController { it.shuffleModeEnabled = !it.shuffleModeEnabled }

    fun cycleRepeat() = withController {
        it.repeatMode = when (it.repeatMode) {
            Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
            Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
            else -> Player.REPEAT_MODE_OFF
        }
    }

    private fun withController(block: (MediaController) -> Unit) {
        val c = controller
        if (c != null) block(c) else waiting += block
    }



    private fun publish() {
        val c = controller ?: return
        val item = c.currentMediaItem
        val duration = c.duration.takeIf { it != C.TIME_UNSET && it > 0 }
            ?: item?.mediaMetadata?.durationMs
            ?: 0L
        // count a song as played once when its position passes half
        val currentId = item?.mediaId
        if (currentId != lastSongId) {
            lastSongId = currentId
            onSongChanged?.invoke(item?.localConfiguration?.uri?.toString())
        }
        // near the start again (a new song or a repeat) means it can be counted again
        if (c.currentPosition < 2_000L) countedMediaId = null
        if (currentId != null && currentId != countedMediaId && duration > 0 && c.currentPosition >= duration * countPercent / 100) {
            countedMediaId = currentId
            currentId.toLongOrNull()?.let { onCounted?.invoke(it) }
        }
        // remember the place in long songs now and then
        val now = System.currentTimeMillis()
        if (currentId != null && duration > 0 && c.isPlaying && now - lastProgressAt > 5_000L) {
            lastProgressAt = now
            currentId.toLongOrNull()?.let { onProgress?.invoke(it, c.currentPosition, duration) }
        }
        val audioFormat = c.currentTracks.groups
            .firstOrNull { it.type == C.TRACK_TYPE_AUDIO && it.isSelected }
            ?.getTrackFormat(0)
        _state.value = PlayerUiState(
            hasMedia = item != null,
            mediaId = item?.mediaId,
            uri = item?.localConfiguration?.uri?.toString(),
            title = item?.mediaMetadata?.title?.toString().orEmpty(),
            artist = item?.mediaMetadata?.artist?.toString().orEmpty(),
            isPlaying = c.isPlaying,
            positionMs = c.currentPosition.coerceAtLeast(0),
            durationMs = duration,
            repeatMode = c.repeatMode,
            shuffle = c.shuffleModeEnabled,
            sampleRate = audioFormat?.sampleRate?.takeIf { it > 0 } ?: 0,
            channels = audioFormat?.channelCount?.takeIf { it > 0 } ?: 0,
            queueIndex = c.currentMediaItemIndex.coerceAtLeast(0),
            queueSize = c.mediaItemCount,
            bitrateBps = audioFormat?.bitrate?.takeIf { it > 0 } ?: 0,
            codec = audioFormat?.let { codecLabel(it.sampleMimeType, it.codecs) }.orEmpty(),
            sleepEndsAtMs = sleepEndsAtMs,
        )
    }
}

fun TrackWithArtist.toMediaItem(artwork: android.net.Uri): MediaItem =
    MediaItem.Builder()
        .setMediaId(track.id.toString())
        .setUri(track.uri)
        .setMediaMetadata(
            MediaMetadata.Builder()
                .setTitle(track.title)
                .setArtist(artistName)
                .setDurationMs(track.durationMs)
                .setArtworkUri(artwork)
                .setExtras(android.os.Bundle().apply {
                    putLong("albumId", track.albumId ?: -1L)
                    putInt("trackNo", track.trackNo ?: -1)
                })
                .build()
        )
        .build()
