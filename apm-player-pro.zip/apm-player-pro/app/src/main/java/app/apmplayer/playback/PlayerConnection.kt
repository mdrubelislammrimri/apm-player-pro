package app.apmplayer.playback

import android.content.ComponentName
import android.content.Context
import androidx.core.content.ContextCompat
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import app.apmplayer.data.TrackWithArtist
import app.apmplayer.util.codecLabel
import kotlinx.coroutines.Job
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

data class PlayerUiState(
    val hasMedia: Boolean = false,
    val mediaId: String? = null,
    val title: String = "",
    val artist: String = "",
    val isPlaying: Boolean = false,
    val positionMs: Long = 0,
    val durationMs: Long = 0,
    val repeatMode: Int = Player.REPEAT_MODE_OFF,
    val shuffle: Boolean = false,
    val sampleRate: Int = 0,
    val bitrateBps: Int = 0,
    val codec: String = "",
    val sleepEndsAtMs: Long = 0,
)

/** What the screens talk to. Hides the media session and exposes one state they can watch. */
class PlayerConnection(private val context: Context) {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private val _state = MutableStateFlow(PlayerUiState())
    val state: StateFlow<PlayerUiState> = _state.asStateFlow()

    private var controller: MediaController? = null
    /** Called once per song when half of it has played (the original's default for "count as played"). */
    var onCounted: ((Long) -> Unit)? = null
    private var countedMediaId: String? = null
    private var sleepEndsAtMs = 0L
    private var sleepJob: Job? = null
    private val waiting = mutableListOf<(MediaController) -> Unit>()

    private val listener = object : Player.Listener {
        override fun onEvents(player: Player, events: Player.Events) = publish()
    }

    init {
        val token = SessionToken(context, ComponentName(context, PlaybackService::class.java))
        val future = MediaController.Builder(context, token).buildAsync()
        future.addListener({
            val c = future.get()
            controller = c
            c.addListener(listener)
            publish()
            waiting.forEach { it(c) }
            waiting.clear()
        }, ContextCompat.getMainExecutor(context))

        // Playback position does not send events, so look at it twice a second while playing.
        scope.launch {
            while (isActive) {
                delay(500)
                if (controller?.isPlaying == true) publish()
            }
        }
    }

    fun play(tracks: List<TrackWithArtist>, startIndex: Int, shuffle: Boolean, startPositionMs: Long = 0L) = withController { c ->
        c.shuffleModeEnabled = shuffle
        c.setMediaItems(tracks.map { it.toMediaItem() }, startIndex, startPositionMs)
        c.prepare()
        c.play()
    }

    fun togglePlayPause() = withController { if (it.isPlaying) it.pause() else it.play() }
    fun next() = withController { it.seekToNextMediaItem() }
    fun previous() = withController { it.seekToPreviousMediaItem() }
    fun seekTo(ms: Long) = withController { it.seekTo(ms) }
    fun setSpeed(speed: Float) = withController { it.setPlaybackSpeed(speed) }
    fun setVolume(volume: Float) = withController { it.volume = volume }
    fun seekBy(deltaMs: Long) = withController { c ->
        val target = (c.currentPosition + deltaMs).coerceAtLeast(0L)
        val duration = c.duration
        c.seekTo(if (duration != C.TIME_UNSET) target.coerceAtMost(duration) else target)
    }

    /** Takes the song that is playing out of the queue (after its file was deleted). */
    fun removeCurrent() = withController { c ->
        val i = c.currentMediaItemIndex
        if (i >= 0 && c.mediaItemCount > 0) c.removeMediaItem(i)
    }

    /** Pauses the music after the given minutes. Null cancels the timer. */
    fun setSleepTimer(minutes: Int?) {
        sleepJob?.cancel()
        sleepJob = null
        if (minutes == null) {
            sleepEndsAtMs = 0L
        } else {
            sleepEndsAtMs = System.currentTimeMillis() + minutes * 60_000L
            sleepJob = scope.launch {
                delay(minutes * 60_000L)
                withController { it.pause() }
                sleepEndsAtMs = 0L
                publish()
            }
        }
        publish()
    }

    /** Jumps to the given place in the queue and plays it. */
    fun seekToItem(index: Int) = withController { c ->
        if (index in 0 until c.mediaItemCount) {
            c.seekTo(index, 0L)
            c.play()
        }
    }

    fun toggleShuffle() = withController { it.shuffleModeEnabled = !it.shuffleModeEnabled }

    fun cycleRepeat() = withController {
        it.repeatMode = when (it.repeatMode) {
            Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
            Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
            else -> Player.REPEAT_MODE_OFF
        }
    }

    private fun withController(block: (MediaController) -> Unit) {
        val c = controller
        if (c != null) block(c) else waiting += block
    }

    private fun publish() {
        val c = controller ?: return
        val item = c.currentMediaItem
        val duration = c.duration.takeIf { it != C.TIME_UNSET && it > 0 }
            ?: item?.mediaMetadata?.durationMs
            ?: 0L
        // count a song as played once when its position passes half
        val currentId = item?.mediaId
        // near the start again (a new song or a repeat) means it can be counted again
        if (c.currentPosition < 2_000L) countedMediaId = null
        if (currentId != null && currentId != countedMediaId && duration > 0 && c.currentPosition >= duration / 2) {
            countedMediaId = currentId
            currentId.toLongOrNull()?.let { onCounted?.invoke(it) }
        }
        val audioFormat = c.currentTracks.groups
            .firstOrNull { it.type == C.TRACK_TYPE_AUDIO && it.isSelected }
            ?.getTrackFormat(0)
        _state.value = PlayerUiState(
            hasMedia = item != null,
            mediaId = item?.mediaId,
            title = item?.mediaMetadata?.title?.toString().orEmpty(),
            artist = item?.mediaMetadata?.artist?.toString().orEmpty(),
            isPlaying = c.isPlaying,
            positionMs = c.currentPosition.coerceAtLeast(0),
            durationMs = duration,
            repeatMode = c.repeatMode,
            shuffle = c.shuffleModeEnabled,
            sampleRate = audioFormat?.sampleRate?.takeIf { it > 0 } ?: 0,
            bitrateBps = audioFormat?.bitrate?.takeIf { it > 0 } ?: 0,
            codec = audioFormat?.let { codecLabel(it.sampleMimeType, it.codecs) }.orEmpty(),
            sleepEndsAtMs = sleepEndsAtMs,
        )
    }
}

private fun TrackWithArtist.toMediaItem(): MediaItem =
    MediaItem.Builder()
        .setMediaId(track.id.toString())
        .setUri(track.uri)
        .setMediaMetadata(
            MediaMetadata.Builder()
                .setTitle(track.title)
                .setArtist(artistName)
                .setDurationMs(track.durationMs)
                .build()
        )
        .build()
