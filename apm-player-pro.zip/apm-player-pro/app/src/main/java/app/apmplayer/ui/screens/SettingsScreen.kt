package app.apmplayer.ui.screens

import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.automirrored.rounded.VolumeUp
import androidx.compose.material.icons.rounded.Folder
import androidx.compose.material.icons.rounded.GraphicEq
import androidx.compose.material.icons.rounded.Headphones
import androidx.compose.material.icons.rounded.Image
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.Layers
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.MoreHoriz
import androidx.compose.material.icons.rounded.Wallpaper
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import app.apmplayer.ui.components.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import app.apmplayer.AppContainer
import app.apmplayer.settings.PrefsBackup
import app.apmplayer.ui.components.SettingAction
import app.apmplayer.ui.components.focusRing
import app.apmplayer.ui.theme.Apm
import app.apmplayer.ui.theme.ApmShape
import app.apmplayer.ui.theme.ApmSpace

data class SettingsGroup(
    val id: String, val title: String, val subtitle: String, val icon: ImageVector, val tint: Color,
)

/** In the same order as the original. The menu shortcuts use the last five. */
val settingsGroups = listOf(
    SettingsGroup("look", "Look and Feel", "Skin, font, player screen, lyrics, lists, animations, orientation", Icons.Rounded.Layers, Color(0xFF8E7CC3)),
    SettingsGroup("audio", "Audio", "Audio info, fade on play and pause, reset sound", Icons.AutoMirrored.Rounded.VolumeUp, Color(0xFFE0788C)),
    SettingsGroup("visualization", "Visualization", "Faded controls opacity, timeout, automatic style", Icons.Rounded.GraphicEq, Color(0xFF9C6FD6)),
    SettingsGroup("background", "Background", "Cover colour wash: intensity, saturation, details", Icons.Rounded.Wallpaper, Color(0xFF4F9C94)),
    SettingsGroup("albumart", "Album Art", "Default image, square cover, cache", Icons.Rounded.Image, Color(0xFF5CA85C)),
    SettingsGroup("library", "Library", "Rescan, music folders, short tracks, progress", Icons.Rounded.Folder, Color(0xFF4A78C2)),
    SettingsGroup("headset", "Headset/Bluetooth", "Pause when headphones are unplugged", Icons.Rounded.Headphones, Color(0xFF8C7A86)),
    SettingsGroup("lock", "Lock Screen", "Show the player over the lock screen", Icons.Rounded.Lock, Color(0xFFE08A3C)),
    SettingsGroup("misc", "Misc", "Restore default settings", Icons.Rounded.MoreHoriz, Color(0xFF3FA7B5)),
    SettingsGroup("about", "About", "Version, licences, privacy", Icons.Rounded.Info, Color(0xFF9A9AD0)),
)

@Composable
fun SettingsScreen(container: AppContainer, onBack: () -> Unit, onOpenGroup: (String) -> Unit) {
    val context = LocalContext.current
    // all choices in one text file: save it somewhere, or read one back
    val exportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) {
            val ok = try {
                context.contentResolver.openOutputStream(uri)?.use { it.write(PrefsBackup.export(context).toByteArray(Charsets.UTF_8)) } != null
            } catch (e: Exception) {
                false
            }
            Toast.makeText(context, if (ok) "Settings saved" else "Could not save the file", Toast.LENGTH_SHORT).show()
        }
    }
    val importLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            val text = try {
                context.contentResolver.openInputStream(uri)?.use { it.readBytes().toString(Charsets.UTF_8) }
            } catch (e: Exception) {
                null
            }
            val ok = text != null && PrefsBackup.import(context, text)
            if (ok) {
                container.settings.reload()
                container.sound.reload()
            }
            Toast.makeText(context, if (ok) "Settings loaded" else "That file is not a settings backup", Toast.LENGTH_SHORT).show()
        }
    }

    Column(Modifier.fillMaxSize()) {
        TopBar("Settings", onBack)
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
            Text(
                "Settings", style = Apm.type.bodySm.copy(fontWeight = FontWeight.Bold), color = Apm.colors.accent,
                modifier = Modifier.padding(horizontal = ApmSpace.s4, vertical = ApmSpace.s3),
            )
            settingsGroups.forEach { g ->
                SettingsRow(g.icon, g.tint, g.title, g.subtitle) { onOpenGroup(g.id) }
            }
            Text(
                "Other", style = Apm.type.bodySm.copy(fontWeight = FontWeight.Bold), color = Apm.colors.accent,
                modifier = Modifier.padding(horizontal = ApmSpace.s4, vertical = ApmSpace.s3),
            )
            SettingAction("Export Settings/Data", "Save every choice, sound setting and preset to a text file") {
                exportLauncher.launch("apm-player-settings.json")
            }
            SettingAction("Import Settings/Data", "Read a file saved by Export") {
                importLauncher.launch(arrayOf("application/json", "text/plain", "*/*"))
            }
        }
    }
}

@Composable
fun SettingsDetailScreen(groupId: String, container: AppContainer, onBack: () -> Unit, onOpen: (String) -> Unit) {
    val s by container.settings.state.collectAsStateWithLifecycle()
    val title = when (groupId) {
        "audioinfo" -> "Audio Info"
        "musicfolders" -> "Music Folders"
        "look_player" -> "Player Screen"
        "look_lyrics" -> "Lyrics"
        "look_notif" -> "Notifications"
        "look_lists" -> "List options"
        else -> settingsGroups.firstOrNull { it.id == groupId }?.title ?: "Settings"
    }
    Column(Modifier.fillMaxSize()) {
        TopBar(title, onBack)
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
            SettingsPageContent(groupId, container, s, onOpen)
        }
    }
}

@Composable
private fun TopBar(title: String, onBack: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().heightIn(min = 64.dp).padding(horizontal = ApmSpace.s2),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(ApmSpace.s2),
    ) {
        IconButton(onClick = onBack) {
            Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "Back", tint = Color.White)
        }
        Text(title, style = Apm.type.title, color = Color.White)
    }
}

@Composable
private fun SettingsRow(icon: ImageVector, tint: Color, title: String, subtitle: String, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().heightIn(min = 80.dp).focusRing(ApmShape.md)
            .clickable(role = Role.Button, onClick = onClick)
            .padding(horizontal = ApmSpace.s4, vertical = ApmSpace.s2),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(ApmSpace.s4),
    ) {
        Icon(icon, contentDescription = null, tint = tint, modifier = Modifier.size(36.dp))
        Column(Modifier.weight(1f)) {
            Text(title, style = Apm.type.title.copy(fontWeight = FontWeight.Medium), color = Color.White)
            Text(subtitle, style = Apm.type.bodySm, color = Color(0xFFB0B0B0))
        }
    }
}
