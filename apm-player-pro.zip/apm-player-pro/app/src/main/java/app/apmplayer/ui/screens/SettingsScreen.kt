package app.apmplayer.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.automirrored.rounded.VolumeUp
import androidx.compose.material.icons.rounded.Folder
import androidx.compose.material.icons.rounded.GraphicEq
import androidx.compose.material.icons.rounded.Headphones
import androidx.compose.material.icons.rounded.Image
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.Layers
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.MoreHoriz
import androidx.compose.material.icons.rounded.Wallpaper
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import app.apmplayer.AppContainer
import app.apmplayer.ui.components.focusRing
import app.apmplayer.ui.theme.Apm
import app.apmplayer.ui.theme.ApmShape
import app.apmplayer.ui.theme.ApmSpace

private data class SettingsGroup(
    val id: String, val title: String, val subtitle: String, val icon: ImageVector, val tint: Color,
)

private val groups = listOf(
    SettingsGroup("look", "Look and Feel", "Skin, player interface, language, notifications", Icons.Rounded.Layers, Color(0xFF8E7CC3)),
    SettingsGroup("audio", "Audio", "Crossfade, replay gain, volume, output", Icons.AutoMirrored.Rounded.VolumeUp, Color(0xFFE0788C)),
    SettingsGroup("visualization", "Visualization", "Faded controls opacity, preset duration", Icons.Rounded.GraphicEq, Color(0xFF9C6FD6)),
    SettingsGroup("background", "Background", "Blur, details, intensity, saturation", Icons.Rounded.Wallpaper, Color(0xFF4F9C94)),
    SettingsGroup("albumart", "Album Art", "Download, quality, cache cleanup", Icons.Rounded.Image, Color(0xFF5CA85C)),
    SettingsGroup("library", "Library", "Rescan, music folders, list, queue options", Icons.Rounded.Folder, Color(0xFF4A78C2)),
    SettingsGroup("headset", "Headset/Bluetooth", "Pause/resume on connection, headset buttons", Icons.Rounded.Headphones, Color(0xFF8C7A86)),
    SettingsGroup("lock", "Lock Screen", "Lock screen options", Icons.Rounded.Lock, Color(0xFFE08A3C)),
    SettingsGroup("misc", "Misc", "Scrobbling, other tweaks", Icons.Rounded.MoreHoriz, Color(0xFF3FA7B5)),
    SettingsGroup("about", "About", "Version, changelog", Icons.Rounded.Info, Color(0xFF9A9AD0)),
)

@Composable
fun SettingsScreen(onBack: () -> Unit, onOpenGroup: (String) -> Unit) {
    Column(Modifier.fillMaxSize()) {
        TopBar("Settings", onBack)
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
            Text(
                "Settings", style = Apm.type.bodySm.copy(fontWeight = FontWeight.Bold), color = Apm.colors.accent,
                modifier = Modifier.padding(horizontal = ApmSpace.s4, vertical = ApmSpace.s3),
            )
            groups.forEach { g ->
                SettingsRow(g.icon, g.tint, g.title, g.subtitle) { onOpenGroup(g.id) }
            }
        }
    }
}

@Composable
fun SettingsDetailScreen(groupId: String, container: AppContainer, onBack: () -> Unit) {
    val group = groups.firstOrNull { it.id == groupId }
    val scanning by container.repository.isScanning.collectAsStateWithLifecycle()
    Column(Modifier.fillMaxSize()) {
        TopBar(group?.title ?: "Settings", onBack)
        if (groupId == "library") {
            SettingsRow(
                Icons.Rounded.Folder, Color(0xFF4A78C2), "Rescan library",
                if (scanning) "Scanning now…" else "Look for new and removed music files",
            ) { container.repository.startScan() }
        } else {
            Text(
                "These options are not built yet.", style = Apm.type.bodySm, color = Apm.colors.textMuted,
                modifier = Modifier.padding(ApmSpace.s5),
            )
        }
    }
}

@Composable
private fun TopBar(title: String, onBack: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().heightIn(min = 64.dp).padding(horizontal = ApmSpace.s2),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(ApmSpace.s2),
    ) {
        IconButton(onClick = onBack) {
            Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "Back", tint = Color.White)
        }
        Text(title, style = Apm.type.title, color = Color.White)
    }
}

@Composable
private fun SettingsRow(icon: ImageVector, tint: Color, title: String, subtitle: String, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().heightIn(min = 80.dp).focusRing(ApmShape.md)
            .clickable(role = Role.Button, onClick = onClick)
            .padding(horizontal = ApmSpace.s4, vertical = ApmSpace.s2),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(ApmSpace.s4),
    ) {
        Icon(icon, contentDescription = null, tint = tint, modifier = Modifier.size(36.dp))
        Column(Modifier.weight(1f)) {
            Text(title, style = Apm.type.title.copy(fontWeight = FontWeight.Medium), color = Color.White)
            Text(subtitle, style = Apm.type.bodySm, color = Color(0xFFB0B0B0))
        }
    }
}
