@file:androidx.annotation.OptIn(androidx.media3.common.util.UnstableApi::class)

package app.apmplayer.playback

import android.content.SharedPreferences
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import app.apmplayer.audio.SoundEngine
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

/**
 * All the fading of the player (Settings, Audio, Crossfade, Fade, and Gapless).
 *
 * The sound of a player is multiplied by a "fade" number between 0 and 1 inside the sound processor, and this class moves that number:
 * - on play, pause and seek: a short fade, so there is no click
 * - when the song is changed by hand: the old sound dips, the new one fades in
 * - when a song ends by itself: a real crossfade. A second player plays the end of the song that is ending while the main player
 *   moves to the next song, and the two sounds are faded across each other.
 *
 * If the second player is not ready in time, nothing special happens and the next song starts as it normally would.
 * Every call must come from the main thread.
 */
class FadeEngine(
    private val a: ExoPlayer,
    private val createSecondPlayer: () -> ExoPlayer,
    private val prefs: () -> SharedPreferences,
) {
    private val handler = Handler(Looper.getMainLooper())
    private var b: ExoPlayer? = null

    private enum class Slot { A, B }

    private class Ramp(
        val slot: Slot,
        val from: Double,
        val to: Double,
        val start: Long,
        val ms: Long,
        val equalPower: Boolean,
        val onDone: (() -> Unit)?,
    )

    private val ramps = ArrayList<Ramp>()
    private val ticker = object : Runnable {
        override fun run() {
            tick()
            if (ramps.isNotEmpty()) handler.postDelayed(this, 16)
        }
    }

    // state of a crossfade
    private var overlap = false
    private var preparedId: String? = null
    private var secondReady = false
    private var secondStartAt = 0L

    private val gapResume = Runnable { a.play() }

    private fun int(key: String, default: Int) = prefs().getInt(key, default)
    private fun bool(key: String, default: Boolean) = prefs().getBoolean(key, default)
    private val bypass get() = SoundEngine.bypass

    init {
        a.addListener(object : Player.Listener {
            override fun onIsPlayingChanged(isPlaying: Boolean) {
                if (isPlaying) {
                    // playback started some other way than the play button (audio focus, a headset): make sure the sound is not left at 0
                    if (!ramps.any { it.slot == Slot.A } && SoundEngine.fadeA < 0.999 && !overlap) ramp(Slot.A, 1.0, int("playPauseFadeMs", 400))
                    handler.removeCallbacks(autoCheck)
                    handler.post(autoCheck)
                }
            }

            override fun onPlayWhenReadyChanged(playWhenReady: Boolean, reason: Int) {
                // Silence Between Tracks: the player pauses at the end of a song, and goes on after the silence
                if (!playWhenReady && reason == Player.PLAY_WHEN_READY_CHANGE_REASON_END_OF_MEDIA_ITEM) {
                    handler.removeCallbacks(gapResume)
                    handler.postDelayed(gapResume, int("silenceMs", 0).toLong())
                } else {
                    handler.removeCallbacks(gapResume)
                }
            }
        })
        applyConfig()
    }

    /** Called when the settings change: preload of the next song and the silence between songs. */
    fun applyConfig() {
        val preload = int("preloadMs", 0)
        a.preloadConfiguration = ExoPlayer.PreloadConfiguration(if (preload > 0) preload * 1000L else C.TIME_UNSET)
        a.pauseAtEndOfMediaItems = int("silenceMs", 0) > 0
    }

    // ---------------------------------------------------------------- the fade number

    private fun value(slot: Slot) = if (slot == Slot.A) SoundEngine.fadeA else SoundEngine.fadeB

    private fun set(slot: Slot, v: Double) {
        if (slot == Slot.A) SoundEngine.fadeA = v else SoundEngine.fadeB = v
    }

    private fun ramp(slot: Slot, to: Double, ms: Int, equalPower: Boolean = false, onDone: (() -> Unit)? = null) {
        ramps.removeAll { it.slot == slot }
        if (ms <= 0 || bypass) {
            set(slot, to)
            onDone?.invoke()
            return
        }
        ramps.add(Ramp(slot, value(slot), to, SystemClock.uptimeMillis(), ms.toLong(), equalPower, onDone))
        handler.removeCallbacks(ticker)
        handler.post(ticker)
    }

    private fun tick() {
        val now = SystemClock.uptimeMillis()
        val finished = ArrayList<Ramp>()
        for (r in ramps.toList()) {
            val t = ((now - r.start).toDouble() / r.ms).coerceIn(0.0, 1.0)
            // equal power: two sounds crossing keep the same loudness
            val k = if (!r.equalPower) t else if (r.to >= r.from) sin(t * PI / 2) else 1.0 - cos(t * PI / 2)
            set(r.slot, r.from + (r.to - r.from) * k)
            if (t >= 1.0) finished.add(r)
        }
        ramps.removeAll(finished)
        finished.forEach { it.onDone?.invoke() }
    }

    // ---------------------------------------------------------------- play, pause, seek

    fun play(doPlay: () -> Unit) {
        handler.removeCallbacks(gapResume)
        if (overlap) abortOverlap()
        if (a.isPlaying) {
            // a pause was still fading out
            ramp(Slot.A, 1.0, int("playPauseFadeMs", 400))
            return
        }
        if (bool("fadePlayPause", true) && !bypass) {
            ramps.removeAll { it.slot == Slot.A }
            SoundEngine.fadeA = 0.0
            doPlay()
            ramp(Slot.A, 1.0, int("playPauseFadeMs", 400))
        } else {
            ramps.removeAll { it.slot == Slot.A }
            SoundEngine.fadeA = 1.0
            doPlay()
        }
    }

    fun pause(doPause: () -> Unit) {
        handler.removeCallbacks(gapResume)
        if (overlap) abortOverlap()
        if (!a.playWhenReady || !bool("fadePlayPause", true) || bypass) {
            doPause()
            return
        }
        // the sound is left at 0 while paused, play brings it back
        ramp(Slot.A, 0.0, int("playPauseFadeMs", 400)) { doPause() }
    }

    fun seek(doSeek: () -> Unit) {
        if (overlap) abortOverlap()
        dropPrepared()
        if (!bool("fadeOnSeek", true) || !a.isPlaying || bypass) {
            doSeek()
            return
        }
        val ms = int("seekFadeMs", 100)
        ramp(Slot.A, 0.0, ms) {
            doSeek()
            ramp(Slot.A, 1.0, ms)
        }
    }

    /** The song is changed by hand: next, previous, or a song picked from a list. */
    fun change(doChange: () -> Unit) {
        if (overlap) abortOverlap()
        dropPrepared()
        val mode = int("manualFading", 1)
        if (mode == 0 || !a.isPlaying || bypass) {
            doChange()
            return
        }
        val fadeIn = if (mode == 1) int("shortCrossfadeMs", 400) else int("crossfadeMs", 5000)
        ramp(Slot.A, 0.0, min(120, fadeIn)) {
            doChange()
            ramp(Slot.A, 1.0, fadeIn)
        }
    }

    // ---------------------------------------------------------------- a song ends by itself: real crossfade

    private val autoCheck = object : Runnable {
        override fun run() {
            checkAuto()
            if (a.isPlaying) handler.postDelayed(this, 40)
        }
    }

    private fun checkAuto() {
        val mode = int("autoFading", 0)
        if (mode == 0 || bypass) {
            if (!overlap) dropPrepared()
            return
        }
        if (overlap || !a.isPlaying) return
        if (a.repeatMode == Player.REPEAT_MODE_ONE) return
        if (mode == 3 && !a.shuffleModeEnabled) return
        val next = a.nextMediaItemIndex
        if (next == C.INDEX_UNSET) return
        val duration = a.duration
        if (duration <= 0 || duration == C.TIME_UNSET) return
        val current = a.currentMediaItem ?: return
        val nextItem = a.getMediaItemAt(next)
        if (mode == 1 && gaplessLikely(current, nextItem)) return
        val nextDuration = nextItem.mediaMetadata.durationMs ?: duration
        val x = min(int("crossfadeMs", 5000).toLong(), min(duration, nextDuration) / 2)
        if (x < 1000) return
        val position = a.currentPosition
        val remaining = duration - position
        if (remaining > x + PREPARE_MS) {
            dropPrepared()
            return
        }
        if (preparedId != current.mediaId) {
            if (remaining - x >= 400) prepareSecond(current, position + (remaining - x))
            return
        }
        // the second player is ready: it starts exactly where the main player will be when the crossfade begins
        if (secondReady && position >= secondStartAt - 15) startOverlap()
    }

    /** Songs of one album that follow each other are meant to play without a gap. */
    private fun gaplessLikely(current: MediaItem, next: MediaItem): Boolean {
        val c = current.mediaMetadata.extras ?: return false
        val n = next.mediaMetadata.extras ?: return false
        val album = c.getLong("albumId", -1L)
        return album != -1L && album == n.getLong("albumId", -2L) && n.getInt("trackNo", -5) == c.getInt("trackNo", -9) + 1
    }

    private val secondListener = object : Player.Listener {
        override fun onPlaybackStateChanged(playbackState: Int) {
            if (playbackState == Player.STATE_READY && !overlap) secondReady = true
        }

        override fun onPlayerError(error: PlaybackException) {
            // the second player failed: carry on as if there were no crossfade
            if (overlap) abortOverlap() else dropPrepared()
        }
    }

    private fun prepareSecond(item: MediaItem, startAt: Long) {
        val player = b ?: createSecondPlayer().also {
            it.addListener(secondListener)
            b = it
        }
        SoundEngine.fadeB = 0.0
        SoundEngine.replayGainB = SoundEngine.replayGain
        secondReady = false
        preparedId = item.mediaId
        secondStartAt = startAt
        player.volume = 1f
        player.setMediaItem(item, startAt)
        player.playWhenReady = false
        player.prepare()
    }

    private fun startOverlap() {
        val player = b ?: return
        overlap = true
        player.playWhenReady = true
        // first the same song is passed from the main player to the second one, quickly, while they play the same place
        ramp(Slot.A, 0.0, JOIN_MS, equalPower = true)
        ramp(Slot.B, 1.0, JOIN_MS, equalPower = true) {
            if (overlap) {
                // the main player is silent: it moves to the next song, and the two songs fade across each other for the rest of the end
                val tail = (player.duration - player.currentPosition).coerceAtLeast(400L).toInt()
                a.seekToNextMediaItem()
                ramp(Slot.A, 1.0, tail, equalPower = true)
                ramp(Slot.B, 0.0, tail, equalPower = true) { finishOverlap() }
            }
        }
    }

    private fun finishOverlap() {
        b?.apply {
            stop()
            clearMediaItems()
        }
        SoundEngine.fadeB = 0.0
        overlap = false
        preparedId = null
        secondReady = false
    }

    /** Stops a crossfade that is going on, because the user did something. The main player goes back to full sound. */
    private fun abortOverlap() {
        ramps.clear()
        b?.apply {
            stop()
            clearMediaItems()
        }
        SoundEngine.fadeB = 0.0
        SoundEngine.fadeA = 1.0
        overlap = false
        preparedId = null
        secondReady = false
    }

    private fun dropPrepared() {
        if (overlap || preparedId == null) return
        b?.apply {
            stop()
            clearMediaItems()
        }
        preparedId = null
        secondReady = false
    }

    fun release() {
        handler.removeCallbacksAndMessages(null)
        ramps.clear()
        b?.release()
        b = null
        SoundEngine.fadeA = 1.0
        SoundEngine.fadeB = 0.0
    }

    private companion object {
        /** How long before the crossfade starts the second player is prepared. */
        const val PREPARE_MS = 2500L

        /** The quick hand over of the end of the song from the main player to the second player. */
        const val JOIN_MS = 250
    }
}
