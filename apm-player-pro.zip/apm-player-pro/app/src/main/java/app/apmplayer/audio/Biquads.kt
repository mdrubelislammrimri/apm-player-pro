package app.apmplayer.audio

import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.log10
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * The filters behind the equalizer. Each fills a 5 number array: b0, b1, b2, a1, a2 (already divided by a0).
 * Formulas from the standard "audio EQ cookbook", checked numerically.
 */
object Biquads {

    fun peaking(f0: Double, db: Double, q: Double, fs: Double, out: DoubleArray) {
        val a = 10.0.pow(db / 40.0)
        val w = 2.0 * PI * f0 / fs
        val alpha = sin(w) / (2.0 * q)
        val c = cos(w)
        val a0 = 1.0 + alpha / a
        out[0] = (1.0 + alpha * a) / a0
        out[1] = (-2.0 * c) / a0
        out[2] = (1.0 - alpha * a) / a0
        out[3] = (-2.0 * c) / a0
        out[4] = (1.0 - alpha / a) / a0
    }

    fun shelf(f0: Double, db: Double, fs: Double, low: Boolean, out: DoubleArray) {
        val a = 10.0.pow(db / 40.0)
        val w = 2.0 * PI * f0 / fs
        val c = cos(w)
        val alpha = sin(w) / 2.0 * sqrt(2.0)
        val sq = 2.0 * sqrt(a) * alpha
        val b0: Double; val b1: Double; val b2: Double; val a0: Double; val a1: Double; val a2: Double
        if (low) {
            b0 = a * ((a + 1) - (a - 1) * c + sq)
            b1 = 2 * a * ((a - 1) - (a + 1) * c)
            b2 = a * ((a + 1) - (a - 1) * c - sq)
            a0 = (a + 1) + (a - 1) * c + sq
            a1 = -2 * ((a - 1) + (a + 1) * c)
            a2 = (a + 1) + (a - 1) * c - sq
        } else {
            b0 = a * ((a + 1) + (a - 1) * c + sq)
            b1 = -2 * a * ((a - 1) + (a + 1) * c)
            b2 = a * ((a + 1) + (a - 1) * c - sq)
            a0 = (a + 1) - (a - 1) * c + sq
            a1 = 2 * ((a - 1) - (a + 1) * c)
            a2 = (a + 1) - (a - 1) * c - sq
        }
        out[0] = b0 / a0; out[1] = b1 / a0; out[2] = b2 / a0; out[3] = a1 / a0; out[4] = a2 / a0
    }

    /** Fills [out] for one parametric band. */
    fun forBand(band: ParamBand, fs: Double, out: DoubleArray) {
        when (band.type) {
            TYPE_LOW_SHELF -> shelf(band.freq.toDouble(), band.gainDb.toDouble(), fs, low = true, out = out)
            TYPE_HIGH_SHELF -> shelf(band.freq.toDouble(), band.gainDb.toDouble(), fs, low = false, out = out)
            else -> peaking(band.freq.toDouble(), band.gainDb.toDouble(), band.q.toDouble(), fs, out)
        }
    }

    /** How many dB the filter adds or removes at frequency [f]. Used to draw the response curve. */
    fun magnitudeDb(c: DoubleArray, f: Double, fs: Double): Double {
        val w = 2.0 * PI * f / fs
        val cw = cos(w); val sw = sin(w)
        val c2 = cos(2 * w); val s2 = sin(2 * w)
        val numRe = c[0] + c[1] * cw + c[2] * c2
        val numIm = -(c[1] * sw + c[2] * s2)
        val denRe = 1.0 + c[3] * cw + c[4] * c2
        val denIm = -(c[3] * sw + c[4] * s2)
        val mag2 = (numRe * numRe + numIm * numIm) / (denRe * denRe + denIm * denIm)
        return 10.0 * log10(mag2.coerceAtLeast(1e-12))
    }
}
