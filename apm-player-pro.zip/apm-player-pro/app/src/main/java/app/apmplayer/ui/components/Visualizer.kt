package app.apmplayer.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import app.apmplayer.audio.AudioSpectrum
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.random.Random

/** Names of the built-in visualizer styles, in the order the next button cycles them. */
val VisualizerNames = listOf("Spectrum Bars", "Mirror Wave", "Pulse Rings", "Starfield")

private const val BANDS = 48

/** Moving points for the starfield style. */
private class Stars(count: Int) {
    val angle = FloatArray(count) { Random.nextFloat() * (2f * PI.toFloat()) }
    val dist = FloatArray(count) { Random.nextFloat() }
    val speed = FloatArray(count) { 0.05f + Random.nextFloat() * 0.25f }
    val hue = FloatArray(count) { Random.nextFloat() * 360f }
}

/**
 * A visualizer that moves with the music, drawn by this app (not copied from anywhere).
 * [style] is an index into [VisualizerNames]. It listens to the sound only while it is on screen.
 */
@Composable
fun VisualizerView(style: Int, playing: Boolean, modifier: Modifier = Modifier) {
    val raw = remember { FloatArray(BANDS) }
    val level = remember { FloatArray(BANDS) }
    val stars = remember { Stars(90) }
    var frame by remember { mutableLongStateOf(0L) }
    val lastFrame = remember { LongArray(1) } // plain holder, writing it does not trigger another draw

    DisposableEffect(Unit) {
        AudioSpectrum.enabled = true
        onDispose { AudioSpectrum.enabled = false }
    }
    LaunchedEffect(Unit) {
        while (true) androidx.compose.runtime.withFrameNanos { frame = it }
    }

    Canvas(modifier) {
        val now = frame
        val dt = if (lastFrame[0] == 0L) 0.016f else ((now - lastFrame[0]) / 1_000_000_000f).coerceIn(0.001f, 0.1f)
        lastFrame[0] = now
        if (playing) AudioSpectrum.bands(raw) else raw.fill(0f)
        for (i in 0 until BANDS) {
            // rise fast, fall slowly
            level[i] = if (raw[i] > level[i]) level[i] * 0.4f + raw[i] * 0.6f else level[i] * 0.9f
        }
        val seconds = now / 1_000_000_000f
        when (style) {
            0 -> bars(level, seconds)
            1 -> wave(level, seconds)
            2 -> rings(level, seconds)
            else -> starfield(level, stars, seconds, dt)
        }
    }
}

private fun hueColor(hue: Float, light: Float = 0.6f, alpha: Float = 1f): Color =
    Color.hsv(((hue % 360f) + 360f) % 360f, 0.75f, light + 0.35f).copy(alpha = alpha)

private fun DrawScope.bars(level: FloatArray, t: Float) {
    val n = level.size
    val slot = size.width / n
    val w = slot * 0.62f
    for (i in 0 until n) {
        val h = max(4f, level[i] * size.height * 0.62f)
        val x = slot * (i + 0.5f)
        val color = hueColor(t * 30f + i * 360f / n)
        drawLine(color, Offset(x, size.height), Offset(x, size.height - h), strokeWidth = w, cap = StrokeCap.Round)
        // a small cap that falls slowly looks like a peak marker
        drawCircle(Color.White.copy(alpha = 0.8f), radius = w * 0.35f, center = Offset(x, size.height - h - w))
    }
}

private fun DrawScope.wave(level: FloatArray, t: Float) {
    val n = level.size
    val cy = size.height * 0.5f
    val top = Path()
    val bottom = Path()
    for (i in 0 until n) {
        val x = size.width * i / (n - 1)
        val h = (level[i] * size.height * 0.34f) * (0.85f + 0.15f * sin(t * 3f + i * 0.4f))
        if (i == 0) {
            top.moveTo(x, cy - h)
            bottom.moveTo(x, cy + h)
        } else {
            top.lineTo(x, cy - h)
            bottom.lineTo(x, cy + h)
        }
    }
    val c1 = hueColor(t * 25f)
    val c2 = hueColor(t * 25f + 120f)
    drawPath(top, c1, style = Stroke(width = 6f, cap = StrokeCap.Round))
    drawPath(bottom, c2, style = Stroke(width = 6f, cap = StrokeCap.Round))
    for (i in 0 until n step 2) {
        val x = size.width * i / (n - 1)
        val h = level[i] * size.height * 0.34f
        drawLine(c1.copy(alpha = 0.18f), Offset(x, cy - h), Offset(x, cy + h), strokeWidth = 4f)
    }
}

private fun DrawScope.rings(level: FloatArray, t: Float) {
    val c = Offset(size.width / 2f, size.height * 0.5f)
    val base = min(size.width, size.height) * 0.16f
    var bass = 0f
    for (i in 0 until 8) bass = max(bass, level[i])
    for (r in 0 until 5) {
        val radius = base * (1f + r * 0.7f) + bass * base * (0.8f + r * 0.2f)
        drawCircle(
            hueColor(t * 40f + r * 50f, alpha = 0.75f - r * 0.1f), radius = radius, center = c,
            style = Stroke(width = 3f + bass * 8f),
        )
    }
    // a ring of lines around the middle, one for each pitch range
    val n = level.size
    for (i in 0 until n) {
        val a = (2.0 * PI * i / n + t * 0.3).toFloat()
        val inner = base * 0.9f
        val outer = inner + level[i] * base * 2.2f + 4f
        drawLine(
            hueColor(i * 360f / n + t * 30f), Offset(c.x + cos(a) * inner, c.y + sin(a) * inner),
            Offset(c.x + cos(a) * outer, c.y + sin(a) * outer), strokeWidth = 5f, cap = StrokeCap.Round,
        )
    }
}

private fun DrawScope.starfield(level: FloatArray, stars: Stars, t: Float, dt: Float) {
    var bass = 0f
    for (i in 0 until 8) bass = max(bass, level[i])
    var treble = 0f
    for (i in 28 until level.size) treble = max(treble, level[i])
    val c = Offset(size.width / 2f, size.height * 0.5f)
    val maxR = max(size.width, size.height) * 0.7f
    for (i in stars.angle.indices) {
        stars.dist[i] += stars.speed[i] * (0.25f + bass * 3f) * dt
        if (stars.dist[i] > 1f) {
            stars.dist[i] = 0f
            stars.angle[i] = Random.nextFloat() * (2f * PI.toFloat())
        }
        val d = stars.dist[i]
        val x = c.x + cos(stars.angle[i]) * d * maxR
        val y = c.y + sin(stars.angle[i]) * d * maxR
        val radius = 2f + d * (6f + treble * 14f)
        drawCircle(hueColor(stars.hue[i] + t * 20f, alpha = min(1f, 0.2f + d)), radius = radius, center = Offset(x, y))
    }
    drawCircle(hueColor(t * 50f, alpha = 0.35f), radius = 20f + bass * 140f, center = c)
}
