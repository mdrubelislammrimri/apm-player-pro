@file:androidx.annotation.OptIn(androidx.media3.common.util.UnstableApi::class)

package app.apmplayer.playback

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import androidx.core.app.NotificationCompat
import androidx.core.graphics.ColorUtils
import androidx.core.graphics.drawable.IconCompat
import androidx.media3.common.Player
import androidx.media3.session.CommandButton
import androidx.media3.session.DefaultMediaNotificationProvider
import androidx.media3.session.MediaNotification
import androidx.media3.session.MediaSession
import androidx.media3.session.SessionCommand
import app.apmplayer.art.ArtLoader
import com.google.common.collect.ImmutableList
import java.util.concurrent.Executors

/** What the buttons of the notification can be. The ids are what the setting stores. */
val NotificationButtonIds = listOf("prev", "playpause", "next", "rewind", "forward", "stop", "shuffle", "repeat", "like")
val NotificationButtonLabels = listOf("Previous", "Play/Pause", "Next", "Back 10 seconds", "Forward 10 seconds", "Stop", "Shuffle", "Repeat", "Like")
const val DEFAULT_NOTIFICATION_BUTTONS = "prev,playpause,next"

/** The buttons the setting names, in order, with play/pause always there. */
fun parseNotificationButtons(text: String): List<String> {
    val list = text.split(",").map { it.trim() }.filter { it in NotificationButtonIds }.distinct().toMutableList()
    if ("playpause" !in list) list.add(0, "playpause")
    return list
}

const val ACTION_SHUFFLE = "apm.shuffle"
const val ACTION_REPEAT = "apm.repeat"
const val ACTION_LIKE = "apm.like"

/**
 * The notification of the player. The standard media notification, with: the buttons the user picked, the colour taken from
 * the cover (Notification Type, Colors, Colorize), and a plain "Legacy" style without the media look.
 * Every choice is read from the settings each time the notification is made, so a change shows at once.
 */
class ApmNotificationProvider(private val context: Context, private val art: ArtLoader) : MediaNotification.Provider {

    private val prefs get() = context.getSharedPreferences("settings", Context.MODE_PRIVATE)
    private val worker = Executors.newSingleThreadExecutor()
    private val main = Handler(Looper.getMainLooper())
    private val colors = HashMap<String, Int>()

    /** The standard provider, with only the choice of buttons changed. */
    private val standard = object : DefaultMediaNotificationProvider(context) {
        override fun getMediaButtons(
            session: MediaSession,
            playerCommands: Player.Commands,
            mediaButtonPreferences: ImmutableList<CommandButton>,
            showPauseButton: Boolean,
        ): ImmutableList<CommandButton> {
            val wanted = parseNotificationButtons(prefs.getString("notifButtons", DEFAULT_NOTIFICATION_BUTTONS) ?: DEFAULT_NOTIFICATION_BUTTONS)
            val out = ImmutableList.builder<CommandButton>()
            var slot = 0
            for (id in wanted) {
                val button = button(id, session, playerCommands, showPauseButton) ?: continue
                // the first three go in the small version of the notification
                val extras = Bundle().apply { putInt(DefaultMediaNotificationProvider.COMMAND_KEY_COMPACT_VIEW_INDEX, if (slot < 3) slot else -1) }
                out.add(CommandButton.Builder(button.icon).apply {
                    button.sessionCommand?.let { setSessionCommand(it) }
                    if (button.sessionCommand == null) setPlayerCommand(button.playerCommand)
                    setDisplayName(button.displayName)
                    setExtras(extras)
                }.build())
                slot++
            }
            return out.build()
        }
    }

    private data class Plain(val icon: Int, val displayName: String, val playerCommand: Int, val sessionCommand: SessionCommand?)

    private fun button(id: String, session: MediaSession, commands: Player.Commands, showPause: Boolean): Plain? = when (id) {
        "prev" -> if (commands.contains(Player.COMMAND_SEEK_TO_PREVIOUS)) Plain(CommandButton.ICON_PREVIOUS, "Previous", Player.COMMAND_SEEK_TO_PREVIOUS, null) else null
        "playpause" -> if (commands.contains(Player.COMMAND_PLAY_PAUSE)) {
            Plain(if (showPause) CommandButton.ICON_PAUSE else CommandButton.ICON_PLAY, if (showPause) "Pause" else "Play", Player.COMMAND_PLAY_PAUSE, null)
        } else null
        "next" -> if (commands.contains(Player.COMMAND_SEEK_TO_NEXT)) Plain(CommandButton.ICON_NEXT, "Next", Player.COMMAND_SEEK_TO_NEXT, null) else null
        "rewind" -> if (commands.contains(Player.COMMAND_SEEK_BACK)) Plain(CommandButton.ICON_SKIP_BACK_10, "Back 10 seconds", Player.COMMAND_SEEK_BACK, null) else null
        "forward" -> if (commands.contains(Player.COMMAND_SEEK_FORWARD)) Plain(CommandButton.ICON_SKIP_FORWARD_10, "Forward 10 seconds", Player.COMMAND_SEEK_FORWARD, null) else null
        "stop" -> if (commands.contains(Player.COMMAND_STOP)) Plain(CommandButton.ICON_STOP, "Stop", Player.COMMAND_STOP, null) else null
        "shuffle" -> Plain(
            if (session.player.shuffleModeEnabled) CommandButton.ICON_SHUFFLE_ON else CommandButton.ICON_SHUFFLE_OFF,
            "Shuffle", Player.COMMAND_INVALID, SessionCommand(ACTION_SHUFFLE, Bundle.EMPTY),
        )
        "repeat" -> Plain(
            when (session.player.repeatMode) {
                Player.REPEAT_MODE_ONE -> CommandButton.ICON_REPEAT_ONE
                Player.REPEAT_MODE_ALL -> CommandButton.ICON_REPEAT_ALL
                else -> CommandButton.ICON_REPEAT_OFF
            },
            "Repeat", Player.COMMAND_INVALID, SessionCommand(ACTION_REPEAT, Bundle.EMPTY),
        )
        "like" -> Plain(CommandButton.ICON_HEART_UNFILLED, "Like", Player.COMMAND_INVALID, SessionCommand(ACTION_LIKE, Bundle.EMPTY))
        else -> null
    }

    override fun createNotification(
        mediaSession: MediaSession,
        mediaButtonPreferences: ImmutableList<CommandButton>,
        actionFactory: MediaNotification.ActionFactory,
        onNotificationChangedCallback: MediaNotification.Provider.Callback,
    ): MediaNotification {
        val type = prefs.getInt("notifType", 0)
        if (type == 3) return legacy(mediaSession, actionFactory)
        val made = standard.createNotification(mediaSession, mediaButtonPreferences, actionFactory, onNotificationChangedCallback)
        val colorize = type == 1 || prefs.getBoolean("colorizeNotification", true)
        if (colorize) {
            // the colour comes from the cover, found in the background and put in when ready
            val uri = mediaSession.player.mediaMetadata.artworkUri
            if (uri != null) {
                val key = uri.toString()
                val known = colors[key]
                if (known != null) {
                    paint(made, known)
                } else {
                    worker.execute {
                        val bitmap = try {
                            if (uri.scheme == "file") android.graphics.BitmapFactory.decodeFile(uri.path) else art.read(uri, 96)
                        } catch (e: Exception) {
                            null
                        }
                        colors[key] = bitmap?.let { dominant(it) } ?: Color.DKGRAY
                        main.post {
                            onNotificationChangedCallback.onNotificationChanged(
                                createNotification(mediaSession, mediaButtonPreferences, actionFactory, onNotificationChangedCallback),
                            )
                        }
                    }
                }
            }
        }
        return made
    }

    override fun handleCustomCommand(session: MediaSession, action: String, extras: Bundle): Boolean =
        standard.handleCustomCommand(session, action, extras)

    /** The colour of the notification: Auto follows the cover, Black wants dark text so it is made lighter, White wants light text so it is made darker. */
    private fun paint(made: MediaNotification, cover: Int) {
        var c = cover
        when (prefs.getInt("notifColors", 0)) {
            1 -> c = ColorUtils.blendARGB(c, Color.WHITE, 0.7f)
            2 -> c = ColorUtils.blendARGB(c, Color.BLACK, 0.5f)
        }
        made.notification.color = c
        made.notification.extras.putBoolean("android.colorized", true)
    }

    /** A colour that stands for the whole picture: the average, with the lively pixels counting more. */
    private fun dominant(source: Bitmap): Int {
        val small = Bitmap.createScaledBitmap(source, 12, 12, true)
        var r = 0.0
        var g = 0.0
        var b = 0.0
        var total = 0.0
        val hsv = FloatArray(3)
        for (x in 0 until 12) for (y in 0 until 12) {
            val px = small.getPixel(x, y)
            Color.colorToHSV(px, hsv)
            val weight = 0.2 + hsv[1] * hsv[2]
            r += Color.red(px) * weight
            g += Color.green(px) * weight
            b += Color.blue(px) * weight
            total += weight
        }
        if (total == 0.0) return Color.DKGRAY
        val average = Color.rgb((r / total).toInt(), (g / total).toInt(), (b / total).toInt())
        // not too light, so white text stays readable on it
        Color.colorToHSV(average, hsv)
        hsv[2] = hsv[2].coerceAtMost(0.75f)
        return Color.HSVToColor(hsv)
    }

    // ---------------------------------------------------------------- Legacy: a plain notification with text and buttons, no media look

    private fun legacy(session: MediaSession, factory: MediaNotification.ActionFactory): MediaNotification {
        val manager = context.getSystemService(NotificationManager::class.java)
        if (manager.getNotificationChannel(LEGACY_CHANNEL) == null) {
            manager.createNotificationChannel(NotificationChannel(LEGACY_CHANNEL, "Player (plain)", NotificationManager.IMPORTANCE_LOW))
        }
        val player = session.player
        val meta = player.mediaMetadata
        val builder = NotificationCompat.Builder(context, LEGACY_CHANNEL)
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentTitle(meta.title ?: "")
            .setContentText(meta.artist ?: "")
            .setSubText(meta.albumTitle)
            .setContentIntent(session.sessionActivity)
            .setDeleteIntent(factory.createMediaActionPendingIntent(session, Player.COMMAND_STOP.toLong()))
            .setOnlyAlertOnce(true)
            .setOngoing(player.isPlaying)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
        builder.addAction(
            factory.createMediaAction(
                session, IconCompat.createWithResource(context, android.R.drawable.ic_media_previous), "Previous", Player.COMMAND_SEEK_TO_PREVIOUS,
            ),
        )
        builder.addAction(
            factory.createMediaAction(
                session,
                IconCompat.createWithResource(context, if (player.isPlaying) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play),
                if (player.isPlaying) "Pause" else "Play", Player.COMMAND_PLAY_PAUSE,
            ),
        )
        builder.addAction(
            factory.createMediaAction(
                session, IconCompat.createWithResource(context, android.R.drawable.ic_media_next), "Next", Player.COMMAND_SEEK_TO_NEXT,
            ),
        )
        return MediaNotification(NOTIFICATION_ID, builder.build())
    }

    private companion object {
        const val LEGACY_CHANNEL = "apm_legacy"
        const val NOTIFICATION_ID = 1001
    }
}
