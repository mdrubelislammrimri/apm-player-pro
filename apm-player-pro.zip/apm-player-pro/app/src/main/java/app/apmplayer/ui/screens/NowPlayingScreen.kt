package app.apmplayer.ui.screens

import app.apmplayer.playback.PlayerUiState
import app.apmplayer.playback.PlayerConnection
import app.apmplayer.ui.theme.n
import androidx.compose.material3.OutlinedTextField
import app.apmplayer.tags.TagEdit
import androidx.compose.foundation.layout.heightIn
import androidx.compose.ui.graphics.ColorMatrix
import androidx.compose.ui.graphics.ColorFilter
import app.apmplayer.ui.components.LocalSettings
import app.apmplayer.settings.Settings
import kotlinx.coroutines.delay
import app.apmplayer.ui.components.rememberArt
import app.apmplayer.ui.components.VisualizerView
import app.apmplayer.ui.components.VisualizerNames
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.Brush
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.DisposableEffect
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.automirrored.rounded.ArrowForward
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.Image
import androidx.compose.animation.core.animateFloatAsState
import android.graphics.Bitmap
import android.app.Activity
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.basicMarquee
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.FastForward
import androidx.compose.material.icons.rounded.FastRewind
import androidx.compose.material.icons.rounded.Forward10
import androidx.compose.material.icons.rounded.GraphicEq
import androidx.compose.material.icons.rounded.KeyboardArrowDown
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Repeat
import androidx.compose.material.icons.rounded.RepeatOne
import androidx.compose.material.icons.rounded.Replay10
import androidx.compose.material.icons.rounded.Schedule
import androidx.compose.material.icons.rounded.Shuffle
import androidx.compose.material.icons.rounded.Star
import androidx.compose.material.icons.rounded.StarBorder
import androidx.compose.material.icons.rounded.ThumbDown
import androidx.compose.material.icons.rounded.ThumbUp
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import app.apmplayer.ui.components.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.RectangleShape
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.semantics.stateDescription
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.media3.common.Player
import app.apmplayer.AppContainer
import app.apmplayer.data.TrackDetail
import app.apmplayer.ui.components.GeneratedArt
import app.apmplayer.ui.components.WaveformSeek
import app.apmplayer.ui.components.focusRing
import app.apmplayer.ui.theme.Apm
import app.apmplayer.ui.theme.ApmShape
import app.apmplayer.ui.theme.ApmSpace
import app.apmplayer.util.audioInfoLine
import app.apmplayer.util.formatDuration
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.launch
import java.util.Locale

@OptIn(ExperimentalFoundationApi::class)
/** S01. The player: art, waveform seek bar with the controls on top, times, and the audio info line. */
@Composable
fun NowPlayingScreen(
    container: AppContainer,
    onBack: () -> Unit,
    onOpenFolder: (String) -> Unit,
    onNavigate: (String) -> Unit,
) {
    val player = container.player
    val state by player.state.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    val trackId = state.mediaId?.toLongOrNull()
    val detail: TrackDetail? by remember(trackId) {
        if (trackId == null) flowOf<TrackDetail?>(null) else container.repository.observeTrack(trackId)
    }.collectAsStateWithLifecycle(initialValue = null)

    val peaks by produceState<ByteArray?>(initialValue = null, detail?.track?.id) {
        value = null
        val t = detail?.track
        if (t != null) value = container.waveforms.get(t.id, t.uri, t.durationMs)
    }

    var showMenu by remember { mutableStateOf(false) }
    var showSleep by remember { mutableStateOf(false) }
    var showInfo by remember { mutableStateOf(false) }
    var showEdit by remember { mutableStateOf(false) }
    var showPlaylists by remember { mutableStateOf(false) }
    var showLyrics by remember { mutableStateOf(false) }
    val playlists by remember { container.repository.playlists.observePlaylists() }.collectAsStateWithLifecycle(initialValue = emptyList())
    val settings = LocalSettings.current
    val waveformOn = settings.seekStyle != 2
    var dragFraction by remember { mutableStateOf<Float?>(null) }

    val deleteLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            player.removeCurrent()
            container.repository.startScan()
        }
    }

    val duration = state.durationMs.coerceAtLeast(1L)
    val fraction = dragFraction ?: (state.positionMs.toFloat() / duration)
    val shownMs = (fraction.coerceIn(0f, 1f) * duration).toLong()
    val sleepActive = state.sleepEndsAtMs > System.currentTimeMillis()
    val seed = trackId ?: 0L

    // real cover from the song file, with the generated colours as a fallback
    val art = rememberArt(trackId, detail?.track?.uri ?: state.uri, 800)
    var vizOn by rememberSaveable { mutableStateOf(false) }
    var vizStyle by rememberSaveable { mutableStateOf(0) }
    var uiVisible by remember { mutableStateOf(true) }
    var tapCount by remember { mutableStateOf(0) }
    var showVizMenu by remember { mutableStateOf(false) }
    val contentAlpha by animateFloatAsState(if (!vizOn || uiVisible) 1f else settings.vizOpacityPct / 100f, label = "uiAlpha")
    val hidden = vizOn && !uiVisible

    // after a few seconds the buttons fade and only the visualizer stays. Tap to bring them back.
    LaunchedEffect(vizOn, uiVisible, tapCount) {
        if (vizOn && uiVisible) {
            delay(settings.vizTimeoutMs.toLong())
            uiVisible = false
        }
    }
    // optional: move on to the next visualizer style every few seconds
    LaunchedEffect(vizOn, settings.vizAutoSeconds) {
        if (vizOn && settings.vizAutoSeconds > 0) {
            while (true) {
                delay(settings.vizAutoSeconds * 1000L)
                vizStyle = (vizStyle + 1) % VisualizerNames.size
            }
        }
    }
    LaunchedEffect(hidden) { container.fullScreenViz.value = hidden }
    DisposableEffect(Unit) { onDispose { container.fullScreenViz.value = false } }

    // like, dislike and the track menu button. Used on the cover or under it, depending on the layout.
    @Composable
    fun RatingMenuRow(modifier: Modifier, alpha: Float) {
        Row(
            modifier.alpha(alpha),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(ApmSpace.s2),
        ) {
            val rating = detail?.track?.rating
            if (settings.showRating) RatingPill(Icons.Rounded.ThumbUp, "Like", rating == 5) {
                val id = trackId
                if (id != null) scope.launch { container.repository.setRating(id, if (rating == 5) 0 else 5) }
            }
            if (settings.showRating) RatingPill(Icons.Rounded.ThumbDown, "Dislike", rating == 1) {
                val id = trackId
                if (id != null) scope.launch { container.repository.setRating(id, if (rating == 1) 0 else 1) }
            }
            Spacer(Modifier.weight(1f))
            IconButton(onClick = { showMenu = true }) {
                Icon(Icons.Rounded.MoreVert, contentDescription = "Track menu", tint = n(Color.White))
            }
        }
    }

    // title and artist, long titles scroll sideways. On the cover they sit on a dark chip.
    @Composable
    fun Labels(onCover: Boolean) {
        val align = if (settings.labelsCentered) TextAlign.Center else TextAlign.Start
        val chip: Modifier = if (settings.labelsBg) {
            Modifier.clip(ApmShape.sm).background(n(Color.Black).copy(alpha = if (onCover) 0.7f else 0.4f))
                .padding(horizontal = ApmSpace.s2, vertical = ApmSpace.s1)
        } else {
            Modifier
        }
        Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(ApmSpace.s1)) {
            Text(
                state.title, style = Apm.type.title.copy(fontWeight = FontWeight.Bold), color = n(Color.White),
                maxLines = 1, softWrap = false, textAlign = align,
                modifier = Modifier.fillMaxWidth().then(chip).basicMarquee(),
            )
            if (state.artist.isNotEmpty()) {
                Text(
                    state.artist, style = Apm.type.body.copy(fontWeight = FontWeight.SemiBold), color = n(Color(0xFFC8C8C8)),
                    maxLines = 1, overflow = TextOverflow.Ellipsis, textAlign = align,
                    modifier = Modifier.fillMaxWidth().then(chip),
                )
            }
        }
    }

    Box(Modifier.fillMaxSize()) {
        if (state.hasMedia) {
            // soft colour wash taken from the cover, fading to black at the bottom
            ArtBackdrop(art, seed, settings)
        }
        if (vizOn && state.hasMedia) {
            Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.72f)))
            VisualizerView(style = vizStyle, playing = state.isPlaying, modifier = Modifier.fillMaxSize())
        }
        Column(Modifier.fillMaxSize().padding(horizontal = ApmSpace.s4).alpha(contentAlpha)) {
            if (vizOn) {
                VizHeader(
                    name = VisualizerNames[vizStyle],
                    onNext = { vizStyle = (vizStyle + 1) % VisualizerNames.size; tapCount++ },
                    onClose = { vizOn = false },
                )
            } else {
                Row(Modifier.fillMaxWidth().height(56.dp), verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Rounded.KeyboardArrowDown, contentDescription = "Back", tint = n(Color.White), modifier = Modifier.size(32.dp))
                    }
                }
            }

            if (!state.hasMedia) {
                Spacer(Modifier.weight(1f))
                Text("Nothing is playing", style = Apm.type.title, color = n(Color.White), modifier = Modifier.align(Alignment.CenterHorizontally))
                Text("Pick a song from your folders.", style = Apm.type.bodySm, color = Apm.colors.textMuted, modifier = Modifier.align(Alignment.CenterHorizontally))
                Spacer(Modifier.weight(1f))
                return@Column
            }

            // cover: pull it down to go back, swipe sideways to change songs
            BoxWithConstraints(
                Modifier.weight(1f).fillMaxWidth()
                    .pointerInput(Unit) {
                        var total = 0f
                        detectVerticalDragGestures(
                            onDragStart = { total = 0f },
                            onDragEnd = {
                                if (total > 150f) onBack() else if (total < -150f && state.hasMedia && settings.lyricsSwipe) showLyrics = true
                            },
                            onDragCancel = {},
                        ) { change, amount -> change.consume(); total += amount }
                    }
                    .pointerInput(settings.coverSwipe) {
                        if (!settings.coverSwipe) return@pointerInput
                        var dx = 0f
                        detectHorizontalDragGestures(
                            onDragStart = { dx = 0f },
                            onDragEnd = { if (dx < -140f) player.next() else if (dx > 140f) player.previous() },
                            onDragCancel = {},
                        ) { change, amount -> change.consume(); dx += amount }
                    },
                contentAlignment = Alignment.Center,
            ) {
                val bmp = art
                // keep the picture's own shape (a wide video thumbnail stays wide), unless the cover is set to square
                val aspect = if (bmp != null && !settings.squareCover) (bmp.width.toFloat() / bmp.height).coerceIn(0.75f, 1.9f) else 1f
                var w = maxWidth
                var h = w / aspect
                if (h > maxHeight) {
                    h = maxHeight
                    w = h * aspect
                }
                Box(Modifier.size(w, h)) {
                    if (bmp != null) {
                        Image(
                            bitmap = bmp.asImageBitmap(), contentDescription = "Cover", contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize().clip(ApmShape.lg),
                        )
                    } else {
                        GeneratedArt(seed = seed, modifier = Modifier.fillMaxSize(), shape = ApmShape.lg)
                    }
                    if (settings.layout != 2) {
                        // Default: labels and buttons on the cover. Alternative: only small faded buttons on it.
                        Column(
                            Modifier.align(Alignment.BottomStart).fillMaxWidth().padding(ApmSpace.s2),
                            verticalArrangement = Arrangement.spacedBy(ApmSpace.s1),
                        ) {
                            if (settings.layout == 0) Labels(onCover = true)
                            RatingMenuRow(Modifier.fillMaxWidth(), if (settings.layout == 1) 0.6f else 1f)
                        }
                    }
                }
            }

            // Full cover: buttons and labels under the cover. Alternative: only the labels. Default: nothing, they are on the cover.
            if (settings.layout == 2) RatingMenuRow(Modifier.fillMaxWidth().padding(top = ApmSpace.s3), 1f)
            if (settings.layout != 0) Box(Modifier.padding(top = ApmSpace.s2)) { Labels(onCover = false) }

            // waveform style, sleep timer | repeat, shuffle
            Row(
                Modifier.fillMaxWidth().padding(vertical = ApmSpace.s3),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                PillGroup {
                    GlyphToggle(
                        Icons.Rounded.GraphicEq, if (vizOn) "Visualizer on" else "Visualizer", vizOn,
                        onLongClick = { showVizMenu = true },
                    ) {
                        vizOn = !vizOn
                        uiVisible = true
                        tapCount++
                    }
                    GlyphToggle(Icons.Rounded.Schedule, if (sleepActive) "Sleep timer on" else "Sleep timer", sleepActive) {
                        showSleep = true
                    }
                }
                PillGroup {
                    val repeatIcon = if (state.repeatMode == Player.REPEAT_MODE_ONE) Icons.Rounded.RepeatOne else Icons.Rounded.Repeat
                    GlyphToggle(
                        repeatIcon,
                        when (state.repeatMode) {
                            Player.REPEAT_MODE_ALL -> "Repeat all"
                            Player.REPEAT_MODE_ONE -> "Repeat one"
                            else -> "Repeat off"
                        },
                        state.repeatMode != Player.REPEAT_MODE_OFF,
                    ) { player.cycleRepeat() }
                    GlyphToggle(Icons.Rounded.Shuffle, if (state.shuffle) "Shuffle on" else "Shuffle off", state.shuffle) {
                        player.toggleShuffle()
                    }
                }
            }

            // seek bar: waveform under the buttons (default), a waveform strip below them, or a plain slider
            val positionText = "${formatDuration(shownMs)} of ${formatDuration(state.durationMs)}"
            val showPro = settings.proButtons || settings.seekStyle == 2
            val wave: @Composable () -> Unit = {
                WaveformSeek(
                    peaks = peaks, fraction = fraction,
                    onPreview = { dragFraction = it },
                    onCommit = { f -> player.seekTo((f * duration).toLong()); dragFraction = null },
                    positionText = positionText,
                )
            }
            when (settings.seekStyle) {
                0 -> Box(Modifier.fillMaxWidth().height(124.dp), contentAlignment = Alignment.Center) {
                    wave()
                    TransportRow(player, state, showPro)
                }
                1 -> Column(Modifier.fillMaxWidth()) {
                    Box(Modifier.fillMaxWidth().height(84.dp), contentAlignment = Alignment.Center) { TransportRow(player, state, showPro) }
                    Box(Modifier.fillMaxWidth().height(64.dp)) { wave() }
                }
                else -> Column(Modifier.fillMaxWidth()) {
                    Box(Modifier.fillMaxWidth().height(84.dp), contentAlignment = Alignment.Center) { TransportRow(player, state, showPro) }
                    Slider(
                        value = fraction.coerceIn(0f, 1f),
                        onValueChange = { dragFraction = it },
                        onValueChangeFinished = {
                            dragFraction?.let { player.seekTo((it * duration).toLong()) }
                            dragFraction = null
                        },
                        colors = SliderDefaults.colors(
                            thumbColor = n(Color.White), activeTrackColor = n(Color.White), inactiveTrackColor = n(Color(0xFF5A5A5A)),
                        ),
                        modifier = Modifier.fillMaxWidth().semantics {
                            contentDescription = "Seek"
                            stateDescription = positionText
                        },
                    )
                }
            }

            Row(Modifier.fillMaxWidth().padding(horizontal = ApmSpace.s2), horizontalArrangement = Arrangement.SpaceBetween) {
                TimeLabel(formatDuration(shownMs), settings.timePills)
                TimeLabel(formatDuration(state.durationMs), settings.timePills)
            }

            val info = audioInfoLine(state.sampleRate, state.bitrateBps, state.codec)
            if (info.isNotEmpty() && settings.showInfoLine) {
                Text(
                    info, style = Apm.type.label.copy(fontWeight = FontWeight.Bold), color = n(Color(0xFF9A9A9A)),
                    modifier = Modifier.align(Alignment.CenterHorizontally).padding(top = ApmSpace.s3, bottom = ApmSpace.s2)
                        .clip(ApmShape.pill).background(n(Color(0xFF1F1F1F))).padding(horizontal = ApmSpace.s4, vertical = ApmSpace.s2),
                )
            }
            Spacer(Modifier.height(ApmSpace.s2))
        }
        if (!settings.tipsShown && state.hasMedia && !vizOn && !showLyrics) {
            TipsCard(
                modifier = Modifier.align(Alignment.TopCenter).padding(top = 72.dp, start = ApmSpace.s4, end = ApmSpace.s4),
                onClose = { container.settings.update { it.copy(tipsShown = true) } },
            )
        }
        if (showLyrics && trackId != null) {
            LyricsOverlay(
                trackId = trackId, title = state.title, positionMs = state.positionMs, container = container,
                onSeek = { player.seekTo(it) }, onClose = { showLyrics = false },
            )
        }
        if (hidden) {
            // the buttons are faded out, a tap brings them back
            Box(
                Modifier.fillMaxSize().clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) {
                    uiVisible = true
                    tapCount++
                },
            )
        }
    }

    if (showVizMenu) {
        AlertDialog(
            onDismissRequest = { showVizMenu = false },
            title = { Text("Visualizer") },
            confirmButton = { TextButton(onClick = { showVizMenu = false }) { Text("Close") } },
            text = {
                Column {
                    VizMenuRow(if (waveformOn) "Seek bar: waveform (tap for plain)" else "Seek bar: plain (tap for waveform)") {
                        container.settings.update { it.copy(seekStyle = if (it.seekStyle == 2) 0 else 2) }
                        showVizMenu = false
                    }
                    VisualizerNames.forEachIndexed { i, name ->
                        VizMenuRow((if (i == vizStyle) "• " else "") + name) {
                            vizStyle = i
                            vizOn = true
                            uiVisible = true
                            tapCount++
                            showVizMenu = false
                        }
                    }
                }
            },
        )
    }

    val d = detail
    if (showMenu && d != null) {
        TrackMenu(
            detail = d,
            onDismiss = { showMenu = false },
            onLike = { scope.launch { container.repository.setRating(d.track.id, if (d.track.rating == 5) 0 else 5) } },
            onDislike = { scope.launch { container.repository.setRating(d.track.id, if (d.track.rating == 1) 0 else 1) } },
            onDelete = {
                showMenu = false
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    val request = MediaStore.createDeleteRequest(context.contentResolver, listOf(Uri.parse(d.track.uri)))
                    deleteLauncher.launch(IntentSenderRequest.Builder(request.intentSender).build())
                } else {
                    Toast.makeText(context, "Deleting songs needs Android 11 or newer in this version.", Toast.LENGTH_LONG).show()
                }
            },
            onInfo = { showMenu = false; showInfo = true },
            onFolder = { showMenu = false; onOpenFolder(d.folderPath) },
            onPlaylist = { showMenu = false; showPlaylists = true },
            onBookmark = {
                showMenu = false
                scope.launch { container.repository.addBookmark(d.track.id, state.positionMs) }
                Toast.makeText(context, "Bookmarked at " + formatDuration(state.positionMs), Toast.LENGTH_SHORT).show()
            },
            onArtist = {
                showMenu = false
                d.track.artistId?.let { onNavigate("songs/artist-$it?title=" + Uri.encode(d.artistName.orEmpty())) }
            },
            onAlbum = {
                showMenu = false
                d.track.albumId?.let { onNavigate("songs/album-$it?title=" + Uri.encode(d.albumTitle.orEmpty())) }
            },
            onLyrics = { showMenu = false; showLyrics = true },
            onGenre = {
                showMenu = false
                d.track.genre?.let { onNavigate("songs/genre?title=" + Uri.encode(it) + "&arg=" + Uri.encode(it)) }
            },
        )
    }
    if (showPlaylists && d != null) {
        PlaylistPickerDialog(
            playlists = playlists,
            onPick = { p ->
                scope.launch { container.repository.addToPlaylist(p.id, d.track.id) }
                Toast.makeText(context, "Added to " + p.name, Toast.LENGTH_SHORT).show()
                showPlaylists = false
            },
            onCreate = { name ->
                scope.launch {
                    val id = container.repository.createPlaylist(name)
                    if (id != null) container.repository.addToPlaylist(id, d.track.id)
                }
                Toast.makeText(context, "Added to " + name.trim(), Toast.LENGTH_SHORT).show()
                showPlaylists = false
            },
            onDismiss = { showPlaylists = false },
        )
    }
    if (showInfo && d != null) {
        InfoDialog(
            detail = d,
            audioLine = audioInfoLine(state.sampleRate, state.bitrateBps, state.codec),
            edited = container.tagEdits.has(d.track.mediaStoreId),
            onEdit = { showInfo = false; showEdit = true },
            onUndo = {
                container.tagEdits.remove(d.track.mediaStoreId)
                container.repository.startScan()
                showInfo = false
                Toast.makeText(context, "Back to what the file says", Toast.LENGTH_SHORT).show()
            },
            onDismiss = { showInfo = false },
        )
    }
    if (showEdit && d != null) {
        EditTagsDialog(
            detail = d,
            onSave = { title, artist, album ->
                container.tagEdits.put(d.track.mediaStoreId, TagEdit(title, artist, album))
                container.repository.startScan()
                showEdit = false
                Toast.makeText(context, "Saved. The library is updating.", Toast.LENGTH_SHORT).show()
            },
            onDismiss = { showEdit = false },
        )
    }
    if (showSleep) {
        SleepDialog(
            endsAtMs = state.sleepEndsAtMs,
            onPick = { minutes -> player.setSleepTimer(minutes); showSleep = false },
            onDismiss = { showSleep = false },
        )
    }
}

@Composable
private fun RatingPill(icon: ImageVector, description: String, on: Boolean, onClick: () -> Unit) {
    Box(
        Modifier.size(width = 64.dp, height = 44.dp).clip(ApmShape.pill)
            .border(1.5.dp, if (on) Apm.colors.accent else n(Color(0xFF8A8A8A)), ApmShape.pill)
            .focusRing(ApmShape.pill).clickable(role = Role.Button, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Icon(icon, contentDescription = description, tint = if (on) Apm.colors.accent else n(Color.White), modifier = Modifier.size(22.dp))
    }
}

@Composable
private fun PillGroup(content: @Composable () -> Unit) {
    val back = LocalSettings.current.buttonsBg
    Row(
        Modifier.clip(ApmShape.pill).then(if (back) Modifier.background(n(Color(0xFF1F1F1F)).copy(alpha = 0.85f)) else Modifier)
            .padding(horizontal = ApmSpace.s1),
        verticalAlignment = Alignment.CenterVertically,
    ) { content() }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun GlyphToggle(
    icon: ImageVector,
    description: String,
    on: Boolean,
    onLongClick: (() -> Unit)? = null,
    onClick: () -> Unit,
) {
    Box(
        Modifier.size(52.dp).clip(ApmShape.round).focusRing(ApmShape.round)
            .combinedClickable(role = Role.Button, onLongClick = onLongClick, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Icon(icon, contentDescription = description, tint = if (on) n(Color.White) else n(Color(0xFF777777)), modifier = Modifier.size(26.dp))
    }
}

@Composable
private fun RoundButton(icon: ImageVector, description: String, sizeDp: Int, onClick: () -> Unit) {
    Box(
        Modifier.size(sizeDp.dp).clip(ApmShape.round).background(Color.Black).focusRing(ApmShape.round)
            .clickable(role = Role.Button, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Icon(icon, contentDescription = description, tint = n(Color.White), modifier = Modifier.size((sizeDp * 0.5f).dp))
    }
}

@Composable
private fun FadedButton(icon: ImageVector, description: String, onClick: () -> Unit) {
    Box(
        Modifier.size(48.dp).clip(ApmShape.round).background(Color.Black.copy(alpha = 0.55f)).focusRing(ApmShape.round)
            .clickable(role = Role.Button, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Icon(icon, contentDescription = description, tint = n(Color(0xFFB0B0B0)), modifier = Modifier.size(26.dp))
    }
}

@Composable
private fun SleepDialog(endsAtMs: Long, onPick: (Int?) -> Unit, onDismiss: () -> Unit) {
    val remainingMin = ((endsAtMs - System.currentTimeMillis()) / 60_000L + 1).toInt()
    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = { TextButton(onClick = onDismiss) { Text("Close") } },
        title = { Text("Sleep timer") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                if (endsAtMs > System.currentTimeMillis()) {
                    Text("Music stops in about $remainingMin min.", style = Apm.type.bodySm, color = Apm.colors.textMuted)
                    TextButton(onClick = { onPick(null) }) { Text("Cancel the timer") }
                }
                listOf(5, 10, 15, 30, 45, 60, 90).forEach { m ->
                    Box(
                        Modifier.fillMaxWidth().height(48.dp).clickable { onPick(m) },
                        contentAlignment = Alignment.CenterStart,
                    ) { Text("$m minutes", style = Apm.type.body, color = Apm.colors.text) }
                }
            }
        },
    )
}

@Composable
private fun InfoDialog(
    detail: TrackDetail,
    audioLine: String,
    edited: Boolean,
    onEdit: () -> Unit,
    onUndo: () -> Unit,
    onDismiss: () -> Unit,
) {
    val t = detail.track
    val rows = listOf(
        "Title" to t.title,
        "Artist" to (detail.artistName ?: "Unknown artist"),
        "Album" to (detail.albumTitle ?: "Unknown album"),
        "Folder" to detail.folderPath,
        "Length" to formatDuration(t.durationMs),
        "Format" to audioLine.lowercase(Locale.ROOT).ifEmpty { t.mimeType.orEmpty() },
        "Size" to (t.sizeBytes?.let { String.format(Locale.ROOT, "%.1f MB", it / 1_048_576.0) } ?: ""),
    ).filter { it.second.isNotBlank() }
    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = { TextButton(onClick = onDismiss) { Text("Close") } },
        dismissButton = { TextButton(onClick = onEdit) { Text("Edit names") } },
        title = { Text("Track info") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(ApmSpace.s2)) {
                rows.forEach { (k, v) ->
                    Column {
                        Text(k, style = Apm.type.caption, color = Apm.colors.textMuted)
                        Text(v, style = Apm.type.body, color = Apm.colors.text)
                    }
                }
                if (edited) {
                    Text(
                        "The names above were edited in this app. The song file itself is unchanged.",
                        style = Apm.type.caption, color = Apm.colors.textMuted,
                    )
                    TextButton(onClick = onUndo) { Text("Undo edits") }
                }
            }
        },
    )
}


/** Colour wash from the cover: the picture shrunk to 16 by 16 and stretched over the screen is a soft blur. */
@Composable
private fun ArtBackdrop(art: Bitmap?, seed: Long, settings: Settings) {
    if (!settings.bgOn) return
    if (art == null) {
        GeneratedArt(seed = seed, modifier = Modifier.fillMaxSize().alpha(settings.bgIntensityPct / 100f * 0.45f), shape = RectangleShape)
        return
    }
    // the picture shrunk to a few pixels and stretched over the screen is a soft blur: fewer pixels, softer
    val size = settings.bgDetails.coerceIn(4, 64)
    val tiny = remember(art, size) { Bitmap.createScaledBitmap(art, size, size, true).asImageBitmap() }
    val colors = remember(settings.bgSaturationPct) {
        ColorFilter.colorMatrix(ColorMatrix().apply { setToSaturation(settings.bgSaturationPct / 100f) })
    }
    Box(Modifier.fillMaxSize()) {
        Image(
            bitmap = tiny, contentDescription = null, contentScale = ContentScale.FillBounds, colorFilter = colors,
            filterQuality = FilterQuality.High, modifier = Modifier.fillMaxSize().alpha(settings.bgIntensityPct / 100f),
        )
        val dark = settings.bgGradientPct / 100f
        Box(
            Modifier.fillMaxSize().background(
                Brush.verticalGradient(listOf(Color.Transparent, n(Color.Black).copy(alpha = 0.55f * dark), n(Color.Black).copy(alpha = dark))),
            ),
        )
    }
}

/** Bar at the top while the visualizer is on: style name, next style, close. */
@Composable
private fun VizHeader(name: String, onNext: () -> Unit, onClose: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(top = ApmSpace.s2).height(56.dp).clip(RoundedCornerShape(28.dp))
            .background(n(Color(0xFF1F1F1F)).copy(alpha = 0.92f)).padding(horizontal = ApmSpace.s3),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(ApmSpace.s2),
    ) {
        Icon(Icons.Rounded.GraphicEq, contentDescription = null, tint = n(Color(0xFFB0B0B0)))
        Column(Modifier.weight(1f)) {
            Text(name, style = Apm.type.bodySm.copy(fontWeight = FontWeight.Bold), color = n(Color.White), maxLines = 1)
            Text("Built-in", style = Apm.type.caption.copy(fontWeight = FontWeight.SemiBold), color = n(Color(0xFFB0B0B0)))
        }
        IconButton(onClick = onNext) {
            Icon(Icons.AutoMirrored.Rounded.ArrowForward, contentDescription = "Next visualizer", tint = n(Color.White))
        }
        IconButton(onClick = onClose) {
            Icon(Icons.Rounded.Close, contentDescription = "Close visualizer", tint = n(Color.White))
        }
    }
}

@Composable
private fun VizMenuRow(text: String, onClick: () -> Unit) {
    Box(Modifier.fillMaxWidth().height(48.dp).clickable(onClick = onClick), contentAlignment = Alignment.CenterStart) {
        Text(text, style = Apm.type.body, color = Apm.colors.text)
    }
}

/** Time label on a black pill so it stays readable over any picture. */
@Composable
private fun TimePill(text: String) {
    Text(
        text, style = Apm.type.caption.copy(fontWeight = FontWeight.Bold), color = n(Color.White),
        modifier = Modifier.clip(ApmShape.pill).background(Color.Black.copy(alpha = 0.85f)).padding(horizontal = ApmSpace.s2, vertical = 3.dp),
    )
}


/** A short guide shown once on the player screen. Gestures that exist in this app only. */
@Composable
private fun TipsCard(modifier: Modifier, onClose: () -> Unit) {
    val tips = listOf(
        "Swipe the cover left or right to change songs.",
        "Swipe the cover up for lyrics, or down to go back.",
        "Tap the bars button for the visualizer. Press and hold it for more.",
        "Tap the waveform to jump to a place in the song.",
        "Swipe the playing song at the bottom of other screens to change songs.",
        "In lists, Select lets you pick many songs. Press and hold a song in a playlist to remove it.",
    )
    Column(
        modifier.clip(RoundedCornerShape(24.dp)).background(n(Color(0xFF2B2B2B)).copy(alpha = 0.96f)).padding(ApmSpace.s4),
        verticalArrangement = Arrangement.spacedBy(ApmSpace.s2),
    ) {
        Text("Tips", style = Apm.type.title, color = n(Color.White))
        tips.forEach { Text("• $it", style = Apm.type.bodySm, color = n(Color(0xFFE0E0E0))) }
        Box(
            Modifier.align(Alignment.End).heightIn(min = 44.dp).clip(ApmShape.pill).background(Apm.colors.accent)
                .focusRing(ApmShape.pill).clickable(role = Role.Button, onClick = onClose).padding(horizontal = ApmSpace.s5),
            contentAlignment = Alignment.Center,
        ) { Text("Got it", style = Apm.type.bodySm.copy(fontWeight = FontWeight.Bold), color = Apm.colors.onAccent) }
    }
}


/** Change how the song is named in this app. The file is not touched, the names are kept here and applied at every scan. */
@Composable
private fun EditTagsDialog(detail: TrackDetail, onSave: (String, String, String) -> Unit, onDismiss: () -> Unit) {
    var title by remember { mutableStateOf(detail.track.title) }
    var artist by remember { mutableStateOf(detail.artistName.orEmpty()) }
    var album by remember { mutableStateOf(detail.albumTitle.orEmpty()) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Edit names") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(ApmSpace.s2)) {
                OutlinedTextField(value = title, onValueChange = { title = it }, singleLine = true, label = { Text("Title") })
                OutlinedTextField(value = artist, onValueChange = { artist = it }, singleLine = true, label = { Text("Artist") })
                OutlinedTextField(value = album, onValueChange = { album = it }, singleLine = true, label = { Text("Album") })
                Text(
                    "Only this app shows the new names. The song file is not changed, so other apps keep the old ones.",
                    style = Apm.type.caption, color = Apm.colors.textMuted,
                )
            }
        },
        confirmButton = {
            TextButton(enabled = title.isNotBlank(), onClick = { onSave(title.trim(), artist.trim(), album.trim()) }) { Text("Save") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
}


/** A time label, on a black pill (the original's look) or as plain text. */
@Composable
private fun TimeLabel(text: String, pill: Boolean) {
    if (pill) {
        TimePill(text)
    } else {
        Text(text, style = Apm.type.caption.copy(fontWeight = FontWeight.Bold), color = n(Color.White))
    }
}


/** Previous, play or pause, next, and the two small faded buttons (10 seconds back and forward) when Pro Buttons is on. */
@Composable
private fun TransportRow(player: PlayerConnection, state: PlayerUiState, showPro: Boolean) {
    Row(
        Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceEvenly,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (showPro) FadedButton(Icons.Rounded.Replay10, "Back 10 seconds") { player.seekBy(-10_000) }
        RoundButton(Icons.Rounded.FastRewind, "Previous song", 56) { player.previous() }
        RoundButton(
            if (state.isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
            if (state.isPlaying) "Pause" else "Play", 76,
        ) { player.togglePlayPause() }
        RoundButton(Icons.Rounded.FastForward, "Next song", 56) { player.next() }
        if (showPro) FadedButton(Icons.Rounded.Forward10, "Forward 10 seconds") { player.seekBy(10_000) }
    }
}
