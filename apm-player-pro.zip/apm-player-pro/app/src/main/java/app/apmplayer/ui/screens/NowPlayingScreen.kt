package app.apmplayer.ui.screens

import android.app.Activity
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.basicMarquee
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.FastForward
import androidx.compose.material.icons.rounded.FastRewind
import androidx.compose.material.icons.rounded.Forward10
import androidx.compose.material.icons.rounded.GraphicEq
import androidx.compose.material.icons.rounded.KeyboardArrowDown
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Repeat
import androidx.compose.material.icons.rounded.RepeatOne
import androidx.compose.material.icons.rounded.Replay10
import androidx.compose.material.icons.rounded.Schedule
import androidx.compose.material.icons.rounded.Shuffle
import androidx.compose.material.icons.rounded.Star
import androidx.compose.material.icons.rounded.StarBorder
import androidx.compose.material.icons.rounded.ThumbDown
import androidx.compose.material.icons.rounded.ThumbUp
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.RectangleShape
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.semantics.stateDescription
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.media3.common.Player
import app.apmplayer.AppContainer
import app.apmplayer.data.TrackDetail
import app.apmplayer.ui.components.GeneratedArt
import app.apmplayer.ui.components.WaveformSeek
import app.apmplayer.ui.components.focusRing
import app.apmplayer.ui.theme.Apm
import app.apmplayer.ui.theme.ApmShape
import app.apmplayer.ui.theme.ApmSpace
import app.apmplayer.util.audioInfoLine
import app.apmplayer.util.formatDuration
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.launch
import java.util.Locale

@OptIn(ExperimentalFoundationApi::class)
/** S01. The player: art, waveform seek bar with the controls on top, times, and the audio info line. */
@Composable
fun NowPlayingScreen(
    container: AppContainer,
    onBack: () -> Unit,
    onOpenFolder: (String) -> Unit,
    onNavigate: (String) -> Unit,
) {
    val player = container.player
    val state by player.state.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    val trackId = state.mediaId?.toLongOrNull()
    val detail: TrackDetail? by remember(trackId) {
        if (trackId == null) flowOf<TrackDetail?>(null) else container.repository.observeTrack(trackId)
    }.collectAsStateWithLifecycle(initialValue = null)

    val peaks by produceState<ByteArray?>(initialValue = null, detail?.track?.id) {
        value = null
        val t = detail?.track
        if (t != null) value = container.waveforms.get(t.id, t.uri, t.durationMs)
    }

    var showMenu by remember { mutableStateOf(false) }
    var showSleep by remember { mutableStateOf(false) }
    var showInfo by remember { mutableStateOf(false) }
    var showPlaylists by remember { mutableStateOf(false) }
    val playlists by remember { container.repository.playlists.observePlaylists() }.collectAsStateWithLifecycle(initialValue = emptyList())
    var waveformOn by rememberSaveable { mutableStateOf(true) }
    var dragFraction by remember { mutableStateOf<Float?>(null) }

    val deleteLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            player.removeCurrent()
            container.repository.startScan()
        }
    }

    val duration = state.durationMs.coerceAtLeast(1L)
    val fraction = dragFraction ?: (state.positionMs.toFloat() / duration)
    val shownMs = (fraction.coerceIn(0f, 1f) * duration).toLong()
    val sleepActive = state.sleepEndsAtMs > System.currentTimeMillis()
    val seed = trackId ?: 0L

    Box(Modifier.fillMaxSize()) {
        if (state.hasMedia) {
            // soft coloured background taken from the artwork
            GeneratedArt(seed = seed, modifier = Modifier.fillMaxSize().alpha(0.3f), shape = RectangleShape)
        }
        Column(Modifier.fillMaxSize().padding(horizontal = ApmSpace.s4)) {
            Row(Modifier.fillMaxWidth().height(56.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) {
                    Icon(Icons.Rounded.KeyboardArrowDown, contentDescription = "Back", tint = Color.White, modifier = Modifier.size(32.dp))
                }
            }

            if (!state.hasMedia) {
                Spacer(Modifier.weight(1f))
                Text("Nothing is playing", style = Apm.type.title, color = Color.White, modifier = Modifier.align(Alignment.CenterHorizontally))
                Text("Pick a song from your folders.", style = Apm.type.bodySm, color = Apm.colors.textMuted, modifier = Modifier.align(Alignment.CenterHorizontally))
                Spacer(Modifier.weight(1f))
                return@Column
            }

            // artwork, pull it down to go back
            BoxWithConstraints(
                Modifier.weight(1f).fillMaxWidth().pointerInput(Unit) {
                    var total = 0f
                    detectVerticalDragGestures(
                        onDragStart = { total = 0f },
                        onDragEnd = { if (total > 150f) onBack() },
                        onDragCancel = {},
                    ) { change, amount -> change.consume(); total += amount }
                },
                contentAlignment = Alignment.Center,
            ) {
                val side = minOf(maxWidth, maxHeight)
                GeneratedArt(seed = seed, modifier = Modifier.size(side), shape = ApmShape.lg)
            }

            // like, dislike | track menu (as in the original player)
            Row(
                Modifier.fillMaxWidth().padding(top = ApmSpace.s3),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(ApmSpace.s2),
            ) {
                val rating = detail?.track?.rating
                RatingPill(Icons.Rounded.ThumbUp, "Like", rating == 5) {
                    val id = trackId
                    if (id != null) scope.launch { container.repository.setRating(id, if (rating == 5) 0 else 5) }
                }
                RatingPill(Icons.Rounded.ThumbDown, "Dislike", rating == 1) {
                    val id = trackId
                    if (id != null) scope.launch { container.repository.setRating(id, if (rating == 1) 0 else 1) }
                }
                Spacer(Modifier.weight(1f))
                IconButton(onClick = { showMenu = true }) {
                    Icon(Icons.Rounded.MoreVert, contentDescription = "Track menu", tint = Color.White)
                }
            }

            // title and artist under the artwork, long titles scroll sideways
            Text(
                state.title, style = Apm.type.title.copy(fontWeight = FontWeight.Bold), color = Color.White,
                maxLines = 1, softWrap = false,
                modifier = Modifier.fillMaxWidth().padding(top = ApmSpace.s2).basicMarquee(),
            )
            if (state.artist.isNotEmpty()) {
                Text(
                    state.artist, style = Apm.type.body.copy(fontWeight = FontWeight.SemiBold), color = Color(0xFFC8C8C8),
                    maxLines = 1, overflow = TextOverflow.Ellipsis,
                )
            }

            // waveform style, sleep timer | repeat, shuffle
            Row(
                Modifier.fillMaxWidth().padding(vertical = ApmSpace.s3),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                PillGroup {
                    GlyphToggle(Icons.Rounded.GraphicEq, if (waveformOn) "Waveform seek bar on" else "Waveform seek bar off", waveformOn) {
                        waveformOn = !waveformOn
                    }
                    GlyphToggle(Icons.Rounded.Schedule, if (sleepActive) "Sleep timer on" else "Sleep timer", sleepActive) {
                        showSleep = true
                    }
                }
                PillGroup {
                    val repeatIcon = if (state.repeatMode == Player.REPEAT_MODE_ONE) Icons.Rounded.RepeatOne else Icons.Rounded.Repeat
                    GlyphToggle(
                        repeatIcon,
                        when (state.repeatMode) {
                            Player.REPEAT_MODE_ALL -> "Repeat all"
                            Player.REPEAT_MODE_ONE -> "Repeat one"
                            else -> "Repeat off"
                        },
                        state.repeatMode != Player.REPEAT_MODE_OFF,
                    ) { player.cycleRepeat() }
                    GlyphToggle(Icons.Rounded.Shuffle, if (state.shuffle) "Shuffle on" else "Shuffle off", state.shuffle) {
                        player.toggleShuffle()
                    }
                }
            }

            // waveform with the controls on top
            Box(Modifier.fillMaxWidth().height(124.dp), contentAlignment = Alignment.Center) {
                val positionText = "${formatDuration(shownMs)} of ${formatDuration(state.durationMs)}"
                if (waveformOn) {
                    WaveformSeek(
                        peaks = peaks, fraction = fraction,
                        onPreview = { dragFraction = it },
                        onCommit = { f -> player.seekTo((f * duration).toLong()); dragFraction = null },
                        positionText = positionText,
                    )
                } else {
                    Slider(
                        value = fraction.coerceIn(0f, 1f),
                        onValueChange = { dragFraction = it },
                        onValueChangeFinished = {
                            dragFraction?.let { player.seekTo((it * duration).toLong()) }
                            dragFraction = null
                        },
                        colors = SliderDefaults.colors(
                            thumbColor = Color.White, activeTrackColor = Color.White, inactiveTrackColor = Color(0xFF5A5A5A),
                        ),
                        modifier = Modifier.fillMaxWidth().semantics {
                            contentDescription = "Seek"
                            stateDescription = positionText
                        },
                    )
                }
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    FadedButton(Icons.Rounded.Replay10, "Back 10 seconds") { player.seekBy(-10_000) }
                    RoundButton(Icons.Rounded.FastRewind, "Previous song", 56) { player.previous() }
                    RoundButton(
                        if (state.isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                        if (state.isPlaying) "Pause" else "Play", 76,
                    ) { player.togglePlayPause() }
                    RoundButton(Icons.Rounded.FastForward, "Next song", 56) { player.next() }
                    FadedButton(Icons.Rounded.Forward10, "Forward 10 seconds") { player.seekBy(10_000) }
                }
            }

            Row(Modifier.fillMaxWidth().padding(horizontal = ApmSpace.s2), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(formatDuration(shownMs), style = Apm.type.bodySm.copy(fontWeight = FontWeight.Bold), color = Color.White)
                Text(formatDuration(state.durationMs), style = Apm.type.bodySm.copy(fontWeight = FontWeight.Bold), color = Color.White)
            }

            val info = audioInfoLine(state.sampleRate, state.bitrateBps, state.codec)
            if (info.isNotEmpty()) {
                Text(
                    info, style = Apm.type.label.copy(fontWeight = FontWeight.Bold), color = Color(0xFF9A9A9A),
                    modifier = Modifier.align(Alignment.CenterHorizontally).padding(top = ApmSpace.s3, bottom = ApmSpace.s2)
                        .clip(ApmShape.pill).background(Color(0xFF1F1F1F)).padding(horizontal = ApmSpace.s4, vertical = ApmSpace.s2),
                )
            }
            Spacer(Modifier.height(ApmSpace.s2))
        }
    }

    val d = detail
    if (showMenu && d != null) {
        TrackMenu(
            detail = d,
            onDismiss = { showMenu = false },
            onLike = { scope.launch { container.repository.setRating(d.track.id, if (d.track.rating == 5) 0 else 5) } },
            onDislike = { scope.launch { container.repository.setRating(d.track.id, if (d.track.rating == 1) 0 else 1) } },
            onDelete = {
                showMenu = false
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    val request = MediaStore.createDeleteRequest(context.contentResolver, listOf(Uri.parse(d.track.uri)))
                    deleteLauncher.launch(IntentSenderRequest.Builder(request.intentSender).build())
                } else {
                    Toast.makeText(context, "Deleting songs needs Android 11 or newer in this version.", Toast.LENGTH_LONG).show()
                }
            },
            onInfo = { showMenu = false; showInfo = true },
            onFolder = { showMenu = false; onOpenFolder(d.folderPath) },
            onPlaylist = { showMenu = false; showPlaylists = true },
            onBookmark = {
                showMenu = false
                scope.launch { container.repository.addBookmark(d.track.id, state.positionMs) }
                Toast.makeText(context, "Bookmarked at " + formatDuration(state.positionMs), Toast.LENGTH_SHORT).show()
            },
            onArtist = {
                showMenu = false
                d.track.artistId?.let { onNavigate("songs/artist-$it?title=" + Uri.encode(d.artistName.orEmpty())) }
            },
            onAlbum = {
                showMenu = false
                d.track.albumId?.let { onNavigate("songs/album-$it?title=" + Uri.encode(d.albumTitle.orEmpty())) }
            },
            onGenre = {
                showMenu = false
                d.track.genre?.let { onNavigate("songs/genre?title=" + Uri.encode(it) + "&arg=" + Uri.encode(it)) }
            },
        )
    }
    if (showPlaylists && d != null) {
        PlaylistPickerDialog(
            playlists = playlists,
            onPick = { p ->
                scope.launch { container.repository.addToPlaylist(p.id, d.track.id) }
                Toast.makeText(context, "Added to " + p.name, Toast.LENGTH_SHORT).show()
                showPlaylists = false
            },
            onCreate = { name ->
                scope.launch {
                    val id = container.repository.createPlaylist(name)
                    if (id != null) container.repository.addToPlaylist(id, d.track.id)
                }
                Toast.makeText(context, "Added to " + name.trim(), Toast.LENGTH_SHORT).show()
                showPlaylists = false
            },
            onDismiss = { showPlaylists = false },
        )
    }
    if (showInfo && d != null) {
        InfoDialog(d, audioInfoLine(state.sampleRate, state.bitrateBps, state.codec)) { showInfo = false }
    }
    if (showSleep) {
        SleepDialog(
            endsAtMs = state.sleepEndsAtMs,
            onPick = { minutes -> player.setSleepTimer(minutes); showSleep = false },
            onDismiss = { showSleep = false },
        )
    }
}

@Composable
private fun RatingPill(icon: ImageVector, description: String, on: Boolean, onClick: () -> Unit) {
    Box(
        Modifier.size(width = 64.dp, height = 44.dp).clip(ApmShape.pill)
            .border(1.5.dp, if (on) Apm.colors.accent else Color(0xFF8A8A8A), ApmShape.pill)
            .focusRing(ApmShape.pill).clickable(role = Role.Button, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Icon(icon, contentDescription = description, tint = if (on) Apm.colors.accent else Color.White, modifier = Modifier.size(22.dp))
    }
}

@Composable
private fun PillGroup(content: @Composable () -> Unit) {
    Row(
        Modifier.clip(ApmShape.pill).background(Color(0xFF1F1F1F).copy(alpha = 0.85f)).padding(horizontal = ApmSpace.s1),
        verticalAlignment = Alignment.CenterVertically,
    ) { content() }
}

@Composable
private fun GlyphToggle(icon: ImageVector, description: String, on: Boolean, onClick: () -> Unit) {
    Box(
        Modifier.size(52.dp).clip(ApmShape.round).focusRing(ApmShape.round).clickable(role = Role.Button, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Icon(icon, contentDescription = description, tint = if (on) Color.White else Color(0xFF777777), modifier = Modifier.size(26.dp))
    }
}

@Composable
private fun RoundButton(icon: ImageVector, description: String, sizeDp: Int, onClick: () -> Unit) {
    Box(
        Modifier.size(sizeDp.dp).clip(ApmShape.round).background(Color.Black).focusRing(ApmShape.round)
            .clickable(role = Role.Button, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Icon(icon, contentDescription = description, tint = Color.White, modifier = Modifier.size((sizeDp * 0.5f).dp))
    }
}

@Composable
private fun FadedButton(icon: ImageVector, description: String, onClick: () -> Unit) {
    Box(
        Modifier.size(48.dp).clip(ApmShape.round).background(Color.Black.copy(alpha = 0.55f)).focusRing(ApmShape.round)
            .clickable(role = Role.Button, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Icon(icon, contentDescription = description, tint = Color(0xFFB0B0B0), modifier = Modifier.size(26.dp))
    }
}

@Composable
private fun SleepDialog(endsAtMs: Long, onPick: (Int?) -> Unit, onDismiss: () -> Unit) {
    val remainingMin = ((endsAtMs - System.currentTimeMillis()) / 60_000L + 1).toInt()
    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = { TextButton(onClick = onDismiss) { Text("Close") } },
        title = { Text("Sleep timer") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                if (endsAtMs > System.currentTimeMillis()) {
                    Text("Music stops in about $remainingMin min.", style = Apm.type.bodySm, color = Apm.colors.textMuted)
                    TextButton(onClick = { onPick(null) }) { Text("Cancel the timer") }
                }
                listOf(5, 10, 15, 30, 45, 60, 90).forEach { m ->
                    Box(
                        Modifier.fillMaxWidth().height(48.dp).clickable { onPick(m) },
                        contentAlignment = Alignment.CenterStart,
                    ) { Text("$m minutes", style = Apm.type.body, color = Apm.colors.text) }
                }
            }
        },
    )
}

@Composable
private fun InfoDialog(detail: TrackDetail, audioLine: String, onDismiss: () -> Unit) {
    val t = detail.track
    val rows = listOf(
        "Title" to t.title,
        "Artist" to (detail.artistName ?: "Unknown artist"),
        "Album" to (detail.albumTitle ?: "Unknown album"),
        "Folder" to detail.folderPath,
        "Length" to formatDuration(t.durationMs),
        "Format" to audioLine.lowercase(Locale.ROOT).ifEmpty { t.mimeType.orEmpty() },
        "Size" to (t.sizeBytes?.let { String.format(Locale.ROOT, "%.1f MB", it / 1_048_576.0) } ?: ""),
    ).filter { it.second.isNotBlank() }
    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = { TextButton(onClick = onDismiss) { Text("Close") } },
        title = { Text("Track info") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(ApmSpace.s2)) {
                rows.forEach { (k, v) ->
                    Column {
                        Text(k, style = Apm.type.caption, color = Apm.colors.textMuted)
                        Text(v, style = Apm.type.body, color = Apm.colors.text)
                    }
                }
            }
        },
    )
}
