package app.apmplayer.audio

import android.content.Context
import app.apmplayer.playback.PlayerConnection
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONArray
import org.json.JSONObject

/** Holds the sound settings, saves them, and pushes them to the audio chain and the player. */
class SoundController(context: Context, private val player: PlayerConnection) {

    private val prefs = context.getSharedPreferences("sound", Context.MODE_PRIVATE)

    private val _state = MutableStateFlow(load())
    val state: StateFlow<SoundState> = _state.asStateFlow()

    private val _userPresets = MutableStateFlow(loadPresets())
    val userPresets: StateFlow<List<EqPreset>> = _userPresets.asStateFlow()

    init {
        push(_state.value)
    }

    fun update(change: (SoundState) -> SoundState) {
        val next = change(_state.value)
        _state.value = next
        push(next)
        save(next)
    }

    fun setBand(index: Int, db: Float) = update { s ->
        s.copy(bandsDb = s.bandsDb.toMutableList().also { it[index] = db.coerceIn(-EQ_RANGE_DB, EQ_RANGE_DB) })
    }

    fun applyPreset(p: EqPreset) = update {
        it.copy(preampDb = p.preampDb, bandsDb = p.bandsDb, bassPct = p.bassPct, treblePct = p.treblePct, toneOn = p.toneOn)
    }

    fun resetEqualizer() = update {
        it.copy(preampDb = 0f, bandsDb = List(EQ_BANDS) { 0f }, bassPct = 0f, treblePct = 0f)
    }

    fun resetSoundKnobs() = update {
        it.copy(balance = 0f, stereoExpandPct = 0f, mono = false, tempoOn = false, tempo = 1f, volume = 1f)
    }

    fun saveCurrentAsPreset(name: String) {
        val s = _state.value
        val preset = EqPreset(name.trim(), s.preampDb, s.bandsDb, s.bassPct, s.treblePct, s.toneOn)
        if (preset.name.isEmpty()) return
        val next = _userPresets.value.filterNot { it.name.equals(preset.name, ignoreCase = true) } + preset
        _userPresets.value = next
        prefs.edit().putString("presets", presetsToJson(next)).apply()
    }

    fun deletePreset(name: String) {
        val next = _userPresets.value.filterNot { it.name == name }
        _userPresets.value = next
        prefs.edit().putString("presets", presetsToJson(next)).apply()
    }

    private fun push(s: SoundState) {
        SoundEngine.params = s.toDspParams()
        player.setSpeed(if (s.tempoOn) s.tempo else 1f)
        player.setVolume(s.volume)
    }

    private fun save(s: SoundState) {
        prefs.edit()
            .putBoolean("eqOn", s.eqOn)
            .putFloat("preamp", s.preampDb)
            .putString("bands", s.bandsDb.joinToString(","))
            .putBoolean("toneOn", s.toneOn)
            .putFloat("bass", s.bassPct)
            .putFloat("treble", s.treblePct)
            .putBoolean("limiterOn", s.limiterOn)
            .putFloat("balance", s.balance)
            .putFloat("expand", s.stereoExpandPct)
            .putBoolean("mono", s.mono)
            .putBoolean("tempoOn", s.tempoOn)
            .putFloat("tempo", s.tempo)
            .putFloat("volume", s.volume)
            .apply()
    }

    private fun load(): SoundState {
        val d = SoundState()
        val bands = prefs.getString("bands", null)?.split(",")?.mapNotNull { it.toFloatOrNull() }
            ?.takeIf { it.size == EQ_BANDS } ?: d.bandsDb
        return SoundState(
            eqOn = prefs.getBoolean("eqOn", d.eqOn),
            preampDb = prefs.getFloat("preamp", d.preampDb),
            bandsDb = bands,
            toneOn = prefs.getBoolean("toneOn", d.toneOn),
            bassPct = prefs.getFloat("bass", d.bassPct),
            treblePct = prefs.getFloat("treble", d.treblePct),
            limiterOn = prefs.getBoolean("limiterOn", d.limiterOn),
            balance = prefs.getFloat("balance", d.balance),
            stereoExpandPct = prefs.getFloat("expand", d.stereoExpandPct),
            mono = prefs.getBoolean("mono", d.mono),
            tempoOn = prefs.getBoolean("tempoOn", d.tempoOn),
            tempo = prefs.getFloat("tempo", d.tempo),
            volume = prefs.getFloat("volume", d.volume),
        )
    }

    private fun presetsToJson(list: List<EqPreset>): String {
        val arr = JSONArray()
        list.forEach { p ->
            arr.put(
                JSONObject()
                    .put("name", p.name).put("preamp", p.preampDb.toDouble())
                    .put("bands", JSONArray(p.bandsDb.map { it.toDouble() }))
                    .put("bass", p.bassPct.toDouble()).put("treble", p.treblePct.toDouble())
                    .put("tone", p.toneOn)
            )
        }
        return arr.toString()
    }

    private fun loadPresets(): List<EqPreset> {
        val raw = prefs.getString("presets", null) ?: return emptyList()
        return try {
            val arr = JSONArray(raw)
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                val b = o.getJSONArray("bands")
                EqPreset(
                    name = o.getString("name"),
                    preampDb = o.getDouble("preamp").toFloat(),
                    bandsDb = (0 until b.length()).map { b.getDouble(it).toFloat() },
                    bassPct = o.getDouble("bass").toFloat(),
                    treblePct = o.getDouble("treble").toFloat(),
                    toneOn = o.getBoolean("tone"),
                )
            }.filter { it.bandsDb.size == EQ_BANDS }
        } catch (e: Exception) {
            emptyList()
        }
    }
}
