package app.apmplayer.audio

import android.content.Context
import app.apmplayer.playback.PlayerConnection
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONArray
import org.json.JSONObject

/** Holds the sound settings, saves them, and pushes them to the audio chain and the player. */
class SoundController(context: Context, private val player: PlayerConnection) {

    private val prefs = context.getSharedPreferences("sound", Context.MODE_PRIVATE)

    private val _state = MutableStateFlow(load())
    val state: StateFlow<SoundState> = _state.asStateFlow()

    private val _userPresets = MutableStateFlow(loadPresets())
    val userPresets: StateFlow<List<EqPreset>> = _userPresets.asStateFlow()

    private val _userReverbs = MutableStateFlow(loadReverbs())
    val userReverbs: StateFlow<List<ReverbPreset>> = _userReverbs.asStateFlow()

    init {
        push(_state.value)
    }

    fun update(change: (SoundState) -> SoundState) {
        val next = change(_state.value)
        _state.value = next
        push(next)
        save(next)
    }

    // ---- graphic equalizer

    fun setBand(index: Int, db: Float) = update { s ->
        s.copy(bandsDb = s.bandsDb.toMutableList().also { it[index] = db.coerceIn(-EQ_RANGE_DB, EQ_RANGE_DB) })
    }

    // ---- parametric equalizer

    fun setEqMode(mode: Int) = update { it.copy(eqMode = mode) }

    fun addParamBand(): Int {
        val current = _state.value.paramBands
        if (current.size >= MAX_PARAM_BANDS) return current.lastIndex
        update { it.copy(paramBands = it.paramBands + ParamBand(TYPE_PEAK, 1000f)) }
        return _state.value.paramBands.lastIndex
    }

    fun removeParamBand(index: Int) = update { s ->
        if (index in s.paramBands.indices) s.copy(paramBands = s.paramBands.filterIndexed { i, _ -> i != index }) else s
    }

    fun updateParamBand(index: Int, band: ParamBand) = update { s ->
        if (index !in s.paramBands.indices) s
        else s.copy(
            paramBands = s.paramBands.mapIndexed { i, old ->
                if (i == index) {
                    band.copy(
                        freq = band.freq.coerceIn(MIN_FREQ, MAX_FREQ),
                        gainDb = band.gainDb.coerceIn(-EQ_RANGE_DB, EQ_RANGE_DB),
                        q = band.q.coerceIn(MIN_Q, MAX_Q),
                    )
                } else old
            },
        )
    }

    // ---- presets

    fun applyPreset(p: EqPreset) = update {
        if (p.parametric) {
            it.copy(
                eqMode = MODE_PARAMETRIC, preampDb = p.preampDb, paramBands = p.paramBands,
                bassPct = p.bassPct, treblePct = p.treblePct, toneOn = p.toneOn,
            )
        } else {
            it.copy(
                eqMode = MODE_GRAPHIC, preampDb = p.preampDb, bandsDb = p.bandsDb,
                bassPct = p.bassPct, treblePct = p.treblePct, toneOn = p.toneOn,
            )
        }
    }

    fun resetEqualizer() = update {
        if (it.eqMode == MODE_PARAMETRIC) {
            it.copy(preampDb = 0f, paramBands = DEFAULT_PARAM_BANDS, bassPct = 0f, treblePct = 0f)
        } else {
            it.copy(preampDb = 0f, bandsDb = List(EQ_BANDS) { 0f }, bassPct = 0f, treblePct = 0f)
        }
    }

    fun resetSoundKnobs() = update {
        it.copy(balance = 0f, stereoExpandPct = 0f, mono = false, tempoOn = false, tempo = 1f, volume = 1f)
    }

    fun saveCurrentAsPreset(name: String) {
        val s = _state.value
        val clean = name.trim()
        if (clean.isEmpty()) return
        val preset = EqPreset(
            name = clean, preampDb = s.preampDb, bandsDb = s.bandsDb, bassPct = s.bassPct, treblePct = s.treblePct,
            toneOn = s.toneOn, parametric = s.eqMode == MODE_PARAMETRIC, paramBands = s.paramBands,
        )
        val next = _userPresets.value.filterNot { it.name.equals(clean, ignoreCase = true) } + preset
        _userPresets.value = next
        prefs.edit().putString("presets", presetsToJson(next).toString()).apply()
    }

    fun deletePreset(name: String) {
        val next = _userPresets.value.filterNot { it.name == name }
        _userPresets.value = next
        prefs.edit().putString("presets", presetsToJson(next).toString()).apply()
    }

    // ---- reverb

    fun updateReverb(change: (ReverbSettings) -> ReverbSettings) = update { it.copy(reverb = change(it.reverb)) }

    fun applyReverbPreset(p: ReverbPreset) = update { it.copy(reverb = p.settings, reverbOn = true) }

    fun saveReverbPreset(name: String) {
        val clean = name.trim()
        if (clean.isEmpty()) return
        val next = _userReverbs.value.filterNot { it.name.equals(clean, ignoreCase = true) } + ReverbPreset(clean, _state.value.reverb)
        _userReverbs.value = next
        prefs.edit().putString("reverbs", reverbsToJson(next).toString()).apply()
    }

    fun deleteReverbPreset(name: String) {
        val next = _userReverbs.value.filterNot { it.name == name }
        _userReverbs.value = next
        prefs.edit().putString("reverbs", reverbsToJson(next).toString()).apply()
    }

    // ---- share your presets as a small text file, and read them back

    fun exportJson(): String = JSONObject()
        .put("app", "Apm Player Pro")
        .put("version", 1)
        .put("equalizerPresets", presetsToJson(_userPresets.value))
        .put("reverbPresets", reverbsToJson(_userReverbs.value))
        .toString(2)

    /** Adds the presets found in [text]. A preset with the same name is replaced. Returns how many were read, or -1 if the text is not a preset file. */
    fun importJson(text: String): Int {
        return try {
            val root = JSONObject(text)
            val eq = presetsFromJson(root.optJSONArray("equalizerPresets") ?: JSONArray())
            val rv = reverbsFromJson(root.optJSONArray("reverbPresets") ?: JSONArray())
            if (eq.isEmpty() && rv.isEmpty() && !root.has("equalizerPresets") && !root.has("reverbPresets")) return -1
            val eqNext = _userPresets.value.filterNot { old -> eq.any { it.name.equals(old.name, ignoreCase = true) } } + eq
            val rvNext = _userReverbs.value.filterNot { old -> rv.any { it.name.equals(old.name, ignoreCase = true) } } + rv
            _userPresets.value = eqNext
            _userReverbs.value = rvNext
            prefs.edit()
                .putString("presets", presetsToJson(eqNext).toString())
                .putString("reverbs", reverbsToJson(rvNext).toString())
                .apply()
            eq.size + rv.size
        } catch (e: Exception) {
            -1
        }
    }

    // ---- saving and loading

    private fun push(s: SoundState) {
        SoundEngine.params = s.toDspParams()
        player.setSpeed(if (s.tempoOn) s.tempo else 1f)
        player.setVolume(s.volume)
    }

    private fun save(s: SoundState) {
        prefs.edit()
            .putBoolean("eqOn", s.eqOn)
            .putInt("eqMode", s.eqMode)
            .putFloat("preamp", s.preampDb)
            .putString("bands", s.bandsDb.joinToString(","))
            .putString("pbands", s.paramBands.joinToString(";") { "${it.type}:${it.freq}:${it.gainDb}:${it.q}" })
            .putBoolean("toneOn", s.toneOn)
            .putFloat("bass", s.bassPct)
            .putFloat("treble", s.treblePct)
            .putBoolean("limiterOn", s.limiterOn)
            .putFloat("balance", s.balance)
            .putFloat("expand", s.stereoExpandPct)
            .putBoolean("mono", s.mono)
            .putBoolean("tempoOn", s.tempoOn)
            .putFloat("tempo", s.tempo)
            .putFloat("volume", s.volume)
            .putBoolean("reverbOn", s.reverbOn)
            .putString("reverb", reverbToString(s.reverb))
            .apply()
    }

    private fun load(): SoundState {
        val d = SoundState()
        val bands = prefs.getString("bands", null)?.split(",")?.mapNotNull { it.toFloatOrNull() }
            ?.takeIf { it.size == EQ_BANDS } ?: d.bandsDb
        val pbands = if (prefs.contains("pbands")) {
            prefs.getString("pbands", "").orEmpty().split(";").filter { it.isNotBlank() }.mapNotNull { part ->
                val x = part.split(":")
                if (x.size != 4) null
                else ParamBand(x[0].toIntOrNull() ?: TYPE_PEAK, x[1].toFloatOrNull() ?: 1000f, x[2].toFloatOrNull() ?: 0f, x[3].toFloatOrNull() ?: 1f)
            }.take(MAX_PARAM_BANDS)
        } else d.paramBands
        return SoundState(
            eqOn = prefs.getBoolean("eqOn", d.eqOn),
            eqMode = prefs.getInt("eqMode", d.eqMode),
            preampDb = prefs.getFloat("preamp", d.preampDb),
            bandsDb = bands,
            paramBands = pbands,
            toneOn = prefs.getBoolean("toneOn", d.toneOn),
            bassPct = prefs.getFloat("bass", d.bassPct),
            treblePct = prefs.getFloat("treble", d.treblePct),
            limiterOn = prefs.getBoolean("limiterOn", d.limiterOn),
            balance = prefs.getFloat("balance", d.balance),
            stereoExpandPct = prefs.getFloat("expand", d.stereoExpandPct),
            mono = prefs.getBoolean("mono", d.mono),
            tempoOn = prefs.getBoolean("tempoOn", d.tempoOn),
            tempo = prefs.getFloat("tempo", d.tempo),
            volume = prefs.getFloat("volume", d.volume),
            reverbOn = prefs.getBoolean("reverbOn", d.reverbOn),
            reverb = reverbFromString(prefs.getString("reverb", null)) ?: d.reverb,
        )
    }

    private fun reverbToString(r: ReverbSettings) =
        listOf(r.damp, r.filter, r.fade, r.preDelay, r.preDelayMix, r.size, r.mix).joinToString(",")

    private fun reverbFromString(s: String?): ReverbSettings? {
        val v = s?.split(",")?.mapNotNull { it.toFloatOrNull() } ?: return null
        return if (v.size == 7) ReverbSettings(v[0], v[1], v[2], v[3], v[4], v[5], v[6]) else null
    }

    private fun bandToJson(b: ParamBand) = JSONObject()
        .put("type", b.type).put("freq", b.freq.toDouble()).put("gain", b.gainDb.toDouble()).put("q", b.q.toDouble())

    private fun bandFromJson(o: JSONObject) = ParamBand(
        type = o.optInt("type", TYPE_PEAK).coerceIn(TYPE_PEAK, TYPE_HIGH_SHELF),
        freq = o.optDouble("freq", 1000.0).toFloat().coerceIn(MIN_FREQ, MAX_FREQ),
        gainDb = o.optDouble("gain", 0.0).toFloat().coerceIn(-EQ_RANGE_DB, EQ_RANGE_DB),
        q = o.optDouble("q", 1.0).toFloat().coerceIn(MIN_Q, MAX_Q),
    )

    private fun presetsToJson(list: List<EqPreset>): JSONArray {
        val arr = JSONArray()
        list.forEach { p ->
            arr.put(
                JSONObject()
                    .put("name", p.name).put("preamp", p.preampDb.toDouble())
                    .put("bands", JSONArray(p.bandsDb.map { it.toDouble() }))
                    .put("bass", p.bassPct.toDouble()).put("treble", p.treblePct.toDouble())
                    .put("tone", p.toneOn).put("parametric", p.parametric)
                    .put("paramBands", JSONArray(p.paramBands.map { bandToJson(it) }))
            )
        }
        return arr
    }

    private fun presetsFromJson(arr: JSONArray): List<EqPreset> = (0 until arr.length()).mapNotNull { i ->
        try {
            val o = arr.getJSONObject(i)
            val b = o.getJSONArray("bands")
            val bands = (0 until b.length()).map { b.getDouble(it).toFloat().coerceIn(-EQ_RANGE_DB, EQ_RANGE_DB) }
            val pb = o.optJSONArray("paramBands")
            val name = o.getString("name").trim()
            if (name.isEmpty() || bands.size != EQ_BANDS) null
            else EqPreset(
                name = name,
                preampDb = o.optDouble("preamp", 0.0).toFloat(),
                bandsDb = bands,
                bassPct = o.optDouble("bass", 0.0).toFloat(),
                treblePct = o.optDouble("treble", 0.0).toFloat(),
                toneOn = o.optBoolean("tone", false),
                parametric = o.optBoolean("parametric", false),
                paramBands = if (pb == null) emptyList() else (0 until minOf(pb.length(), MAX_PARAM_BANDS)).map { bandFromJson(pb.getJSONObject(it)) },
            )
        } catch (e: Exception) {
            null
        }
    }

    private fun reverbsToJson(list: List<ReverbPreset>): JSONArray {
        val arr = JSONArray()
        list.forEach { p -> arr.put(JSONObject().put("name", p.name).put("values", reverbToString(p.settings))) }
        return arr
    }

    private fun reverbsFromJson(arr: JSONArray): List<ReverbPreset> = (0 until arr.length()).mapNotNull { i ->
        try {
            val o = arr.getJSONObject(i)
            val settings = reverbFromString(o.getString("values"))
            val name = o.getString("name").trim()
            if (settings == null || name.isEmpty()) null else ReverbPreset(name, settings)
        } catch (e: Exception) {
            null
        }
    }

    private fun loadPresets(): List<EqPreset> {
        val raw = prefs.getString("presets", null) ?: return emptyList()
        return try { presetsFromJson(JSONArray(raw)) } catch (e: Exception) { emptyList() }
    }

    private fun loadReverbs(): List<ReverbPreset> {
        val raw = prefs.getString("reverbs", null) ?: return emptyList()
        return try { reverbsFromJson(JSONArray(raw)) } catch (e: Exception) { emptyList() }
    }
}
