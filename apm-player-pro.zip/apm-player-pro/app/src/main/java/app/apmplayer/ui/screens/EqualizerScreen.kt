package app.apmplayer.ui.screens

import app.apmplayer.audio.MODE_PARAMETRIC
import app.apmplayer.audio.MODE_GRAPHIC
import androidx.compose.ui.platform.LocalContext
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.rememberLauncherForActivityResult
import android.widget.Toast
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.material.icons.rounded.RadioButtonChecked
import androidx.compose.material.icons.rounded.SurroundSound
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import app.apmplayer.audio.BUILT_IN_PRESETS
import app.apmplayer.audio.EQ_BANDS
import app.apmplayer.audio.EQ_LABELS
import app.apmplayer.audio.EQ_RANGE_DB
import app.apmplayer.audio.EqPreset
import app.apmplayer.audio.SoundController
import app.apmplayer.ui.components.BoldLabel
import app.apmplayer.ui.components.EqGreen
import app.apmplayer.ui.components.EqSlider
import app.apmplayer.ui.components.Knob
import app.apmplayer.ui.components.OutlinePill
import app.apmplayer.ui.components.TogglePill
import app.apmplayer.ui.components.VolumeRed
import app.apmplayer.ui.components.focusRing
import app.apmplayer.ui.components.oneDecimal
import app.apmplayer.ui.theme.Apm
import app.apmplayer.ui.theme.ApmShape
import app.apmplayer.ui.theme.ApmSpace
import java.util.Locale
import kotlin.math.pow

/** S02 and S03. Three tabs: equalizer, sound knobs, reverb. */
@Composable
fun EqualizerScreen(sound: SoundController) {
    var tab by rememberSaveable { mutableIntStateOf(0) }
    Column(Modifier.fillMaxSize().padding(horizontal = ApmSpace.s2, vertical = ApmSpace.s2)) {
        TabBar(tab) { tab = it }
        when (tab) {
            0 -> GraphicTab(sound)
            1 -> KnobsTab(sound)
            else -> ReverbPanel(sound)
        }
    }
}

@Composable
private fun TabBar(selected: Int, onSelect: (Int) -> Unit) {
    val items: List<Pair<ImageVector, String>> = listOf(
        Icons.Rounded.Tune to "Equalizer",
        Icons.Rounded.RadioButtonChecked to "Sound knobs",
        Icons.Rounded.SurroundSound to "Reverb",
    )
    Row(
        Modifier.fillMaxWidth().height(64.dp).clip(ApmShape.pill).background(Apm.colors.surfaceRaised),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        items.forEachIndexed { i, (icon, label) ->
            Box(
                Modifier.weight(1f).fillMaxHeight().focusRing(ApmShape.pill)
                    .clickable(role = Role.Tab) { onSelect(i) },
                contentAlignment = Alignment.Center,
            ) {
                Icon(
                    icon, contentDescription = label,
                    tint = if (i == selected) Color.White else Color(0xFF7A7A7A),
                    modifier = Modifier.size(32.dp),
                )
            }
        }
    }
}

@Composable
private fun GraphicTab(sound: SoundController) {
    val s by sound.state.collectAsStateWithLifecycle()
    val user by sound.userPresets.collectAsStateWithLifecycle()
    var showPresets by remember { mutableStateOf(false) }
    var showSave by remember { mutableStateOf(false) }
    var showMenu by remember { mutableStateOf(false) }
    val context = LocalContext.current

    // presets as a small text file: save them somewhere, or read a file back
    val exportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) {
            val ok = try {
                context.contentResolver.openOutputStream(uri)?.use { it.write(sound.exportJson().toByteArray(Charsets.UTF_8)) } != null
            } catch (e: Exception) {
                false
            }
            Toast.makeText(context, if (ok) "Presets saved" else "Could not save the file", Toast.LENGTH_SHORT).show()
        }
    }
    val importLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            val text = try {
                context.contentResolver.openInputStream(uri)?.use { it.readBytes().toString(Charsets.UTF_8) }
            } catch (e: Exception) {
                null
            }
            val count = if (text == null) -1 else sound.importJson(text)
            Toast.makeText(context, if (count >= 0) "Added $count presets" else "That file is not a preset file", Toast.LENGTH_SHORT).show()
        }
    }

    Column(Modifier.fillMaxSize().padding(top = ApmSpace.s3)) {
        if (s.eqMode == MODE_PARAMETRIC) {
            ParametricPanel(s, sound, Modifier.weight(1f).fillMaxWidth())
        } else Row(Modifier.weight(1f).fillMaxWidth()) {
            // preamp in its own dark panel
            Column(
                Modifier.width(60.dp).fillMaxHeight().clip(ApmShape.lg).background(Color(0xFF101010))
                    .padding(vertical = ApmSpace.s2),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                EqSlider(
                    value = s.preampDb, range = EQ_RANGE_DB,
                    onChange = { v -> sound.update { it.copy(preampDb = v) } },
                    description = "Preamp", modifier = Modifier.weight(1f).fillMaxWidth(), enabled = s.eqOn,
                )
                BoldLabel("Preamp", oneDecimal(s.preampDb))
            }
            Row(Modifier.weight(1f).fillMaxHeight()) {
                for (i in 0 until EQ_BANDS) {
                    Column(Modifier.weight(1f).fillMaxHeight(), horizontalAlignment = Alignment.CenterHorizontally) {
                        EqSlider(
                            value = s.bandsDb[i], range = EQ_RANGE_DB,
                            onChange = { v -> sound.setBand(i, v) },
                            description = EQ_LABELS[i] + " hertz", modifier = Modifier.weight(1f).fillMaxWidth(),
                            enabled = s.eqOn,
                        )
                        BoldLabel(EQ_LABELS[i], oneDecimal(s.bandsDb[i]))
                    }
                }
            }
        }

        if (s.eqMode != MODE_PARAMETRIC) {
            ResponseGraph(s, Modifier.fillMaxWidth().padding(top = ApmSpace.s2).height(56.dp))
        }

        val status = buildString {
            append("NO DVC ")
            append(if (!s.eqOn) "NO EQ" else if (s.eqMode == MODE_PARAMETRIC) "PEQ ${s.paramBands.size}" else "EQ $EQ_BANDS")
            if (s.reverbOn) append(" REV")
            if (s.toneOn) append(" TON")
            if (s.limiterOn) append(" LMT")
        }
        Text(
            status,
            style = Apm.type.bodySm.copy(fontWeight = FontWeight.Bold),
            color = Color(0xFFCCCCCC),
            modifier = Modifier.align(Alignment.CenterHorizontally).padding(top = ApmSpace.s2)
                .clip(ApmShape.pill).background(Color(0xFF161616)).padding(horizontal = ApmSpace.s4, vertical = ApmSpace.s2),
        )

        Row(
            Modifier.fillMaxWidth().padding(top = ApmSpace.s2),
            horizontalArrangement = Arrangement.spacedBy(ApmSpace.s3),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            TogglePill("Equ", s.eqOn, { sound.update { it.copy(eqOn = !it.eqOn) } })
            OutlinePill("Preset", { showPresets = true }, Modifier.weight(1f))
            Box {
                Box(
                    Modifier.size(48.dp).clip(ApmShape.round).border(1.5.dp, Color(0xFF8A8A8A), ApmShape.round)
                        .focusRing(ApmShape.round).clickable(role = Role.Button) { showMenu = true },
                    contentAlignment = Alignment.Center,
                ) { Icon(Icons.Rounded.MoreVert, contentDescription = "More", tint = Color.White) }
                DropdownMenu(expanded = showMenu, onDismissRequest = { showMenu = false }) {
                    DropdownMenuItem(text = { Text("Save as preset") }, onClick = { showMenu = false; showSave = true })
                    DropdownMenuItem(text = { Text("Reset equalizer") }, onClick = { showMenu = false; sound.resetEqualizer() })
                    DropdownMenuItem(
                        text = { Text(if (s.eqMode == MODE_PARAMETRIC) "Switch to graphic equalizer" else "Switch to parametric equalizer") },
                        onClick = {
                            showMenu = false
                            sound.setEqMode(if (s.eqMode == MODE_PARAMETRIC) MODE_GRAPHIC else MODE_PARAMETRIC)
                        },
                    )
                    DropdownMenuItem(text = { Text("Export presets") }, onClick = { showMenu = false; exportLauncher.launch("apm-player-presets.json") })
                    DropdownMenuItem(
                        text = { Text("Import presets") },
                        onClick = { showMenu = false; importLauncher.launch(arrayOf("application/json", "text/plain", "*/*")) },
                    )
                }
            }
        }

        Row(
            Modifier.fillMaxWidth().padding(top = ApmSpace.s2),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(ApmSpace.s2)) {
                TogglePill("Tone", s.toneOn, { sound.update { it.copy(toneOn = !it.toneOn) } })
                TogglePill("Limit", s.limiterOn, { sound.update { it.copy(limiterOn = !it.limiterOn) } })
            }
            Row(Modifier.weight(1f), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
                KnobWithLabel("Bass", s.bassPct, 0f, 100f, 0f, s.toneOn) { v -> sound.update { it.copy(bassPct = v) } }
                KnobWithLabel("Treble", s.treblePct, 0f, 100f, 0f, s.toneOn) { v -> sound.update { it.copy(treblePct = v) } }
            }
        }
    }

    if (showPresets) {
        PresetDialog(
            builtIn = BUILT_IN_PRESETS, user = user,
            onPick = { sound.applyPreset(it); showPresets = false },
            onDelete = { sound.deletePreset(it.name) },
            onDismiss = { showPresets = false },
        )
    }
    if (showSave) {
        SavePresetDialog(onSave = { sound.saveCurrentAsPreset(it); showSave = false }, onDismiss = { showSave = false })
    }
}

@Composable
private fun KnobWithLabel(
    title: String, value: Float, min: Float, max: Float, default: Float, enabled: Boolean, onChange: (Float) -> Unit,
) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Knob(
            value = value, min = min, max = max, defaultValue = default, onChange = onChange,
            description = title, valueText = "${value.toInt()} percent", size = 84.dp, enabled = enabled,
        )
        BoldLabel(title, "${value.toInt()}%")
    }
}

@Composable
private fun KnobsTab(sound: SoundController) {
    val s by sound.state.collectAsStateWithLifecycle()
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(top = ApmSpace.s4),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(ApmSpace.s3),
    ) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Knob(
                    value = s.balance, min = -1f, max = 1f, defaultValue = 0f,
                    onChange = { v -> sound.update { it.copy(balance = v) } },
                    description = "Balance", valueText = String.format(Locale.ROOT, "%.2f", s.balance), size = 140.dp,
                )
                BoldLabel("Balance", String.format(Locale.ROOT, "%.2f", s.balance))
            }
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Knob(
                    value = s.stereoExpandPct, min = 0f, max = 100f, defaultValue = 0f,
                    onChange = { v -> sound.update { it.copy(stereoExpandPct = v) } },
                    description = "Stereo expand", valueText = "${s.stereoExpandPct.toInt()} percent", size = 140.dp,
                )
                BoldLabel("Stereo Expand", "${s.stereoExpandPct.toInt()}%")
            }
        }

        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.width(110.dp), verticalArrangement = Arrangement.spacedBy(ApmSpace.s2)) {
                TogglePill("Tempo", s.tempoOn, { sound.update { it.copy(tempoOn = !it.tempoOn) } })
            }
            Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                // knob position 0..1 maps to speed 0.5x..2x
                val pos = (kotlin.math.ln(s.tempo / 0.5f) / kotlin.math.ln(4f)).coerceIn(0f, 1f)
                Knob(
                    value = pos, min = 0f, max = 1f, defaultValue = 0.5f,
                    onChange = { v -> sound.update { it.copy(tempo = 0.5f * 4f.pow(v)) } },
                    description = "Tempo", valueText = String.format(Locale.ROOT, "%.2f times", s.tempo),
                    size = 140.dp, enabled = s.tempoOn,
                )
                Text(
                    String.format(Locale.ROOT, "%.2fx", s.tempo),
                    style = Apm.type.bodySm.copy(fontWeight = FontWeight.SemiBold), color = Color(0xFF8A8A8A),
                    modifier = Modifier.alpha(if (s.tempoOn) 1f else 0.4f),
                )
            }
            Column(Modifier.width(64.dp), verticalArrangement = Arrangement.spacedBy(ApmSpace.s2)) {
                StepButton("+", s.tempoOn) { sound.update { it.copy(tempo = (it.tempo + 0.05f).coerceIn(0.5f, 2f)) } }
                StepButton("-", s.tempoOn) { sound.update { it.copy(tempo = (it.tempo - 0.05f).coerceIn(0.5f, 2f)) } }
            }
        }

        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            TogglePill("Mono", s.mono, { sound.update { it.copy(mono = !it.mono) } })
            OutlinePill("Reset", { sound.resetSoundKnobs() })
        }

        val volRing = androidx.compose.ui.graphics.lerp(Color(0xFF14E014), VolumeRed, ((s.volume - 0.5f) / 0.5f).coerceIn(0f, 1f))
        Knob(
            value = s.volume, min = 0f, max = 1f, defaultValue = 1f,
            onChange = { v -> sound.update { it.copy(volume = v) } },
            description = "Volume", valueText = "${(s.volume * 100).toInt()} percent",
            size = 190.dp, ringColor = volRing,
        )
        BoldLabel("Volume", "${(s.volume * 100).toInt()}%")
        Spacer(Modifier.height(ApmSpace.s4))
    }
}

@Composable
private fun StepButton(text: String, enabled: Boolean, onClick: () -> Unit) {
    Box(
        Modifier.fillMaxWidth().height(48.dp).alpha(if (enabled) 1f else 0.4f).clip(ApmShape.lg)
            .background(Color(0xFF1A1A1A)).focusRing(ApmShape.lg)
            .clickable(enabled = enabled, role = Role.Button, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) { Text(text, style = Apm.type.title, color = Color.White) }
}

@Composable
private fun PresetDialog(
    builtIn: List<EqPreset>, user: List<EqPreset>,
    onPick: (EqPreset) -> Unit, onDelete: (EqPreset) -> Unit, onDismiss: () -> Unit,
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = { TextButton(onClick = onDismiss) { Text("Close") } },
        title = { Text("Presets") },
        text = {
            LazyColumn(Modifier.heightIn(max = 380.dp)) {
                items(user, key = { "u" + it.name }) { p ->
                    Row(
                        Modifier.fillMaxWidth().heightIn(min = 48.dp).clickable { onPick(p) },
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Text(p.name, Modifier.weight(1f), style = Apm.type.body, color = Apm.colors.text)
                        TextButton(onClick = { onDelete(p) }) { Text("Delete") }
                    }
                }
                items(builtIn, key = { "b" + it.name }) { p ->
                    Box(Modifier.fillMaxWidth().heightIn(min = 48.dp).clickable { onPick(p) }, contentAlignment = Alignment.CenterStart) {
                        Text(p.name, style = Apm.type.body, color = Apm.colors.text)
                    }
                }
            }
        },
    )
}

@Composable
private fun SavePresetDialog(onSave: (String) -> Unit, onDismiss: () -> Unit) {
    var name by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = { TextButton(onClick = { onSave(name) }, enabled = name.isNotBlank()) { Text("Save") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
        title = { Text("Save preset") },
        text = { OutlinedTextField(value = name, onValueChange = { name = it }, singleLine = true, label = { Text("Name") }) },
    )
}
