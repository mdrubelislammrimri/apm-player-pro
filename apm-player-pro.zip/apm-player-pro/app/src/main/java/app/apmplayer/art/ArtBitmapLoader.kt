
package app.apmplayer.art

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import androidx.media3.common.util.BitmapLoader
import com.google.common.util.concurrent.ListenableFuture
import com.google.common.util.concurrent.MoreExecutors
import java.io.FileNotFoundException
import java.util.concurrent.Executors

/**
 * Gives the notification, lock screen and Bluetooth devices the cover picture of the song.
 * The song's own file address is used as the picture address, and the cover is read from inside the file.
 */
class ArtBitmapLoader(private val art: ArtLoader) : BitmapLoader {
    private val executor = MoreExecutors.listeningDecorator(Executors.newFixedThreadPool(2))

    override fun supportsMimeType(mimeType: String): Boolean = mimeType.startsWith("image/")

    override fun decodeBitmap(data: ByteArray): ListenableFuture<Bitmap> = executor.submit<Bitmap> {
        BitmapFactory.decodeByteArray(data, 0, data.size) ?: throw IllegalArgumentException("Not a picture")
    }

    override fun loadBitmap(uri: Uri): ListenableFuture<Bitmap> = executor.submit<Bitmap> {
        // a picture the user chose is a file in the app's folder, otherwise the cover is read from inside the song
        (if (uri.scheme == "file") BitmapFactory.decodeFile(uri.path) else art.read(uri, 512)) ?: throw FileNotFoundException("This song has no cover")
    }
}
