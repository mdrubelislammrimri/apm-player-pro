package app.apmplayer.util

import java.util.Locale

/** Letter shown in the A to Z index for a title. Anything that does not start with A to Z goes under '#'. */
fun indexLetter(title: String): Char {
    val c = title.trim().firstOrNull()?.toString()?.uppercase(Locale.ROOT)?.firstOrNull() ?: return '#'
    return if (c in 'A'..'Z') c else '#'
}
