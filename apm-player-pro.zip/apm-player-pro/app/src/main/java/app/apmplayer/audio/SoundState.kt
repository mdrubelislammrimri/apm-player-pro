package app.apmplayer.audio

const val EQ_BANDS = 10
val EQ_FREQS = intArrayOf(31, 62, 125, 250, 500, 1000, 2000, 4000, 8000, 16000)
val EQ_LABELS = listOf("31", "62", "125", "250", "500", "1K", "2K", "4K", "8K", "16K")
const val EQ_RANGE_DB = 15f

/** Everything the sound controls change. Saved on the phone, so it survives closing the app. */
data class SoundState(
    val eqOn: Boolean = true,
    val preampDb: Float = 0f,
    val bandsDb: List<Float> = List(EQ_BANDS) { 0f },
    val toneOn: Boolean = false,
    val bassPct: Float = 0f,
    val treblePct: Float = 0f,
    val limiterOn: Boolean = true,
    val balance: Float = 0f,
    val stereoExpandPct: Float = 0f,
    val mono: Boolean = false,
    val tempoOn: Boolean = false,
    val tempo: Float = 1f,
    val volume: Float = 1f,
) {
    fun toDspParams() = DspParams(
        eqOn = eqOn, preampDb = preampDb, bandsDb = bandsDb,
        toneOn = toneOn, bassPct = bassPct, treblePct = treblePct,
        limiterOn = limiterOn, balance = balance, stereoExpandPct = stereoExpandPct, mono = mono,
    )
}

/** What the audio thread reads. A new object is made for every change, so the thread only compares references. */
class DspParams(
    val eqOn: Boolean = true,
    val preampDb: Float = 0f,
    val bandsDb: List<Float> = List(EQ_BANDS) { 0f },
    val toneOn: Boolean = false,
    val bassPct: Float = 0f,
    val treblePct: Float = 0f,
    val limiterOn: Boolean = true,
    val balance: Float = 0f,
    val stereoExpandPct: Float = 0f,
    val mono: Boolean = false,
)

object SoundEngine {
    @Volatile
    var params: DspParams = DspParams()
}

data class EqPreset(
    val name: String,
    val preampDb: Float,
    val bandsDb: List<Float>,
    val bassPct: Float = 0f,
    val treblePct: Float = 0f,
    val toneOn: Boolean = false,
    val builtIn: Boolean = false,
)

/** Starting points, written for this app. Gains in dB for 31 Hz to 16 kHz. */
val BUILT_IN_PRESETS: List<EqPreset> = listOf(
    "Flat" to listOf(0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f),
    "Bass boost" to listOf(6f, 5f, 4f, 2f, 0f, 0f, 0f, 0f, 0f, 0f),
    "Treble boost" to listOf(0f, 0f, 0f, 0f, 0f, 1f, 2f, 3f, 4f, 5f),
    "Bass and treble" to listOf(5f, 4f, 2f, 0f, -1f, -1f, 0f, 2f, 4f, 5f),
    "Rock" to listOf(4f, 3f, 2f, 0f, -1f, -1f, 1f, 3f, 4f, 4f),
    "Pop" to listOf(-1f, 1f, 3f, 4f, 3f, 0f, -1f, -1f, 1f, 2f),
    "Jazz" to listOf(3f, 2f, 1f, 2f, -2f, -2f, 0f, 1f, 2f, 3f),
    "Classical" to listOf(0f, 0f, 0f, 0f, 0f, 0f, -2f, -2f, -2f, -3f),
    "Vocal" to listOf(-2f, -2f, -1f, 1f, 3f, 3f, 2f, 1f, 0f, -1f),
    "Loudness" to listOf(5f, 3f, 0f, 0f, -1f, 0f, 0f, 0f, 3f, 4f),
).map { (name, bands) -> EqPreset(name, preampDb = 0f, bandsDb = bands, builtIn = true) }
