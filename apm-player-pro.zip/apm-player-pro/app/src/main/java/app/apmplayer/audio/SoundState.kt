package app.apmplayer.audio

const val EQ_BANDS = 10
val EQ_FREQS = intArrayOf(31, 62, 125, 250, 500, 1000, 2000, 4000, 8000, 16000)
val EQ_LABELS = listOf("31", "62", "125", "250", "500", "1K", "2K", "4K", "8K", "16K")
const val EQ_RANGE_DB = 15f

const val MODE_GRAPHIC = 0
const val MODE_PARAMETRIC = 1

const val TYPE_PEAK = 0
const val TYPE_LOW_SHELF = 1
const val TYPE_HIGH_SHELF = 2
const val MAX_PARAM_BANDS = 10
const val MIN_FREQ = 20f
const val MAX_FREQ = 20000f
const val MIN_Q = 0.2f
const val MAX_Q = 10f

/** One filter of the parametric equalizer: what kind, where, how much, how wide. */
data class ParamBand(
    val type: Int = TYPE_PEAK,
    val freq: Float = 1000f,
    val gainDb: Float = 0f,
    val q: Float = 1.0f,
)

val DEFAULT_PARAM_BANDS = listOf(
    ParamBand(TYPE_LOW_SHELF, 80f),
    ParamBand(TYPE_PEAK, 250f),
    ParamBand(TYPE_PEAK, 1000f),
    ParamBand(TYPE_PEAK, 4000f),
    ParamBand(TYPE_HIGH_SHELF, 10000f),
)

/** Knobs of the reverb tab, all 0 to 1. Pre-delay 1.0 means 100 milliseconds. */
data class ReverbSettings(
    val damp: Float = 0.5f,
    val filter: Float = 0.2f,
    val fade: Float = 0.2f,
    val preDelay: Float = 0f,
    val preDelayMix: Float = 0.5f,
    val size: Float = 0.5f,
    val mix: Float = 0.3f,
)

data class ReverbPreset(val name: String, val settings: ReverbSettings, val builtIn: Boolean = false)

val BUILT_IN_REVERBS: List<ReverbPreset> = listOf(
    ReverbPreset("Room", ReverbSettings(damp = 0.6f, filter = 0.2f, fade = 0.3f, preDelay = 0.05f, preDelayMix = 0.4f, size = 0.3f, mix = 0.25f), true),
    ReverbPreset("Auditorium", ReverbSettings(damp = 0.5f, filter = 0.15f, fade = 0.2f, preDelay = 0.15f, preDelayMix = 0.5f, size = 0.6f, mix = 0.3f), true),
    ReverbPreset("Great Hall", ReverbSettings(damp = 0.4f, filter = 0.1f, fade = 0.1f, preDelay = 0.25f, preDelayMix = 0.5f, size = 0.8f, mix = 0.35f), true),
    ReverbPreset("Stadium", ReverbSettings(damp = 0.3f, filter = 0.1f, fade = 0f, preDelay = 0.4f, preDelayMix = 0.6f, size = 1f, mix = 0.4f), true),
    ReverbPreset("Cathedral", ReverbSettings(damp = 0.35f, filter = 0.15f, fade = 0.05f, preDelay = 0.3f, preDelayMix = 0.5f, size = 0.95f, mix = 0.4f), true),
)

/** Everything the sound controls change. Saved on the phone, so it survives closing the app. */
data class SoundState(
    val eqOn: Boolean = true,
    val eqMode: Int = MODE_GRAPHIC,
    val preampDb: Float = 0f,
    val bandsDb: List<Float> = List(EQ_BANDS) { 0f },
    val paramBands: List<ParamBand> = DEFAULT_PARAM_BANDS,
    val toneOn: Boolean = false,
    val bassPct: Float = 0f,
    val treblePct: Float = 0f,
    val limiterOn: Boolean = true,
    val balance: Float = 0f,
    val stereoExpandPct: Float = 0f,
    val mono: Boolean = false,
    val tempoOn: Boolean = false,
    val tempo: Float = 1f,
    val volume: Float = 1f,
    val reverbOn: Boolean = false,
    val reverb: ReverbSettings = ReverbSettings(),
) {
    fun toDspParams() = DspParams(
        eqOn = eqOn, parametric = eqMode == MODE_PARAMETRIC, preampDb = preampDb, bandsDb = bandsDb, paramBands = paramBands,
        toneOn = toneOn, bassPct = bassPct, treblePct = treblePct,
        limiterOn = limiterOn, balance = balance, stereoExpandPct = stereoExpandPct, mono = mono,
        reverbOn = reverbOn, reverb = reverb,
    )
}

/** What the audio thread reads. A new object is made for every change, so the thread only compares references. */
class DspParams(
    val eqOn: Boolean = true,
    val parametric: Boolean = false,
    val preampDb: Float = 0f,
    val bandsDb: List<Float> = List(EQ_BANDS) { 0f },
    val paramBands: List<ParamBand> = emptyList(),
    val toneOn: Boolean = false,
    val bassPct: Float = 0f,
    val treblePct: Float = 0f,
    val limiterOn: Boolean = true,
    val balance: Float = 0f,
    val stereoExpandPct: Float = 0f,
    val mono: Boolean = false,
    val reverbOn: Boolean = false,
    val reverb: ReverbSettings = ReverbSettings(),
)

object SoundEngine {
    @Volatile
    var params: DspParams = DspParams()

    /** Replay gain of the playing song, as a multiplier. 1.0 changes nothing. */
    @Volatile
    var replayGain: Double = 1.0

    /** Lowers the volume while another app speaks (audio focus). 1.0 changes nothing. */
    @Volatile
    var duck: Double = 1.0

    /** On: the sound passes through untouched (bit perfect output). */
    @Volatile
    var bypass: Boolean = false

    /** On: a tiny noise is added before the sound is cut to 16 bit, which hides rounding errors. */
    @Volatile
    var ditherType: Int = 0

    /** Lowers the sound when Direct Volume Control is off, to leave room for the equalizer. As a multiplier. */
    @Volatile
    var headroom: Double = 1.0

    /** True while the volume knob moves the phone's own volume. */
    val dvcActive = kotlinx.coroutines.flow.MutableStateFlow(false)
}

/** A saved equalizer setup. [parametric] says which of the two band sets the preset is about. */
data class EqPreset(
    val name: String,
    val preampDb: Float,
    val bandsDb: List<Float>,
    val bassPct: Float = 0f,
    val treblePct: Float = 0f,
    val toneOn: Boolean = false,
    val builtIn: Boolean = false,
    val parametric: Boolean = false,
    val paramBands: List<ParamBand> = emptyList(),
)

/** Starting points, written for this app. Gains in dB for 31 Hz to 16 kHz. */
val BUILT_IN_PRESETS: List<EqPreset> = listOf(
    "Flat" to listOf(0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f),
    "Bass boost" to listOf(6f, 5f, 4f, 2f, 0f, 0f, 0f, 0f, 0f, 0f),
    "Treble boost" to listOf(0f, 0f, 0f, 0f, 0f, 1f, 2f, 3f, 4f, 5f),
    "Bass and treble" to listOf(5f, 4f, 2f, 0f, -1f, -1f, 0f, 2f, 4f, 5f),
    "Rock" to listOf(4f, 3f, 2f, 0f, -1f, -1f, 1f, 3f, 4f, 4f),
    "Pop" to listOf(-1f, 1f, 3f, 4f, 3f, 0f, -1f, -1f, 1f, 2f),
    "Jazz" to listOf(3f, 2f, 1f, 2f, -2f, -2f, 0f, 1f, 2f, 3f),
    "Classical" to listOf(0f, 0f, 0f, 0f, 0f, 0f, -2f, -2f, -2f, -3f),
    "Vocal" to listOf(-2f, -2f, -1f, 1f, 3f, 3f, 2f, 1f, 0f, -1f),
    "Loudness" to listOf(5f, 3f, 0f, 0f, -1f, 0f, 0f, 0f, 3f, 4f),
).map { (name, bands) -> EqPreset(name, preampDb = 0f, bandsDb = bands, builtIn = true) }
