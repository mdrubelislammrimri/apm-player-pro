package app.apmplayer.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import app.apmplayer.ui.components.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import app.apmplayer.audio.BUILT_IN_REVERBS
import app.apmplayer.audio.Biquads
import app.apmplayer.audio.EQ_BANDS
import app.apmplayer.audio.EQ_FREQS
import app.apmplayer.audio.EQ_RANGE_DB
import app.apmplayer.audio.MAX_FREQ
import app.apmplayer.audio.MAX_PARAM_BANDS
import app.apmplayer.audio.MAX_Q
import app.apmplayer.audio.MIN_FREQ
import app.apmplayer.audio.MIN_Q
import app.apmplayer.audio.MODE_PARAMETRIC
import app.apmplayer.audio.ParamBand
import app.apmplayer.audio.ReverbPreset
import app.apmplayer.audio.ReverbSettings
import app.apmplayer.audio.SoundController
import app.apmplayer.audio.SoundState
import app.apmplayer.audio.TYPE_HIGH_SHELF
import app.apmplayer.audio.TYPE_LOW_SHELF
import app.apmplayer.audio.TYPE_PEAK
import app.apmplayer.ui.components.BoldLabel
import app.apmplayer.ui.components.EqGreen
import app.apmplayer.ui.components.Knob
import app.apmplayer.ui.components.OutlinePill
import app.apmplayer.ui.components.TogglePill
import app.apmplayer.ui.components.focusRing
import app.apmplayer.ui.components.oneDecimal
import app.apmplayer.ui.theme.Apm
import app.apmplayer.ui.theme.ApmShape
import app.apmplayer.ui.theme.ApmSpace
import java.util.Locale
import kotlin.math.abs
import kotlin.math.ln
import kotlin.math.log10
import kotlin.math.max
import kotlin.math.pow

private const val CURVE_POINTS = 120

/** How much the whole equalizer changes the sound at 120 pitches from 20 Hz to 20 kHz, in dB. */
private fun responseCurve(s: SoundState): DoubleArray {
    val out = DoubleArray(CURVE_POINTS)
    if (!s.eqOn) return out
    val fs = 48000.0
    val filters = ArrayList<DoubleArray>()
    if (s.eqMode == MODE_PARAMETRIC) {
        for (b in s.paramBands) {
            if (abs(b.gainDb) >= 0.05f) filters += DoubleArray(5).also { Biquads.forBand(b, fs, it) }
        }
    } else {
        for (i in 0 until EQ_BANDS) {
            if (abs(s.bandsDb[i]) >= 0.05f) {
                filters += DoubleArray(5).also { Biquads.peaking(EQ_FREQS[i].toDouble(), s.bandsDb[i].toDouble(), 1.41, fs, it) }
            }
        }
    }
    if (s.toneOn) {
        if (s.bassPct >= 0.5f) filters += DoubleArray(5).also { Biquads.shelf(100.0, s.bassPct / 100.0 * 12.0, fs, true, it) }
        if (s.treblePct >= 0.5f) filters += DoubleArray(5).also { Biquads.shelf(6000.0, s.treblePct / 100.0 * 12.0, fs, false, it) }
    }
    for (k in 0 until CURVE_POINTS) {
        val f = 20.0 * 1000.0.pow(k.toDouble() / (CURVE_POINTS - 1))
        var db = s.preampDb.toDouble()
        for (c in filters) db += Biquads.magnitudeDb(c, f, fs)
        out[k] = db
    }
    return out
}

/** The shape the equalizer gives to the sound, drawn as one green line. Works for both modes. */
@Composable
fun ResponseGraph(s: SoundState, modifier: Modifier = Modifier) {
    val curve = remember(s.eqOn, s.eqMode, s.bandsDb, s.paramBands, s.preampDb, s.toneOn, s.bassPct, s.treblePct) { responseCurve(s) }
    Box(modifier.clip(ApmShape.lg).background(Color(0xFF262626))) {
        Canvas(Modifier.fillMaxSize()) {
            val pad = 6.dp.toPx()
            val mid = size.height / 2f
            fun yFor(db: Double): Float = mid - (db.toFloat().coerceIn(-EQ_RANGE_DB, EQ_RANGE_DB) / EQ_RANGE_DB) * (mid - pad)
            drawLine(Color(0xFF444444), Offset(0f, mid), Offset(size.width, mid), strokeWidth = 1.dp.toPx())
            for (f in listOf(100.0, 1000.0, 10000.0)) {
                val x = size.width * (log10(f / 20.0) / 3.0).toFloat()
                drawLine(Color(0xFF363636), Offset(x, 0f), Offset(x, size.height), strokeWidth = 1.dp.toPx())
            }
            var prev: Offset? = null
            for (i in curve.indices) {
                val p = Offset(size.width * i / (curve.size - 1), yFor(curve[i]))
                prev?.let { drawLine(EqGreen, it, p, strokeWidth = 2.5.dp.toPx(), cap = StrokeCap.Round) }
                prev = p
            }
        }
    }
}

private fun freqText(f: Float): String =
    if (f >= 1000f) String.format(Locale.ROOT, "%.1f kHz", f / 1000f) else String.format(Locale.ROOT, "%d Hz", f.toInt())

private fun freqToKnob(f: Float): Float = (ln(f / MIN_FREQ) / ln(MAX_FREQ / MIN_FREQ)).coerceIn(0f, 1f)
private fun knobToFreq(v: Float): Float = MIN_FREQ * (MAX_FREQ / MIN_FREQ).pow(v)
private fun qToKnob(q: Float): Float = (ln(q / MIN_Q) / ln(MAX_Q / MIN_Q)).coerceIn(0f, 1f)
private fun knobToQ(v: Float): Float = MIN_Q * (MAX_Q / MIN_Q).pow(v)

@Composable
private fun SmallChip(text: String, sub: String?, selected: Boolean, onClick: () -> Unit) {
    Column(
        Modifier
            .heightIn(min = 48.dp)
            .clip(ApmShape.pill)
            .background(if (selected) Color(0xFF3A3A3A) else Color(0xFF1C1C1C))
            .focusRing(ApmShape.pill)
            .clickable(role = Role.Tab, onClick = onClick)
            .padding(horizontal = ApmSpace.s4, vertical = ApmSpace.s1),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Text(text, style = Apm.type.body.copy(fontWeight = FontWeight.Bold), color = if (selected) Color.White else Color(0xFFA0A0A0))
        if (sub != null) Text(sub, style = Apm.type.label, color = Color(0xFF8A8A8A))
    }
}

/** The parametric equalizer: pick a filter, choose its kind, then turn frequency, gain and width. Up to 10 filters. */
@Composable
fun ParametricPanel(s: SoundState, sound: SoundController, modifier: Modifier = Modifier) {
    var selected by rememberSaveable { mutableStateOf(0) }
    val bands = s.paramBands
    val sel = selected.coerceIn(0, max(0, bands.lastIndex))

    Column(
        modifier.verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(ApmSpace.s2),
    ) {
        ResponseGraph(s, Modifier.fillMaxWidth().height(150.dp))

        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            BoldLabel("Preamp", oneDecimal(s.preampDb) + " dB", Modifier.padding(end = ApmSpace.s3))
            Slider(
                value = s.preampDb, onValueChange = { v -> sound.update { it.copy(preampDb = v) } },
                valueRange = -EQ_RANGE_DB..EQ_RANGE_DB,
                colors = SliderDefaults.colors(thumbColor = EqGreen, activeTrackColor = EqGreen, inactiveTrackColor = Color(0xFF444444)),
                modifier = Modifier.weight(1f),
            )
        }

        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(ApmSpace.s2)) {
            bands.forEachIndexed { i, b -> SmallChip("${i + 1}", freqText(b.freq), i == sel) { selected = i } }
            if (bands.size < MAX_PARAM_BANDS) SmallChip("+", "add", false) { selected = sound.addParamBand() }
        }

        if (bands.isEmpty()) {
            Text(
                "No filters yet. Tap + to add one.", style = Apm.type.bodySm, color = Apm.colors.textMuted,
                modifier = Modifier.padding(ApmSpace.s3),
            )
        } else {
            val b = bands[sel]
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(ApmSpace.s2)) {
                SmallChip("Peak", null, b.type == TYPE_PEAK) { sound.updateParamBand(sel, b.copy(type = TYPE_PEAK)) }
                SmallChip("Low shelf", null, b.type == TYPE_LOW_SHELF) { sound.updateParamBand(sel, b.copy(type = TYPE_LOW_SHELF)) }
                SmallChip("High shelf", null, b.type == TYPE_HIGH_SHELF) { sound.updateParamBand(sel, b.copy(type = TYPE_HIGH_SHELF)) }
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.Top) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Knob(
                        value = freqToKnob(b.freq), min = 0f, max = 1f, defaultValue = freqToKnob(1000f),
                        onChange = { v -> sound.updateParamBand(sel, b.copy(freq = knobToFreq(v))) },
                        description = "Frequency", valueText = freqText(b.freq), size = 92.dp,
                    )
                    BoldLabel("Frequency", freqText(b.freq))
                }
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Knob(
                        value = b.gainDb, min = -EQ_RANGE_DB, max = EQ_RANGE_DB, defaultValue = 0f,
                        onChange = { v -> sound.updateParamBand(sel, b.copy(gainDb = v)) },
                        description = "Gain", valueText = oneDecimal(b.gainDb) + " decibels", size = 92.dp,
                    )
                    BoldLabel("Gain", oneDecimal(b.gainDb) + " dB")
                }
                Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.alpha(if (b.type == TYPE_PEAK) 1f else 0.4f)) {
                    Knob(
                        value = qToKnob(b.q), min = 0f, max = 1f, defaultValue = qToKnob(1f),
                        onChange = { v -> sound.updateParamBand(sel, b.copy(q = knobToQ(v))) },
                        description = "Width", valueText = oneDecimal(b.q), size = 92.dp, enabled = b.type == TYPE_PEAK,
                    )
                    BoldLabel("Q width", oneDecimal(b.q))
                }
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center) {
                OutlinePill("Remove this filter", {
                    sound.removeParamBand(sel)
                    selected = max(0, sel - 1)
                })
            }
        }
    }
}

@Composable
private fun ReverbKnob(name: String, value: Float, text: String, enabled: Boolean, onChange: (Float) -> Unit) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Knob(
            value = value, min = 0f, max = 1f, defaultValue = 0f, onChange = onChange,
            description = name, valueText = text, size = 84.dp, enabled = enabled,
        )
        BoldLabel(name, text, Modifier.alpha(if (enabled) 1f else 0.4f))
    }
}

/** The reverb tab: seven knobs, an on/off pill, presets you can save. The sound is made in the audio chain. */
@Composable
fun ReverbPanel(sound: SoundController) {
    val s by sound.state.collectAsStateWithLifecycle()
    val user by sound.userReverbs.collectAsStateWithLifecycle()
    val on = s.reverbOn
    val r = s.reverb
    var showPresets by remember { mutableStateOf(false) }
    var showSave by remember { mutableStateOf(false) }
    fun two(v: Float) = String.format(Locale.ROOT, "%.2f", v)

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(top = ApmSpace.s4),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(ApmSpace.s3),
    ) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
            ReverbKnob("Damp", r.damp, two(r.damp), on) { v -> sound.updateReverb { it.copy(damp = v) } }
            ReverbKnob("Filter", r.filter, two(r.filter), on) { v -> sound.updateReverb { it.copy(filter = v) } }
            ReverbKnob("Fade", r.fade, two(r.fade), on) { v -> sound.updateReverb { it.copy(fade = v) } }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
            ReverbKnob("Pre-Delay", r.preDelay, "${(r.preDelay * 100).toInt()} ms", on) { v -> sound.updateReverb { it.copy(preDelay = v) } }
            ReverbKnob("Pre-Delay Mix", r.preDelayMix, two(r.preDelayMix), on) { v -> sound.updateReverb { it.copy(preDelayMix = v) } }
            ReverbKnob("Size", r.size, two(r.size), on) { v -> sound.updateReverb { it.copy(size = v) } }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(ApmSpace.s2), verticalAlignment = Alignment.CenterVertically) {
            TogglePill("Reverb", on, { sound.update { it.copy(reverbOn = !it.reverbOn) } })
            OutlinePill("Preset", { showPresets = true }, Modifier.weight(1f))
            OutlinePill("Save", { showSave = true })
            OutlinePill("Reset", { sound.updateReverb { ReverbSettings() } })
        }
        ReverbKnob("Mix", r.mix, two(r.mix), on) { v -> sound.updateReverb { it.copy(mix = v) } }
        Text(
            "Turn Reverb on first. The knobs change the room: Size is how long the sound hangs, Fade how fast it dies, Damp how dull it gets.",
            style = Apm.type.caption, color = Apm.colors.textMuted, textAlign = TextAlign.Center,
            modifier = Modifier.padding(horizontal = ApmSpace.s4),
        )
    }

    if (showPresets) {
        ReverbPresetDialog(
            builtIn = BUILT_IN_REVERBS, user = user,
            onPick = { sound.applyReverbPreset(it); showPresets = false },
            onDelete = { sound.deleteReverbPreset(it.name) },
            onDismiss = { showPresets = false },
        )
    }
    if (showSave) {
        NameDialog("Save reverb preset", "", "Save", { showSave = false }) { name ->
            sound.saveReverbPreset(name)
            showSave = false
        }
    }
}

@Composable
private fun ReverbPresetDialog(
    builtIn: List<ReverbPreset>, user: List<ReverbPreset>,
    onPick: (ReverbPreset) -> Unit, onDelete: (ReverbPreset) -> Unit, onDismiss: () -> Unit,
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = { TextButton(onClick = onDismiss) { Text("Close") } },
        title = { Text("Reverb presets") },
        text = {
            LazyColumn(Modifier.heightIn(max = 380.dp)) {
                items(user, key = { "u" + it.name }) { p ->
                    Row(Modifier.fillMaxWidth().heightIn(min = 48.dp).clickable { onPick(p) }, verticalAlignment = Alignment.CenterVertically) {
                        Text(p.name, Modifier.weight(1f), style = Apm.type.body, color = Apm.colors.text)
                        TextButton(onClick = { onDelete(p) }) { Text("Delete") }
                    }
                }
                items(builtIn, key = { "b" + it.name }) { p ->
                    Box(Modifier.fillMaxWidth().heightIn(min = 48.dp).clickable { onPick(p) }, contentAlignment = Alignment.CenterStart) {
                        Text(p.name, style = Apm.type.body, color = Apm.colors.text)
                    }
                }
            }
        },
    )
}
