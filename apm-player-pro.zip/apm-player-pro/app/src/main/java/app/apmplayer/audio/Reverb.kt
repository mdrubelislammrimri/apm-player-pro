package app.apmplayer.audio

import kotlin.math.max

/**
 * A room reverb built from the classic recipe: 8 comb filters in parallel and 4 all-pass filters in a row for each ear,
 * plus a pre-delay and a soft filter on the wet sound. Simulated before writing: the tail always fades, even at the
 * largest size, and the wet level was set to be about as loud as the dry sound.
 */
class ReverbEngine(private val sampleRate: Int) {

    private class Comb(n: Int) {
        val buf = DoubleArray(max(1, n))
        var i = 0
        var store = 0.0
        fun process(x: Double, feedback: Double, damp: Double): Double {
            val out = buf[i]
            store = out * (1.0 - damp) + store * damp
            buf[i] = x + store * feedback
            i++
            if (i == buf.size) i = 0
            return out
        }
    }

    private class AllPass(n: Int) {
        val buf = DoubleArray(max(1, n))
        var i = 0
        fun process(x: Double): Double {
            val held = buf[i]
            val out = -x + held
            buf[i] = x + held * 0.5
            i++
            if (i == buf.size) i = 0
            return out
        }
    }

    private val scale = sampleRate / 44100.0
    private val combsL = Array(8) { Comb((COMB[it] * scale).toInt()) }
    private val combsR = Array(8) { Comb(((COMB[it] + SPREAD) * scale).toInt()) }
    private val allL = Array(4) { AllPass((ALLPASS[it] * scale).toInt()) }
    private val allR = Array(4) { AllPass(((ALLPASS[it] + SPREAD) * scale).toInt()) }

    private val preLen = (0.1 * sampleRate).toInt() + 2
    private val preL = DoubleArray(preLen)
    private val preR = DoubleArray(preLen)
    private var preWrite = 0

    private var feedback = 0.8
    private var damp = 0.3
    private var lowpass = 0.0
    private var preSamples = 0
    private var preMix = 0.5
    private var filterL = 0.0
    private var filterR = 0.0

    /** The reverb sound for the last frame given to [process]. */
    var wetL = 0.0
        private set
    var wetR = 0.0
        private set

    /** All knobs are 0 to 1. Size sets how long the tail is, Fade how fast it dies, Damp how dull it gets. */
    fun configure(s: ReverbSettings) {
        feedback = (0.68 + s.size * 0.30) * (1.0 - s.fade * 0.25)
        damp = s.damp * 0.7
        lowpass = s.filter * 0.9
        preSamples = (s.preDelay * 0.1 * sampleRate).toInt().coerceIn(0, preLen - 1)
        preMix = s.preDelayMix.toDouble()
    }

    fun process(l: Double, r: Double) {
        preL[preWrite] = l
        preR[preWrite] = r
        val readAt = (preWrite - preSamples + preLen) % preLen
        preWrite++
        if (preWrite == preLen) preWrite = 0
        val inL = l * (1.0 - preMix) + preL[readAt] * preMix
        val inR = r * (1.0 - preMix) + preR[readAt] * preMix
        val input = (inL + inR) * 0.015

        var sumL = 0.0
        var sumR = 0.0
        for (c in combsL) sumL += c.process(input, feedback, damp)
        for (c in combsR) sumR += c.process(input, feedback, damp)
        for (a in allL) sumL = a.process(sumL)
        for (a in allR) sumR = a.process(sumR)

        filterL = sumL * (1.0 - lowpass) + filterL * lowpass
        filterR = sumR * (1.0 - lowpass) + filterR * lowpass
        wetL = filterL
        wetR = filterR
    }

    private companion object {
        val COMB = intArrayOf(1116, 1188, 1277, 1356, 1422, 1491, 1557, 1617)
        val ALLPASS = intArrayOf(556, 441, 341, 225)
        const val SPREAD = 23
    }
}
