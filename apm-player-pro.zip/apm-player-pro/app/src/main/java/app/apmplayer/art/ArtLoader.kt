package app.apmplayer.art

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.util.LruCache
import android.util.Size
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext

/** Finds the cover picture inside a song file and keeps recent ones in memory. */
class ArtLoader(private val context: Context) {

    private val cache = object : LruCache<String, Bitmap>(24 * 1024 * 1024) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount
    }
    private val noArt = HashSet<Long>()
    private val gate = Semaphore(3) // a few pictures at a time, so a fast scroll does not freeze the phone

    /** Forgets every picture held in memory, and the list of songs that had none. */
    fun clearCache() {
        cache.evictAll()
        synchronized(noArt) { noArt.clear() }
    }

    /** Returns the cover, or null when the song has none. [sizePx] is the wanted size of the longest side. */
    suspend fun load(trackId: Long, uri: String, sizePx: Int): Bitmap? {
        val key = "$trackId@$sizePx"
        cache.get(key)?.let { return it }
        if (synchronized(noArt) { trackId in noArt }) return null
        return gate.withPermit {
            cache.get(key)?.let { return@withPermit it }
            val bitmap = withContext(Dispatchers.IO) { read(Uri.parse(uri), sizePx) }
            if (bitmap == null) synchronized(noArt) { noArt += trackId } else cache.put(key, bitmap)
            bitmap
        }
    }

    /** Reads the cover now, on the calling thread. Null when the song has none. */
    fun read(uri: Uri, sizePx: Int): Bitmap? {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            try {
                return context.contentResolver.loadThumbnail(uri, Size(sizePx, sizePx), null)
            } catch (e: Exception) {
                // no thumbnail from the system, try reading the picture inside the file
            }
        }
        val retriever = MediaMetadataRetriever()
        return try {
            retriever.setDataSource(context, uri)
            val bytes = retriever.embeddedPicture ?: return null
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
            var sample = 1
            while (bounds.outWidth / (sample * 2) >= sizePx && bounds.outHeight / (sample * 2) >= sizePx) sample *= 2
            BitmapFactory.decodeByteArray(bytes, 0, bytes.size, BitmapFactory.Options().apply { inSampleSize = sample })
        } catch (e: Exception) {
            null
        } finally {
            try { retriever.release() } catch (e: Exception) { }
        }
    }
}
