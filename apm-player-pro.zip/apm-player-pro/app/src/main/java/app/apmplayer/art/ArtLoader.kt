package app.apmplayer.art

import kotlinx.coroutines.flow.MutableStateFlow
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.util.LruCache
import android.util.Size
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext

/** Finds the cover picture inside a song file and keeps recent ones in memory. */
class ArtLoader(private val context: Context) {

    private val cache = object : LruCache<String, Bitmap>(24 * 1024 * 1024) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount
    }
    private val noArt = HashSet<Long>()
    /** Goes up when a cover was changed, so lists and the player load it again. */
    val version = MutableStateFlow(0)
    private val gate = Semaphore(3) // a few pictures at a time, so a fast scroll does not freeze the phone

    /** A picture the user chose for this song, kept in the app's own folder. */
    private fun mine(trackId: Long, sizePx: Int): Bitmap? {
        val f = java.io.File(context.filesDir, "art/$trackId.jpg")
        if (!f.exists()) return null
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(f.path, bounds)
        var sample = 1
        while (bounds.outWidth / (sample * 2) >= sizePx && bounds.outHeight / (sample * 2) >= sizePx) sample *= 2
        return BitmapFactory.decodeFile(f.path, BitmapFactory.Options().apply { inSampleSize = sample })
    }

    /** Saves a picture as the cover of a song. */
    fun saveMine(trackId: Long, bitmap: Bitmap) {
        val dir = java.io.File(context.filesDir, "art").apply { mkdirs() }
        java.io.FileOutputStream(java.io.File(dir, "$trackId.jpg")).use { bitmap.compress(Bitmap.CompressFormat.JPEG, 90, it) }
        bump()
    }

    /** Takes a picture the user picked from the phone, makes it a sensible size and keeps it as this song's cover. */
    fun importPicture(trackId: Long, source: Uri): Boolean = try {
        val resolver = context.contentResolver
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        resolver.openInputStream(source)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        var sample = 1
        while (bounds.outWidth / (sample * 2) >= 1024 && bounds.outHeight / (sample * 2) >= 1024) sample *= 2
        val bitmap = resolver.openInputStream(source)?.use {
            BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = sample })
        }
        if (bitmap == null) false else { saveMine(trackId, bitmap); true }
    } catch (e: Exception) {
        false
    }

    fun removeMine(trackId: Long) {
        java.io.File(context.filesDir, "art/$trackId.jpg").delete()
        bump()
    }

    fun hasMine(trackId: Long): Boolean = java.io.File(context.filesDir, "art/$trackId.jpg").exists()

    private fun bump() {
        clearCache()
        version.value = version.value + 1
    }

    /** Forgets every picture held in memory, and the list of songs that had none. */
    fun clearCache() {
        cache.evictAll()
        synchronized(noArt) { noArt.clear() }
    }

    /** Returns the cover, or null when the song has none. [sizePx] is the wanted size of the longest side. */
    suspend fun load(trackId: Long, uri: String, sizePx: Int): Bitmap? {
        val key = "$trackId@$sizePx"
        mine(trackId, sizePx)?.let { return it }
        cache.get(key)?.let { return it }
        if (synchronized(noArt) { trackId in noArt }) return null
        return gate.withPermit {
            cache.get(key)?.let { return@withPermit it }
            val bitmap = withContext(Dispatchers.IO) { read(Uri.parse(uri), sizePx) }
            if (bitmap == null) synchronized(noArt) { noArt += trackId } else cache.put(key, bitmap)
            bitmap
        }
    }

    /** Reads the cover now, on the calling thread. Null when the song has none. */
    fun read(uri: Uri, sizePx: Int): Bitmap? {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            try {
                return context.contentResolver.loadThumbnail(uri, Size(sizePx, sizePx), null)
            } catch (e: Exception) {
                // no thumbnail from the system, try reading the picture inside the file
            }
        }
        val retriever = MediaMetadataRetriever()
        return try {
            retriever.setDataSource(context, uri)
            val bytes = retriever.embeddedPicture ?: return null
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
            var sample = 1
            while (bounds.outWidth / (sample * 2) >= sizePx && bounds.outHeight / (sample * 2) >= sizePx) sample *= 2
            BitmapFactory.decodeByteArray(bytes, 0, bytes.size, BitmapFactory.Options().apply { inSampleSize = sample })
        } catch (e: Exception) {
            null
        } finally {
            try { retriever.release() } catch (e: Exception) { }
        }
    }
}
