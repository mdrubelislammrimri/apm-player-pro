package app.apmplayer.data

import android.content.ContentUris
import android.content.Context
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import androidx.room.withTransaction
import app.apmplayer.settings.SettingsStore
import app.apmplayer.tags.TagEditsStore
import app.apmplayer.util.folderDisplayName
import app.apmplayer.util.normalizeFolderPath
import app.apmplayer.util.parentFolderPath
import app.apmplayer.util.relativeFolderFromFilePath
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** Reads the phone's audio files from MediaStore and keeps the local database in step with them. */
class LibraryScanner(
    private val context: Context,
    private val db: ApmDatabase,
    private val settings: SettingsStore,
    private val tagEdits: TagEditsStore,
) {

    private data class Row(
        val mediaStoreId: Long,
        val title: String,
        val artist: String?,
        val album: String?,
        val durationMs: Long,
        val trackRaw: Int,
        val year: Int,
        val dateAddedMs: Long,
        val mime: String?,
        val size: Long,
        val folderPath: String,
        val displayName: String?,
        val genre: String?,
        val composer: String?,
        val albumArtist: String?,
    )

    suspend fun scan() = withContext(Dispatchers.IO) {
        // names edited inside this app win over what the file says
        val edits = tagEdits.all()
        val useFileName = settings.state.value.filenameAsTitle
        val all = readMediaStore().map { raw ->
            // "Filename as title" shows the file's name (without the type) instead of the title tag
            val r = if (useFileName && !raw.displayName.isNullOrBlank()) raw.copy(title = raw.displayName.substringBeforeLast('.')) else raw
            val e = edits[r.mediaStoreId]
            if (e == null) r else r.copy(
                title = e.title?.ifBlank { null } ?: r.title,
                artist = if (e.artist != null) e.artist.ifBlank { null } else r.artist,
                album = if (e.album != null) e.album.ifBlank { null } else r.album,
            )
        }
        val s = settings.state.value
        // remember every folder the phone has music in, so the Music Folders page can list them
        settings.update { it.copy(knownFolders = all.map { r -> r.folderPath }.toSet()) }
        val minMs = s.minTrackSeconds * 1000L
        val rows = all.filter { r ->
            r.durationMs >= minMs &&
                !(s.ignoreVideo && r.mime?.startsWith("video/") == true) &&
                s.excludedFolders.none { ex -> r.folderPath == ex || r.folderPath.startsWith("$ex/") }
        }
        val generation = System.currentTimeMillis()
        db.withTransaction {
            val folders = HashMap<String, Long>()
            val artists = HashMap<String, Long>()
            val albums = HashMap<String, Long>()
            val trackDao = db.trackDao()
            for (r in rows) {
                val folderId = folderId(r.folderPath, folders, generation)
                val artistId = artistId(r.artist, artists, generation)
                val albumId = albumId(r.album, artistId, r.year, r.dateAddedMs, albums, generation)
                val existing = trackDao.findByMediaStoreId(r.mediaStoreId)
                val uri = ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, r.mediaStoreId)
                val track = TrackEntity(
                    id = existing?.id ?: 0,
                    mediaStoreId = r.mediaStoreId,
                    uri = uri.toString(),
                    title = r.title,
                    artistId = artistId,
                    albumId = albumId,
                    folderId = folderId,
                    durationMs = r.durationMs,
                    trackNo = (r.trackRaw % 1000).takeIf { it > 0 },
                    discNo = (r.trackRaw / 1000).takeIf { it > 0 },
                    year = r.year.takeIf { it > 0 },
                    genre = r.genre ?: existing?.genre,
                    composer = r.composer ?: existing?.composer,
                    albumArtist = r.albumArtist ?: existing?.albumArtist,
                    playCount = existing?.playCount ?: 0,
                    lastPlayedMs = existing?.lastPlayedMs ?: 0,
                    rating = existing?.rating ?: 0,
                    mimeType = r.mime,
                    sizeBytes = r.size,
                    bitrate = existing?.bitrate,
                    sampleRate = existing?.sampleRate,
                    bitDepth = existing?.bitDepth,
                    dateAddedMs = r.dateAddedMs,
                    isMissing = false,
                    scanGeneration = generation,
                    createdAt = existing?.createdAt ?: generation,
                    updatedAt = generation,
                )
                if (existing == null) trackDao.insert(track) else trackDao.update(track)
            }
            trackDao.markMissing(generation)
        }
    }

    private suspend fun folderId(path: String, cache: MutableMap<String, Long>, now: Long): Long {
        cache[path]?.let { return it }
        val dao = db.folderDao()
        dao.findByPath(path)?.let { cache[path] = it.id; return it.id }
        val parentId = parentFolderPath(path)?.let { folderId(it, cache, now) }
        val id = dao.insert(
            FolderEntity(
                path = path, name = folderDisplayName(path), parentId = parentId,
                artworkTrackId = null, createdAt = now, updatedAt = now,
            )
        )
        cache[path] = id
        return id
    }

    private suspend fun artistId(name: String?, cache: MutableMap<String, Long>, now: Long): Long? {
        if (name.isNullOrBlank() || name == UNKNOWN) return null
        val key = name.lowercase()
        cache[key]?.let { return it }
        val dao = db.artistDao()
        val id = dao.findByName(name)?.id
            ?: dao.insert(ArtistEntity(name = name, createdAt = now, updatedAt = now))
        cache[key] = id
        return id
    }

    private suspend fun albumId(
        title: String?, artistId: Long?, year: Int, dateAddedMs: Long,
        cache: MutableMap<String, Long>, now: Long,
    ): Long? {
        if (title.isNullOrBlank() || title == UNKNOWN) return null
        val key = title.lowercase() + "|" + artistId
        cache[key]?.let { return it }
        val dao = db.albumDao()
        val id = dao.find(title, artistId)?.id ?: dao.insert(
            AlbumEntity(
                title = title, artistId = artistId, year = year.takeIf { it > 0 },
                artworkUri = null, dateAddedMs = dateAddedMs, createdAt = now, updatedAt = now,
            )
        )
        cache[key] = id
        return id
    }

    private fun readMediaStore(): List<Row> {
        val uri = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        val modern = Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q
        val pathColumn = if (modern) MediaStore.Audio.Media.RELATIVE_PATH else MediaStore.Audio.Media.DATA
        val projection = arrayOf(
            MediaStore.Audio.Media._ID, MediaStore.Audio.Media.TITLE, MediaStore.Audio.Media.ARTIST,
            MediaStore.Audio.Media.ALBUM, MediaStore.Audio.Media.DURATION, MediaStore.Audio.Media.TRACK,
            MediaStore.Audio.Media.YEAR, MediaStore.Audio.Media.DATE_ADDED, MediaStore.Audio.Media.MIME_TYPE,
            MediaStore.Audio.Media.SIZE, MediaStore.Audio.Media.DISPLAY_NAME, pathColumn,
        ) + if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            // Genre, composer and album artist are only in MediaStore from Android 11.
            arrayOf(MediaStore.Audio.Media.GENRE, MediaStore.Audio.Media.COMPOSER, MediaStore.Audio.Media.ALBUM_ARTIST)
        } else {
            emptyArray<String>()
        }
        // Show every audio file except ringtones, alarms and notification sounds.
        // (Many songs from other apps are not flagged "music", so IS_MUSIC would hide them.)
        val selection = "${MediaStore.Audio.Media.IS_RINGTONE} = 0 AND ${MediaStore.Audio.Media.IS_ALARM} = 0 AND " +
            "${MediaStore.Audio.Media.IS_NOTIFICATION} = 0 AND ${MediaStore.Audio.Media.DURATION} > 0"
        @Suppress("DEPRECATION")
        val storageRoot = Environment.getExternalStorageDirectory().absolutePath
        val out = ArrayList<Row>()
        context.contentResolver.query(uri, projection, selection, null, null)?.use { c ->
            val iId = c.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
            val iTitle = c.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
            val iArtist = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
            val iAlbum = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM)
            val iDuration = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
            val iTrack = c.getColumnIndexOrThrow(MediaStore.Audio.Media.TRACK)
            val iYear = c.getColumnIndexOrThrow(MediaStore.Audio.Media.YEAR)
            val iAdded = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DATE_ADDED)
            val iMime = c.getColumnIndexOrThrow(MediaStore.Audio.Media.MIME_TYPE)
            val iSize = c.getColumnIndexOrThrow(MediaStore.Audio.Media.SIZE)
            val iPath = c.getColumnIndexOrThrow(pathColumn)
            val iName = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DISPLAY_NAME)
            val iGenre = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) c.getColumnIndexOrThrow(MediaStore.Audio.Media.GENRE) else -1
            val iComposer = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) c.getColumnIndexOrThrow(MediaStore.Audio.Media.COMPOSER) else -1
            val iAlbumArtist = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) c.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM_ARTIST) else -1
            while (c.moveToNext()) {
                val rawPath = c.getString(iPath)
                val folder = if (modern) rawPath else relativeFolderFromFilePath(rawPath.orEmpty(), storageRoot)
                out += Row(
                    mediaStoreId = c.getLong(iId),
                    title = c.getString(iTitle)?.ifBlank { null } ?: "Untitled",
                    artist = c.getString(iArtist),
                    album = c.getString(iAlbum),
                    durationMs = c.getLong(iDuration),
                    trackRaw = c.getInt(iTrack),
                    year = c.getInt(iYear),
                    dateAddedMs = c.getLong(iAdded) * 1000,
                    mime = c.getString(iMime),
                    size = c.getLong(iSize),
                    folderPath = normalizeFolderPath(folder),
                    displayName = c.getString(iName),
                    genre = if (iGenre >= 0) c.getString(iGenre)?.trim()?.ifEmpty { null } else null,
                    composer = if (iComposer >= 0) c.getString(iComposer)?.trim()?.ifEmpty { null } else null,
                    albumArtist = if (iAlbumArtist >= 0) c.getString(iAlbumArtist)?.trim()?.ifEmpty { null } else null,
                )
            }
        }
        return out
    }

    private companion object {
        const val UNKNOWN = "<unknown>"
    }
}
