package app.apmplayer.ui.screens

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.PlaylistPlay
import androidx.compose.material.icons.rounded.Bookmark
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.OutlinedTextField
import app.apmplayer.ui.components.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import app.apmplayer.AppContainer
import app.apmplayer.data.BookmarkWithTrack
import app.apmplayer.data.PlaylistRow
import app.apmplayer.data.TrackWithArtist
import app.apmplayer.ui.components.GeneratedArt
import app.apmplayer.ui.components.OutlinePill
import app.apmplayer.ui.components.focusRing
import app.apmplayer.ui.theme.Apm
import app.apmplayer.ui.theme.ApmShape
import app.apmplayer.ui.theme.ApmSpace
import app.apmplayer.util.formatDuration
import kotlinx.coroutines.launch

private val PlaylistColor = Color(0xFF9A5A52)
private val BookmarkColor = Color(0xFF4A6FC2)

/** All playlists. Tap to open, press and hold to rename or delete. */
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun PlaylistsScreen(container: AppContainer, onUp: () -> Unit, onOpen: (PlaylistRow) -> Unit) {
    val rows by remember { container.repository.playlists.observePlaylists() }.collectAsStateWithLifecycle(initialValue = null)
    val scope = rememberCoroutineScope()
    var showNew by remember { mutableStateOf(false) }
    var manage by remember { mutableStateOf<PlaylistRow?>(null) }
    var rename by remember { mutableStateOf<PlaylistRow?>(null) }
    var message by remember { mutableStateOf<String?>(null) }

    Column(Modifier.fillMaxSize()) {
        ListHeader("Playlists", Icons.AutoMirrored.Rounded.PlaylistPlay, PlaylistColor, onUp)
        Row(Modifier.padding(horizontal = ApmSpace.s3, vertical = ApmSpace.s2)) {
            OutlinePill("New playlist", { showNew = true })
        }
        message?.let { Text(it, style = Apm.type.bodySm, color = Apm.colors.danger, modifier = Modifier.padding(horizontal = ApmSpace.s4)) }
        val list = rows
        when {
            list == null -> SkeletonList()
            list.isEmpty() -> Text(
                "No playlists yet. Tap New playlist, or use the track menu on the player screen.",
                style = Apm.type.bodySm, color = Apm.colors.textMuted, modifier = Modifier.padding(ApmSpace.s5),
            )
            else -> LazyColumn(Modifier.fillMaxSize()) {
                items(list, key = { it.id }) { p ->
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .heightIn(min = 76.dp)
                            .focusRing(ApmShape.md)
                            .combinedClickable(role = Role.Button, onLongClick = { manage = p }, onClick = { onOpen(p) })
                            .padding(horizontal = ApmSpace.s4, vertical = ApmSpace.s1),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(ApmSpace.s4),
                    ) {
                        GeneratedArt(seed = p.id, modifier = Modifier.size(60.dp), shape = ApmShape.sm)
                        Column(Modifier.weight(1f)) {
                            Text(
                                p.name, style = Apm.type.body.copy(fontWeight = FontWeight.Bold), color = Apm.colors.text,
                                maxLines = 2, overflow = TextOverflow.Ellipsis,
                            )
                            Text(
                                if (p.trackCount == 1) "1 song" else "${p.trackCount} songs",
                                style = Apm.type.bodySm.copy(fontWeight = FontWeight.SemiBold), color = Color(0xFFB0B0B0),
                            )
                        }
                    }
                }
            }
        }
    }

    if (showNew) {
        NameDialog("New playlist", "", "Create", { showNew = false }) { name ->
            scope.launch {
                message = if (container.repository.createPlaylist(name) == null) "That name is empty or already used." else null
            }
            showNew = false
        }
    }
    manage?.let { p ->
        AlertDialog(
            onDismissRequest = { manage = null },
            title = { Text(p.name) },
            confirmButton = { TextButton(onClick = { rename = p; manage = null }) { Text("Rename") } },
            dismissButton = {
                TextButton(onClick = {
                    scope.launch { container.repository.playlists.delete(p.id) }
                    manage = null
                }) { Text("Delete") }
            },
        )
    }
    rename?.let { p ->
        NameDialog("Rename playlist", p.name, "Rename", { rename = null }) { name ->
            scope.launch {
                message = if (container.repository.renamePlaylist(p.id, name)) null else "That name is empty or already used."
            }
            rename = null
        }
    }
}

/** Saved places in songs. Tap to play from there, press and hold to delete. */
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun BookmarksScreen(container: AppContainer, onUp: () -> Unit, onOpenNowPlaying: () -> Unit) {
    val rows by remember { container.repository.bookmarks.observeAll() }.collectAsStateWithLifecycle(initialValue = null)
    val playing by container.player.state.collectAsStateWithLifecycle()
    val scope = rememberCoroutineScope()
    var delete by remember { mutableStateOf<BookmarkWithTrack?>(null) }

    Column(Modifier.fillMaxSize()) {
        ListHeader("Bookmarks", Icons.Rounded.Bookmark, BookmarkColor, onUp)
        val list = rows
        when {
            list == null -> SkeletonList()
            list.isEmpty() -> Text(
                "No bookmarks yet. Open the track menu on the player screen and tap Bookmark.",
                style = Apm.type.bodySm, color = Apm.colors.textMuted, modifier = Modifier.padding(ApmSpace.s5),
            )
            else -> LazyColumn(Modifier.fillMaxSize()) {
                items(list, key = { it.bookmarkId }) { b ->
                    SongRow(
                        TrackWithArtist(b.track, b.artistName),
                        highlighted = b.track.id.toString() == playing.mediaId,
                        onLongClick = { delete = b },
                        extraInfo = "Bookmark at " + formatDuration(b.positionMs),
                    ) {
                        container.play(listOf(TrackWithArtist(b.track, b.artistName)), 0, shuffle = false, startPositionMs = b.positionMs)
                        onOpenNowPlaying()
                    }
                }
            }
        }
    }

    delete?.let { b ->
        AlertDialog(
            onDismissRequest = { delete = null },
            title = { Text("Delete bookmark") },
            text = { Text(b.track.title + " at " + formatDuration(b.positionMs)) },
            confirmButton = {
                TextButton(onClick = {
                    scope.launch { container.repository.bookmarks.delete(b.bookmarkId) }
                    delete = null
                }) { Text("Delete") }
            },
            dismissButton = { TextButton(onClick = { delete = null }) { Text("Cancel") } },
        )
    }
}

/** Small dialog with one text box. */
@Composable
fun NameDialog(title: String, initial: String, confirmLabel: String, onDismiss: () -> Unit, onConfirm: (String) -> Unit) {
    var name by remember { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = { OutlinedTextField(value = name, onValueChange = { name = it }, singleLine = true, label = { Text("Name") }) },
        confirmButton = { TextButton(onClick = { onConfirm(name) }, enabled = name.isNotBlank()) { Text(confirmLabel) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
}

/** Pick a playlist to add a song to, or make a new one. */
@Composable
fun PlaylistPickerDialog(
    playlists: List<PlaylistRow>,
    onPick: (PlaylistRow) -> Unit,
    onCreate: (String) -> Unit,
    onDismiss: () -> Unit,
) {
    var newName by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Add to playlist") },
        text = {
            Column {
                OutlinedTextField(
                    value = newName, onValueChange = { newName = it }, singleLine = true,
                    label = { Text("New playlist name") },
                )
                TextButton(onClick = { onCreate(newName) }, enabled = newName.isNotBlank()) { Text("Create and add") }
                LazyColumn(Modifier.heightIn(max = 240.dp)) {
                    items(playlists, key = { it.id }) { p ->
                        Box(
                            Modifier.fillMaxWidth().heightIn(min = 48.dp).focusRing(ApmShape.sm)
                                .combinedClickableNoLong { onPick(p) },
                            contentAlignment = Alignment.CenterStart,
                        ) { Text(p.name, style = Apm.type.body, color = Apm.colors.text) }
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Close") } },
    )
}

private fun Modifier.combinedClickableNoLong(onClick: () -> Unit): Modifier =
    this.then(Modifier.clickable(role = Role.Button, onClick = onClick))
