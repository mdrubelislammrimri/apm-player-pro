package app.apmplayer.util

data class LyricLine(val timeMs: Long, val text: String)

/** [synced] is true when the lines carry times (an .lrc file), then [lines] are in time order. */
data class ParsedLyrics(val lines: List<LyricLine>, val synced: Boolean)

private val TIMED_LINE = Regex("""^\s*((?:\[\d{1,3}:\d{2}(?:[.:]\d{1,3})?])+)(.*)$""")
private val ONE_TAG = Regex("""\[(\d{1,3}):(\d{2})(?:[.:](\d{1,3}))?]""")

private fun tagToMs(minutes: String, seconds: String, fraction: String): Long {
    val frac = when (fraction.length) {
        0 -> 0L
        1 -> fraction.toLong() * 100
        2 -> fraction.toLong() * 10
        else -> fraction.take(3).toLong()
    }
    return minutes.toLong() * 60_000L + seconds.toLong() * 1000L + frac
}

/**
 * Reads lyrics text. A line like "[01:23.45]words" has a time, and a line can carry several times.
 * Lines like "[ar:Artist]" are tags of the file and are skipped. Without times the text is shown as it is.
 */
fun parseLyrics(raw: String): ParsedLyrics {
    val timed = ArrayList<LyricLine>()
    val plain = ArrayList<LyricLine>()
    for (line in raw.replace("\r\n", "\n").replace('\r', '\n').split('\n')) {
        val match = TIMED_LINE.matchEntire(line)
        if (match != null) {
            val text = match.groupValues[2].trim()
            for (tag in ONE_TAG.findAll(match.groupValues[1])) {
                val (m, s, f) = tag.destructured
                timed += LyricLine(tagToMs(m, s, f), text)
            }
        } else if (!Regex("""^\s*\[[A-Za-z]+:.*]\s*$""").matches(line)) {
            plain += LyricLine(-1L, line.trim())
        }
    }
    return if (timed.size >= 2) {
        ParsedLyrics(timed.sortedBy { it.timeMs }, synced = true)
    } else {
        // trim blank lines at the start and the end, keep the ones in between as gaps between verses
        val lines = plain.dropWhile { it.text.isEmpty() }.dropLastWhile { it.text.isEmpty() }
        ParsedLyrics(lines, synced = false)
    }
}

/** Index of the line being sung at [positionMs], or -1 before the first line. */
fun currentLyricIndex(lines: List<LyricLine>, positionMs: Long): Int = lines.indexOfLast { it.timeMs in 0..positionMs }
