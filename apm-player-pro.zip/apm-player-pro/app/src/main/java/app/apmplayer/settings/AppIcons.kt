package app.apmplayer.settings

import android.content.ComponentName
import android.content.Context
import android.content.pm.PackageManager
import app.apmplayer.R

/** One launcher icon the user can pick. [alias] is the name of its launcher entry in the manifest. */
data class AppIcon(val alias: String, val name: String, val kind: String, val res: Int)

val AppIcons = listOf(
    AppIcon("Icon01", "Default", "Adaptive icon", R.mipmap.ic_launcher),
    AppIcon("Icon02", "Default", "Material You colors", R.mipmap.ic_choice_02),
    AppIcon("Icon03", "Black", "Round icon", R.mipmap.ic_choice_03),
    AppIcon("Icon04", "Black Play", "Adaptive icon", R.mipmap.ic_choice_04),
    AppIcon("Icon05", "Classic", "Round icon", R.mipmap.ic_choice_05),
    AppIcon("Icon06", "Wave", "Adaptive icon", R.mipmap.ic_choice_06),
    AppIcon("Icon07", "Round", "Round icon", R.mipmap.ic_choice_07),
    AppIcon("Icon08", "Rounded Corners", "Material You colors", R.mipmap.ic_choice_08),
    AppIcon("Icon09", "Rounded Corners", "Material You colors (dark)", R.mipmap.ic_choice_09),
    AppIcon("Icon10", "White", "Round icon", R.mipmap.ic_choice_10),
    AppIcon("Icon11", "White Play", "Material You colors", R.mipmap.ic_choice_11),
    AppIcon("Icon12", "White Play", "Material You colors (dark)", R.mipmap.ic_choice_12),
    AppIcon("Icon13", "White Play", "Adaptive icon", R.mipmap.ic_choice_13),
    AppIcon("Icon14", "Wave", "Round icon", R.mipmap.ic_choice_14),
)

private fun component(context: Context, icon: AppIcon) = ComponentName(context.packageName, "app.apmplayer." + icon.alias)

/** The number of the icon that is switched on now. */
fun currentAppIcon(context: Context): Int {
    val pm = context.packageManager
    AppIcons.forEachIndexed { i, icon ->
        val state = pm.getComponentEnabledSetting(component(context, icon))
        if (state == PackageManager.COMPONENT_ENABLED_STATE_ENABLED) return i
        if (state == PackageManager.COMPONENT_ENABLED_STATE_DEFAULT && i == 0) return 0
    }
    return 0
}

/** Switches to the icon at [index]: the new launcher entry on first, so the app never has none, then the others off. */
fun setAppIcon(context: Context, index: Int) {
    val pm = context.packageManager
    pm.setComponentEnabledSetting(component(context, AppIcons[index]), PackageManager.COMPONENT_ENABLED_STATE_ENABLED, PackageManager.DONT_KILL_APP)
    AppIcons.forEachIndexed { i, icon ->
        if (i != index) {
            pm.setComponentEnabledSetting(component(context, icon), PackageManager.COMPONENT_ENABLED_STATE_DISABLED, PackageManager.DONT_KILL_APP)
        }
    }
}
