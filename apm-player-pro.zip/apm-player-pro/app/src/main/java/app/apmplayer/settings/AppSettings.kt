package app.apmplayer.settings

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/** Every choice on the settings pages. The names double as the keys saved on the phone. */
data class Settings(
    // Look and Feel
    val orientation: Int = 0, // 0 default, 1 portrait, 2 landscape
    val hideStatusBar: Boolean = false,
    val keepScreenOn: Boolean = false,
    val ratingType: Int = 1, // 0 off, 1 like and unlike thumbs, 2 five stars, 3 five stars in the menu and lists only
    val menuShortcuts: Int = 5,
    val seekStyle: Int = 0, // 0 waveform under the buttons, 1 static waveform strip, 2 plain slider
    // Audio
    val fadeMs: Int = 0,
    // Visualization
    val vizOpacityPct: Int = 0,
    val vizTimeoutMs: Int = 3500,
    val vizAutoSeconds: Int = 0,
    // Background
    val bgOn: Boolean = true,
    val bgIntensityPct: Int = 70,
    val bgSaturationPct: Int = 100,
    val bgDetails: Int = 16,
    val bgGradientPct: Int = 100,
    // Album art
    val forceDefaultArt: Boolean = false,
    val squareCover: Boolean = false,
    // Library
    val minTrackSeconds: Int = 6,
    val ignoreVideo: Boolean = true,
    val rememberProgress: Boolean = true,
    val rememberMinMinutes: Int = 45,
    val countPlayedPct: Int = 50,
    val excludedFolders: Set<String> = emptySet(),
    val knownFolders: Set<String> = emptySet(), // filled by the scan, not a choice
    // Headset and lock screen
    val pauseOnUnplug: Boolean = true,
    val showOnLock: Boolean = false,
    // first run tips on the player screen
    val tipsShown: Boolean = false,
    // colour skin, an index into ApmSkins
    val skin: Int = 0,
    // Look and Feel, part 1 of the settings pages
    val fontBoost: Int = 0, // 0 default, 1 bold, 2 bold plus
    val animations: Int = 2, // 0 off, 1 fast, 2 default
    val startAtLibrary: Boolean = true,
    val timePills: Boolean = true,
    val showInfoLine: Boolean = true,
    val coverSwipe: Boolean = true,
    val lyricsSize: Int = 1, // 0 small, 1 normal, 2 large, 3 extra large
    val lyricsAutoScroll: Boolean = true,
    val lyricsKeepOn: Boolean = false,
    val lyricsSwipe: Boolean = true,
    val stopOnSwipe: Boolean = false,
    val filenameAsTitle: Boolean = false,
    val showTrackNumber: Boolean = false,
    val showFormat: Boolean = true,
    val listCovers: Boolean = true,
    // Skin page
    val themeMode: Int = 0, // 0 default (dark), 1 light, 2 dark, 3 follow the phone
    val fontFamily: Int = 0, // 0 default, 1 alternative font
    val layout: Int = 2, // 0 default, 1 alternative, 2 full cover
    val labelsCentered: Boolean = false,
    val labelsBg: Boolean = true,
    val buttonsBg: Boolean = true,
    val materialYou: Int = 0, // 0 off, 1 more pronounced, 2 less pronounced
    val lessRounded: Boolean = false,
    val proButtons: Boolean = true,
    val knobHighlight: Int = 2, // 0 none, 1 monochromatic, 2 colorful
    val eqColorful: Boolean = true,
    val statusScrim: Boolean = true,
    val navbarPlayer: Int = 0, // 0 default, 1 semi-transparent, 2 no background
    val navbarOther: Int = 0, // 0 default, 1 no background
    val offsetNavbar: Boolean = false,
    val customSkins: String = "[]", // skins imported by the user, as JSON
    // Player Screen page
    val albumArtAnim: Boolean = true,
    val animateLabels: Boolean = true,
    val animateLabelsEverywhere: Boolean = false,
    val playerButtons: String = "viz,sleep,repeat,shuffle", // the buttons under the cover, in order
    val preferNoGap: Boolean = false,
    val noEditOnLongPress: Boolean = false,
    val coverMenu: Boolean = true, // press and hold the cover to open the track menu
    val menuLongPress: Int = 0, // press and hold the menu button: index into the action list, 0 is off
    val lyricsButton: Int = 1, // 0 off, 1 when lyrics are saved for the song, 2 always
    val line2Press: Int = 0, // press the artist line: 0 off, 1 artist, 2 album, 3 folder, 4 genre
    val line2LongPress: Int = 1,
    val prevResets: Boolean = false, // the previous button first goes back to the start of the song
    val rewindProLong: Boolean = true, // the small side buttons go 10 seconds for long songs
    val folderNavFlat: Boolean = false, // the track menu Folder goes to the Folders list, not the folder tree
)

/** Holds the settings, saves each change, and tells the screens. */
class SettingsStore(context: Context) {

    private val prefs = context.getSharedPreferences("settings", Context.MODE_PRIVATE)
    private val _state = MutableStateFlow(load())
    val state: StateFlow<Settings> = _state.asStateFlow()

    fun update(change: (Settings) -> Settings) {
        val next = change(_state.value)
        _state.value = next
        save(next)
    }

    /** Reads everything again, used after a backup was loaded. */
    fun reload() {
        _state.value = load()
    }

    /** Back to the starting values. The list of folders the scan found is kept. */
    fun resetAll() = update { Settings(knownFolders = it.knownFolders, tipsShown = it.tipsShown) }

    private fun save(s: Settings) {
        prefs.edit()
            .putInt("orientation", s.orientation)
            .putBoolean("hideStatusBar", s.hideStatusBar)
            .putBoolean("keepScreenOn", s.keepScreenOn)
            .putInt("ratingType", s.ratingType)
            .putInt("menuShortcuts", s.menuShortcuts)
            .putInt("seekStyle", s.seekStyle)
            .putInt("fadeMs", s.fadeMs)
            .putInt("vizOpacityPct", s.vizOpacityPct)
            .putInt("vizTimeoutMs", s.vizTimeoutMs)
            .putInt("vizAutoSeconds", s.vizAutoSeconds)
            .putBoolean("bgOn", s.bgOn)
            .putInt("bgIntensityPct", s.bgIntensityPct)
            .putInt("bgSaturationPct", s.bgSaturationPct)
            .putInt("bgDetails", s.bgDetails)
            .putInt("bgGradientPct", s.bgGradientPct)
            .putBoolean("forceDefaultArt", s.forceDefaultArt)
            .putBoolean("squareCover", s.squareCover)
            .putInt("minTrackSeconds", s.minTrackSeconds)
            .putBoolean("ignoreVideo", s.ignoreVideo)
            .putBoolean("rememberProgress", s.rememberProgress)
            .putInt("rememberMinMinutes", s.rememberMinMinutes)
            .putInt("countPlayedPct", s.countPlayedPct)
            .putStringSet("excludedFolders", HashSet(s.excludedFolders))
            .putStringSet("knownFolders", HashSet(s.knownFolders))
            .putBoolean("pauseOnUnplug", s.pauseOnUnplug)
            .putBoolean("showOnLock", s.showOnLock)
            .putBoolean("tipsShown", s.tipsShown)
            .putInt("skin", s.skin)
            .putInt("fontBoost", s.fontBoost)
            .putInt("animations", s.animations)
            .putBoolean("startAtLibrary", s.startAtLibrary)
            .putBoolean("timePills", s.timePills)
            .putBoolean("showInfoLine", s.showInfoLine)
            .putBoolean("coverSwipe", s.coverSwipe)
            .putInt("lyricsSize", s.lyricsSize)
            .putBoolean("lyricsAutoScroll", s.lyricsAutoScroll)
            .putBoolean("lyricsKeepOn", s.lyricsKeepOn)
            .putBoolean("lyricsSwipe", s.lyricsSwipe)
            .putBoolean("stopOnSwipe", s.stopOnSwipe)
            .putBoolean("filenameAsTitle", s.filenameAsTitle)
            .putBoolean("showTrackNumber", s.showTrackNumber)
            .putBoolean("showFormat", s.showFormat)
            .putBoolean("listCovers", s.listCovers)
            .putInt("themeMode", s.themeMode)
            .putInt("fontFamily", s.fontFamily)
            .putInt("layout", s.layout)
            .putBoolean("labelsCentered", s.labelsCentered)
            .putBoolean("labelsBg", s.labelsBg)
            .putBoolean("buttonsBg", s.buttonsBg)
            .putInt("materialYou", s.materialYou)
            .putBoolean("lessRounded", s.lessRounded)
            .putBoolean("proButtons", s.proButtons)
            .putInt("knobHighlight", s.knobHighlight)
            .putBoolean("eqColorful", s.eqColorful)
            .putBoolean("statusScrim", s.statusScrim)
            .putInt("navbarPlayer", s.navbarPlayer)
            .putInt("navbarOther", s.navbarOther)
            .putBoolean("offsetNavbar", s.offsetNavbar)
            .putString("customSkins", s.customSkins)
            .putBoolean("albumArtAnim", s.albumArtAnim)
            .putBoolean("animateLabels", s.animateLabels)
            .putBoolean("animateLabelsEverywhere", s.animateLabelsEverywhere)
            .putString("playerButtons", s.playerButtons)
            .putBoolean("preferNoGap", s.preferNoGap)
            .putBoolean("noEditOnLongPress", s.noEditOnLongPress)
            .putBoolean("coverMenu", s.coverMenu)
            .putInt("menuLongPress", s.menuLongPress)
            .putInt("lyricsButton", s.lyricsButton)
            .putInt("line2Press", s.line2Press)
            .putInt("line2LongPress", s.line2LongPress)
            .putBoolean("prevResets", s.prevResets)
            .putBoolean("rewindProLong", s.rewindProLong)
            .putBoolean("folderNavFlat", s.folderNavFlat)
            .apply()
    }

    private fun load(): Settings {
        val d = Settings()
        return Settings(
            orientation = prefs.getInt("orientation", d.orientation),
            hideStatusBar = prefs.getBoolean("hideStatusBar", d.hideStatusBar),
            keepScreenOn = prefs.getBoolean("keepScreenOn", d.keepScreenOn),
            ratingType = if (prefs.contains("ratingType")) prefs.getInt("ratingType", d.ratingType) else if (prefs.getBoolean("showRating", true)) 1 else 0,
            menuShortcuts = prefs.getInt("menuShortcuts", d.menuShortcuts),
            // older versions saved the seek bar as an on/off switch
            seekStyle = if (prefs.contains("seekStyle")) prefs.getInt("seekStyle", d.seekStyle) else if (prefs.getBoolean("waveformSeek", true)) 0 else 2,
            fadeMs = prefs.getInt("fadeMs", d.fadeMs),
            vizOpacityPct = prefs.getInt("vizOpacityPct", d.vizOpacityPct),
            vizTimeoutMs = prefs.getInt("vizTimeoutMs", d.vizTimeoutMs),
            vizAutoSeconds = prefs.getInt("vizAutoSeconds", d.vizAutoSeconds),
            bgOn = prefs.getBoolean("bgOn", d.bgOn),
            bgIntensityPct = prefs.getInt("bgIntensityPct", d.bgIntensityPct),
            bgSaturationPct = prefs.getInt("bgSaturationPct", d.bgSaturationPct),
            bgDetails = prefs.getInt("bgDetails", d.bgDetails),
            bgGradientPct = prefs.getInt("bgGradientPct", d.bgGradientPct),
            forceDefaultArt = prefs.getBoolean("forceDefaultArt", d.forceDefaultArt),
            squareCover = prefs.getBoolean("squareCover", d.squareCover),
            minTrackSeconds = prefs.getInt("minTrackSeconds", d.minTrackSeconds),
            ignoreVideo = prefs.getBoolean("ignoreVideo", d.ignoreVideo),
            rememberProgress = prefs.getBoolean("rememberProgress", d.rememberProgress),
            rememberMinMinutes = prefs.getInt("rememberMinMinutes", d.rememberMinMinutes),
            countPlayedPct = prefs.getInt("countPlayedPct", d.countPlayedPct),
            excludedFolders = prefs.getStringSet("excludedFolders", null)?.toSet() ?: emptySet(),
            knownFolders = prefs.getStringSet("knownFolders", null)?.toSet() ?: emptySet(),
            pauseOnUnplug = prefs.getBoolean("pauseOnUnplug", d.pauseOnUnplug),
            showOnLock = prefs.getBoolean("showOnLock", d.showOnLock),
            tipsShown = prefs.getBoolean("tipsShown", d.tipsShown),
            skin = prefs.getInt("skin", d.skin),
            fontBoost = prefs.getInt("fontBoost", d.fontBoost),
            animations = prefs.getInt("animations", d.animations),
            startAtLibrary = prefs.getBoolean("startAtLibrary", d.startAtLibrary),
            timePills = prefs.getBoolean("timePills", d.timePills),
            showInfoLine = prefs.getBoolean("showInfoLine", d.showInfoLine),
            coverSwipe = prefs.getBoolean("coverSwipe", d.coverSwipe),
            lyricsSize = prefs.getInt("lyricsSize", d.lyricsSize),
            lyricsAutoScroll = prefs.getBoolean("lyricsAutoScroll", d.lyricsAutoScroll),
            lyricsKeepOn = prefs.getBoolean("lyricsKeepOn", d.lyricsKeepOn),
            lyricsSwipe = prefs.getBoolean("lyricsSwipe", d.lyricsSwipe),
            stopOnSwipe = prefs.getBoolean("stopOnSwipe", d.stopOnSwipe),
            filenameAsTitle = prefs.getBoolean("filenameAsTitle", d.filenameAsTitle),
            showTrackNumber = prefs.getBoolean("showTrackNumber", d.showTrackNumber),
            showFormat = prefs.getBoolean("showFormat", d.showFormat),
            listCovers = prefs.getBoolean("listCovers", d.listCovers),
            themeMode = prefs.getInt("themeMode", d.themeMode),
            fontFamily = prefs.getInt("fontFamily", d.fontFamily),
            layout = prefs.getInt("layout", d.layout),
            labelsCentered = prefs.getBoolean("labelsCentered", d.labelsCentered),
            labelsBg = prefs.getBoolean("labelsBg", d.labelsBg),
            buttonsBg = prefs.getBoolean("buttonsBg", d.buttonsBg),
            materialYou = prefs.getInt("materialYou", d.materialYou),
            lessRounded = prefs.getBoolean("lessRounded", d.lessRounded),
            proButtons = prefs.getBoolean("proButtons", d.proButtons),
            knobHighlight = prefs.getInt("knobHighlight", d.knobHighlight),
            eqColorful = prefs.getBoolean("eqColorful", d.eqColorful),
            statusScrim = prefs.getBoolean("statusScrim", d.statusScrim),
            navbarPlayer = prefs.getInt("navbarPlayer", d.navbarPlayer),
            navbarOther = prefs.getInt("navbarOther", d.navbarOther),
            offsetNavbar = prefs.getBoolean("offsetNavbar", d.offsetNavbar),
            customSkins = prefs.getString("customSkins", d.customSkins) ?: d.customSkins,
            albumArtAnim = prefs.getBoolean("albumArtAnim", d.albumArtAnim),
            animateLabels = prefs.getBoolean("animateLabels", d.animateLabels),
            animateLabelsEverywhere = prefs.getBoolean("animateLabelsEverywhere", d.animateLabelsEverywhere),
            playerButtons = prefs.getString("playerButtons", d.playerButtons) ?: d.playerButtons,
            preferNoGap = prefs.getBoolean("preferNoGap", d.preferNoGap),
            noEditOnLongPress = prefs.getBoolean("noEditOnLongPress", d.noEditOnLongPress),
            coverMenu = prefs.getBoolean("coverMenu", d.coverMenu),
            menuLongPress = prefs.getInt("menuLongPress", d.menuLongPress),
            lyricsButton = prefs.getInt("lyricsButton", d.lyricsButton),
            line2Press = prefs.getInt("line2Press", d.line2Press),
            line2LongPress = prefs.getInt("line2LongPress", d.line2LongPress),
            prevResets = prefs.getBoolean("prevResets", d.prevResets),
            rewindProLong = prefs.getBoolean("rewindProLong", d.rewindProLong),
            folderNavFlat = prefs.getBoolean("folderNavFlat", d.folderNavFlat),
        )
    }
}
