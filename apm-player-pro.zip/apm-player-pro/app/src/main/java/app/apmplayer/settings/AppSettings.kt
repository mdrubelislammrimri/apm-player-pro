package app.apmplayer.settings

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/** Every choice on the settings pages. The names double as the keys saved on the phone. */
data class Settings(
    // Look and Feel
    val orientation: Int = 0, // 0 default, 1 portrait, 2 landscape
    val hideStatusBar: Boolean = false,
    val keepScreenOn: Boolean = false,
    val ratingType: Int = 1, // 0 off, 1 like and unlike thumbs, 2 five stars, 3 five stars in the menu and lists only
    val menuShortcuts: Int = 5,
    val seekStyle: Int = 0, // 0 waveform under the buttons, 1 static waveform strip, 2 plain slider
    // Audio
    // Visualization
    val vizOpacityPct: Int = 0,
    val vizTimeoutMs: Int = 3500,
    val vizAutoSeconds: Int = 0,
    // Background
    val bgOn: Boolean = true,
    val bgIntensityPct: Int = 70,
    val bgSaturationPct: Int = 100,
    val bgDetails: Int = 16,
    val bgGradientPct: Int = 100,
    // Album art
    val forceDefaultArt: Boolean = false,
    val squareCover: Boolean = false,
    // Library
    val minTrackSeconds: Int = 6,
    val ignoreVideo: Boolean = true,
    val rememberProgress: Boolean = true,
    val rememberMinMinutes: Int = 45,
    val countPlayedPct: Int = 50,
    val excludedFolders: Set<String> = emptySet(),
    val knownFolders: Set<String> = emptySet(), // filled by the scan, not a choice
    // Headset and lock screen
    val pauseOnUnplug: Boolean = true,
    val showOnLock: Boolean = false,
    // first run tips on the player screen
    val tipsShown: Boolean = false,
    // colour skin, an index into ApmSkins
    val skin: Int = 0,
    // Look and Feel, part 1 of the settings pages
    val fontBoost: Int = 0, // 0 default, 1 bold, 2 bold plus
    val animations: Int = 2, // 0 off, 1 fast, 2 default
    val startAtPlayer: Boolean = true, // the app opens on the player screen
    val timePills: Boolean = true,
    val showInfoLine: Boolean = true,
    val coverSwipe: Boolean = true,
    val lyricsZoom: Float = 1f, // text size of the lyrics, changed by pinching or the size choice
    val lyricsAutoScroll: Boolean = true,
    val lyricsKeepOn: Boolean = false,
    val lyricsSwipe: Int = 2, // swipe the cover up: 0 off, 1 when lyrics are saved, 2 always
    val stopOnSwipe: Boolean = false,
    val filenameAsTitle: Boolean = false,
    val showTrackNumber: Boolean = false,
    val showFormat: Boolean = true,
    val listCovers: Boolean = true,
    // Skin page
    val themeMode: Int = 0, // 0 default (dark), 1 light, 2 dark, 3 follow the phone
    val fontFamily: Int = 0, // 0 default, 1 alternative font
    val layout: Int = 2, // 0 default, 1 alternative, 2 full cover
    val labelsCentered: Boolean = false,
    val labelsBg: Boolean = true,
    val buttonsBg: Boolean = true,
    val materialYou: Int = 0, // 0 off, 1 more pronounced, 2 less pronounced
    val lessRounded: Boolean = false,
    val proButtons: Boolean = true,
    val knobHighlight: Int = 2, // 0 none, 1 monochromatic, 2 colorful
    val eqColorful: Boolean = true,
    val statusScrim: Boolean = true,
    val navbarPlayer: Int = 0, // 0 default, 1 semi-transparent, 2 no background
    val navbarOther: Int = 0, // 0 default, 1 no background
    val offsetNavbar: Boolean = false,
    val customSkins: String = "[]", // skins imported by the user, as JSON
    // Player Screen page
    val albumArtAnim: Boolean = true,
    val animateLabels: Boolean = true,
    val animateLabelsEverywhere: Boolean = false,
    val playerButtons: String = "viz,sleep,repeat,shuffle", // the buttons under the cover, in order
    val preferNoGap: Boolean = false,
    val noEditOnLongPress: Boolean = false,
    val coverMenu: Boolean = true, // press and hold the cover to open the track menu
    val menuLongPress: Int = 0, // press and hold the menu button: index into the action list, 0 is off
    val lyricsButton: Int = 1, // 0 off, 1 when lyrics are saved for the song, 2 always
    val line2Press: Int = 0, // press the artist line: 0 off, 1 artist, 2 album, 3 folder, 4 genre
    val line2LongPress: Int = 1,
    val prevResets: Boolean = false, // the previous button first goes back to the start of the song
    val rewindProLong: Boolean = true, // the small side buttons go 10 seconds for long songs
    val folderNavFlat: Boolean = false, // the track menu Folder goes to the Folders list, not the folder tree
    // Lyrics page
    val lyricsOffsetMs: Int = 0,
    val lyricsMenuAction: Int = 0, // the Lyrics item of the track menu: 0 open the lyrics, 1 search in a browser or app
    val lyricsUrl: String = "https://www.google.com/search?q=lyrics %ARTIST% %TITLE%",
    val lyricsApp: String = "", // package name of the app for lyrics searches, empty is the browser
    val scanLrc: Boolean = true,
    val lrcFolderUri: String = "",
    val lyricsUtf8: Boolean = true,
    val lyricsCharset: Int = 0,
    val lyricsAuto: Boolean = false, // look up lyrics online when a song has none
    val lyricsWifiOnly: Boolean = true,
    // Notifications page
    val notifType: Int = 0, // 0 auto, 1 media / colorized, 2 media with the custom cover, 3 legacy (plain)
    val notifColors: Int = 0, // 0 auto, 1 black text, 2 white text
    val colorizeNotification: Boolean = true,
    val notifButtons: String = "prev,playpause,next",
    val notifOpenList: Boolean = false, // touching the notification goes to the list the songs came from
    val keepNotification: Boolean = true,
    val keepInactiveNotification: Boolean = false,
    val keepService: Boolean = false,
    val removeOnDisconnect: Boolean = false,
    // Audio page
    // Crossfade, Fade, and Gapless page
    val autoFading: Int = 0, // when a song ends by itself: 0 no fading, 1 non-gapless songs, 2 all songs, 3 shuffled songs
    val manualFading: Int = 1, // when the song is changed by hand: 0 no fading, 1 short crossfade, 2 crossfade
    val fadePlayPause: Boolean = true,
    val fadeOnSeek: Boolean = true,
    val preloadMs: Int = 0,
    val silenceMs: Int = 0,
    val crossfadeMs: Int = 5000,
    val shortCrossfadeMs: Int = 400,
    val playPauseFadeMs: Int = 400,
    val seekFadeMs: Int = 100,
    val rgApply: Int = 0, // 0 don't apply, 1 apply the gain, 2 apply the gain and keep the loudest point below full scale
    val rgSource: Int = 0, // 0 album, 1 track
    val rgPreampWith: Float = 0f,
    val rgPreampWithout: Float = 0f,
    // Audio Focus page
    val resumeAfterCall: Boolean = true,
    val resumeOnStart: Boolean = false,
    val resumeOnReopen: Boolean = false,
    val waitForStorage: Boolean = false,
    val focusShort: Boolean = true, // pause on a short change of audio focus (calls, notifications, navigation)
    val pauseInCall: Boolean = true,
    val resumeOnGain: Boolean = true,
    val duckVolume: Boolean = true, // lower the volume instead of pausing, when possible
    val focusPermanent: Boolean = true, // pause when another player takes the focus for good
    // Direct Volume Control page
    val dvc: Boolean = false, // the volume knob moves the phone's own music volume
    val noDvcBtAbs: Boolean = true, // no DVC for Bluetooth, which usually has absolute volume
    val noDvcWired: Boolean = false,
    val noDvcSpeaker: Boolean = false,
    val noDvcBt: Boolean = false,
    val noDvcUsb: Boolean = false,
    val noDvcOther: Boolean = false,
    val preampReductionDb: Float = 0f, // lowers the sound when DVC is off, to leave room for the equalizer
    val outputType: Int = -1, // preferred output: -1 automatic, else an AudioDeviceInfo type
    val outputName: String = "",
    val bitPerfect: Boolean = false,
    val ditherType: Int = 0, // 0 none, 1 rectangular, 2 triangular, 3 triangular with high pass, 4 F-weighted, 5 modified-e-weighted, 6 improved-e-weighted, 7 Shibata
)

/** Holds the settings, saves each change, and tells the screens. */
class SettingsStore(context: Context) {

    private val prefs = context.getSharedPreferences("settings", Context.MODE_PRIVATE)
    private val _state = MutableStateFlow(load())
    val state: StateFlow<Settings> = _state.asStateFlow()

    fun update(change: (Settings) -> Settings) {
        val next = change(_state.value)
        _state.value = next
        save(next)
    }

    /** Reads everything again, used after a backup was loaded. */
    fun reload() {
        _state.value = load()
    }

    /** Back to the starting values. The list of folders the scan found is kept. */
    fun resetAll() = update { Settings(knownFolders = it.knownFolders, tipsShown = it.tipsShown) }

    private fun save(s: Settings) {
        prefs.edit()
            .putInt("orientation", s.orientation)
            .putBoolean("hideStatusBar", s.hideStatusBar)
            .putBoolean("keepScreenOn", s.keepScreenOn)
            .putInt("ratingType", s.ratingType)
            .putInt("menuShortcuts", s.menuShortcuts)
            .putInt("seekStyle", s.seekStyle)
            .putInt("vizOpacityPct", s.vizOpacityPct)
            .putInt("vizTimeoutMs", s.vizTimeoutMs)
            .putInt("vizAutoSeconds", s.vizAutoSeconds)
            .putBoolean("bgOn", s.bgOn)
            .putInt("bgIntensityPct", s.bgIntensityPct)
            .putInt("bgSaturationPct", s.bgSaturationPct)
            .putInt("bgDetails", s.bgDetails)
            .putInt("bgGradientPct", s.bgGradientPct)
            .putBoolean("forceDefaultArt", s.forceDefaultArt)
            .putBoolean("squareCover", s.squareCover)
            .putInt("minTrackSeconds", s.minTrackSeconds)
            .putBoolean("ignoreVideo", s.ignoreVideo)
            .putBoolean("rememberProgress", s.rememberProgress)
            .putInt("rememberMinMinutes", s.rememberMinMinutes)
            .putInt("countPlayedPct", s.countPlayedPct)
            .putStringSet("excludedFolders", HashSet(s.excludedFolders))
            .putStringSet("knownFolders", HashSet(s.knownFolders))
            .putBoolean("pauseOnUnplug", s.pauseOnUnplug)
            .putBoolean("showOnLock", s.showOnLock)
            .putBoolean("tipsShown", s.tipsShown)
            .putInt("skin", s.skin)
            .putInt("fontBoost", s.fontBoost)
            .putInt("animations", s.animations)
            .putBoolean("startAtPlayer", s.startAtPlayer)
            .putBoolean("timePills", s.timePills)
            .putBoolean("showInfoLine", s.showInfoLine)
            .putBoolean("coverSwipe", s.coverSwipe)
            .putFloat("lyricsZoom", s.lyricsZoom)
            .putBoolean("lyricsAutoScroll", s.lyricsAutoScroll)
            .putBoolean("lyricsKeepOn", s.lyricsKeepOn)
            .putInt("lyricsSwipeMode", s.lyricsSwipe)
            .putBoolean("stopOnSwipe", s.stopOnSwipe)
            .putBoolean("filenameAsTitle", s.filenameAsTitle)
            .putBoolean("showTrackNumber", s.showTrackNumber)
            .putBoolean("showFormat", s.showFormat)
            .putBoolean("listCovers", s.listCovers)
            .putInt("themeMode", s.themeMode)
            .putInt("fontFamily", s.fontFamily)
            .putInt("layout", s.layout)
            .putBoolean("labelsCentered", s.labelsCentered)
            .putBoolean("labelsBg", s.labelsBg)
            .putBoolean("buttonsBg", s.buttonsBg)
            .putInt("materialYou", s.materialYou)
            .putBoolean("lessRounded", s.lessRounded)
            .putBoolean("proButtons", s.proButtons)
            .putInt("knobHighlight", s.knobHighlight)
            .putBoolean("eqColorful", s.eqColorful)
            .putBoolean("statusScrim", s.statusScrim)
            .putInt("navbarPlayer", s.navbarPlayer)
            .putInt("navbarOther", s.navbarOther)
            .putBoolean("offsetNavbar", s.offsetNavbar)
            .putString("customSkins", s.customSkins)
            .putBoolean("albumArtAnim", s.albumArtAnim)
            .putBoolean("animateLabels", s.animateLabels)
            .putBoolean("animateLabelsEverywhere", s.animateLabelsEverywhere)
            .putString("playerButtons", s.playerButtons)
            .putBoolean("preferNoGap", s.preferNoGap)
            .putBoolean("noEditOnLongPress", s.noEditOnLongPress)
            .putBoolean("coverMenu", s.coverMenu)
            .putInt("menuLongPress", s.menuLongPress)
            .putInt("lyricsButton", s.lyricsButton)
            .putInt("line2Press", s.line2Press)
            .putInt("line2LongPress", s.line2LongPress)
            .putBoolean("prevResets", s.prevResets)
            .putBoolean("rewindProLong", s.rewindProLong)
            .putBoolean("folderNavFlat", s.folderNavFlat)
            .putInt("lyricsOffsetMs", s.lyricsOffsetMs)
            .putInt("lyricsMenuAction", s.lyricsMenuAction)
            .putString("lyricsUrl", s.lyricsUrl)
            .putString("lyricsApp", s.lyricsApp)
            .putBoolean("scanLrc", s.scanLrc)
            .putString("lrcFolderUri", s.lrcFolderUri)
            .putBoolean("lyricsUtf8", s.lyricsUtf8)
            .putInt("lyricsCharset", s.lyricsCharset)
            .putBoolean("lyricsAuto", s.lyricsAuto)
            .putBoolean("lyricsWifiOnly", s.lyricsWifiOnly)
            .putInt("notifType", s.notifType)
            .putInt("notifColors", s.notifColors)
            .putBoolean("colorizeNotification", s.colorizeNotification)
            .putString("notifButtons", s.notifButtons)
            .putBoolean("notifOpenList", s.notifOpenList)
            .putBoolean("keepNotification", s.keepNotification)
            .putBoolean("keepInactiveNotification", s.keepInactiveNotification)
            .putBoolean("keepService", s.keepService)
            .putBoolean("removeOnDisconnect", s.removeOnDisconnect)
            .putInt("autoFading", s.autoFading)
            .putInt("manualFading", s.manualFading)
            .putBoolean("fadePlayPause", s.fadePlayPause)
            .putBoolean("fadeOnSeek", s.fadeOnSeek)
            .putInt("preloadMs", s.preloadMs)
            .putInt("silenceMs", s.silenceMs)
            .putInt("crossfadeMs", s.crossfadeMs)
            .putInt("shortCrossfadeMs", s.shortCrossfadeMs)
            .putInt("playPauseFadeMs", s.playPauseFadeMs)
            .putInt("seekFadeMs", s.seekFadeMs)
            .putInt("rgApply", s.rgApply)
            .putInt("rgSource", s.rgSource)
            .putFloat("rgPreampWith", s.rgPreampWith)
            .putFloat("rgPreampWithout", s.rgPreampWithout)
            .putBoolean("resumeAfterCall", s.resumeAfterCall)
            .putBoolean("resumeOnStart", s.resumeOnStart)
            .putBoolean("resumeOnReopen", s.resumeOnReopen)
            .putBoolean("waitForStorage", s.waitForStorage)
            .putBoolean("focusShort", s.focusShort)
            .putBoolean("pauseInCall", s.pauseInCall)
            .putBoolean("resumeOnGain", s.resumeOnGain)
            .putBoolean("duckVolume", s.duckVolume)
            .putBoolean("focusPermanent", s.focusPermanent)
            .putBoolean("dvc", s.dvc)
            .putBoolean("noDvcBtAbs", s.noDvcBtAbs)
            .putBoolean("noDvcWired", s.noDvcWired)
            .putBoolean("noDvcSpeaker", s.noDvcSpeaker)
            .putBoolean("noDvcBt", s.noDvcBt)
            .putBoolean("noDvcUsb", s.noDvcUsb)
            .putBoolean("noDvcOther", s.noDvcOther)
            .putFloat("preampReductionDb", s.preampReductionDb)
            .putInt("outputType", s.outputType)
            .putString("outputName", s.outputName)
            .putBoolean("bitPerfect", s.bitPerfect)
            .putInt("ditherType", s.ditherType)
            .apply()
    }

    private fun load(): Settings {
        val d = Settings()
        return Settings(
            orientation = prefs.getInt("orientation", d.orientation),
            hideStatusBar = prefs.getBoolean("hideStatusBar", d.hideStatusBar),
            keepScreenOn = prefs.getBoolean("keepScreenOn", d.keepScreenOn),
            ratingType = if (prefs.contains("ratingType")) prefs.getInt("ratingType", d.ratingType) else if (prefs.getBoolean("showRating", true)) 1 else 0,
            menuShortcuts = prefs.getInt("menuShortcuts", d.menuShortcuts),
            // older versions saved the seek bar as an on/off switch
            seekStyle = if (prefs.contains("seekStyle")) prefs.getInt("seekStyle", d.seekStyle) else if (prefs.getBoolean("waveformSeek", true)) 0 else 2,
            vizOpacityPct = prefs.getInt("vizOpacityPct", d.vizOpacityPct),
            vizTimeoutMs = prefs.getInt("vizTimeoutMs", d.vizTimeoutMs),
            vizAutoSeconds = prefs.getInt("vizAutoSeconds", d.vizAutoSeconds),
            bgOn = prefs.getBoolean("bgOn", d.bgOn),
            bgIntensityPct = prefs.getInt("bgIntensityPct", d.bgIntensityPct),
            bgSaturationPct = prefs.getInt("bgSaturationPct", d.bgSaturationPct),
            bgDetails = prefs.getInt("bgDetails", d.bgDetails),
            bgGradientPct = prefs.getInt("bgGradientPct", d.bgGradientPct),
            forceDefaultArt = prefs.getBoolean("forceDefaultArt", d.forceDefaultArt),
            squareCover = prefs.getBoolean("squareCover", d.squareCover),
            minTrackSeconds = prefs.getInt("minTrackSeconds", d.minTrackSeconds),
            ignoreVideo = prefs.getBoolean("ignoreVideo", d.ignoreVideo),
            rememberProgress = prefs.getBoolean("rememberProgress", d.rememberProgress),
            rememberMinMinutes = prefs.getInt("rememberMinMinutes", d.rememberMinMinutes),
            countPlayedPct = prefs.getInt("countPlayedPct", d.countPlayedPct),
            excludedFolders = prefs.getStringSet("excludedFolders", null)?.toSet() ?: emptySet(),
            knownFolders = prefs.getStringSet("knownFolders", null)?.toSet() ?: emptySet(),
            pauseOnUnplug = prefs.getBoolean("pauseOnUnplug", d.pauseOnUnplug),
            showOnLock = prefs.getBoolean("showOnLock", d.showOnLock),
            tipsShown = prefs.getBoolean("tipsShown", d.tipsShown),
            skin = prefs.getInt("skin", d.skin),
            fontBoost = prefs.getInt("fontBoost", d.fontBoost),
            animations = prefs.getInt("animations", d.animations),
            startAtPlayer = prefs.getBoolean("startAtPlayer", d.startAtPlayer),
            timePills = prefs.getBoolean("timePills", d.timePills),
            showInfoLine = prefs.getBoolean("showInfoLine", d.showInfoLine),
            coverSwipe = prefs.getBoolean("coverSwipe", d.coverSwipe),
            lyricsZoom = if (prefs.contains("lyricsZoom")) prefs.getFloat("lyricsZoom", d.lyricsZoom) else when (prefs.getInt("lyricsSize", 1)) { 0 -> 0.8f; 2 -> 1.3f; 3 -> 1.6f; else -> 1f },
            lyricsAutoScroll = prefs.getBoolean("lyricsAutoScroll", d.lyricsAutoScroll),
            lyricsKeepOn = prefs.getBoolean("lyricsKeepOn", d.lyricsKeepOn),
            lyricsSwipe = if (prefs.contains("lyricsSwipeMode")) prefs.getInt("lyricsSwipeMode", d.lyricsSwipe) else if (prefs.getBoolean("lyricsSwipe", true)) 2 else 0,
            stopOnSwipe = prefs.getBoolean("stopOnSwipe", d.stopOnSwipe),
            filenameAsTitle = prefs.getBoolean("filenameAsTitle", d.filenameAsTitle),
            showTrackNumber = prefs.getBoolean("showTrackNumber", d.showTrackNumber),
            showFormat = prefs.getBoolean("showFormat", d.showFormat),
            listCovers = prefs.getBoolean("listCovers", d.listCovers),
            themeMode = prefs.getInt("themeMode", d.themeMode),
            fontFamily = prefs.getInt("fontFamily", d.fontFamily),
            layout = prefs.getInt("layout", d.layout),
            labelsCentered = prefs.getBoolean("labelsCentered", d.labelsCentered),
            labelsBg = prefs.getBoolean("labelsBg", d.labelsBg),
            buttonsBg = prefs.getBoolean("buttonsBg", d.buttonsBg),
            materialYou = prefs.getInt("materialYou", d.materialYou),
            lessRounded = prefs.getBoolean("lessRounded", d.lessRounded),
            proButtons = prefs.getBoolean("proButtons", d.proButtons),
            knobHighlight = prefs.getInt("knobHighlight", d.knobHighlight),
            eqColorful = prefs.getBoolean("eqColorful", d.eqColorful),
            statusScrim = prefs.getBoolean("statusScrim", d.statusScrim),
            navbarPlayer = prefs.getInt("navbarPlayer", d.navbarPlayer),
            navbarOther = prefs.getInt("navbarOther", d.navbarOther),
            offsetNavbar = prefs.getBoolean("offsetNavbar", d.offsetNavbar),
            customSkins = prefs.getString("customSkins", d.customSkins) ?: d.customSkins,
            albumArtAnim = prefs.getBoolean("albumArtAnim", d.albumArtAnim),
            animateLabels = prefs.getBoolean("animateLabels", d.animateLabels),
            animateLabelsEverywhere = prefs.getBoolean("animateLabelsEverywhere", d.animateLabelsEverywhere),
            playerButtons = prefs.getString("playerButtons", d.playerButtons) ?: d.playerButtons,
            preferNoGap = prefs.getBoolean("preferNoGap", d.preferNoGap),
            noEditOnLongPress = prefs.getBoolean("noEditOnLongPress", d.noEditOnLongPress),
            coverMenu = prefs.getBoolean("coverMenu", d.coverMenu),
            menuLongPress = prefs.getInt("menuLongPress", d.menuLongPress),
            lyricsButton = prefs.getInt("lyricsButton", d.lyricsButton),
            line2Press = prefs.getInt("line2Press", d.line2Press),
            line2LongPress = prefs.getInt("line2LongPress", d.line2LongPress),
            prevResets = prefs.getBoolean("prevResets", d.prevResets),
            rewindProLong = prefs.getBoolean("rewindProLong", d.rewindProLong),
            folderNavFlat = prefs.getBoolean("folderNavFlat", d.folderNavFlat),
            lyricsOffsetMs = prefs.getInt("lyricsOffsetMs", d.lyricsOffsetMs),
            lyricsMenuAction = prefs.getInt("lyricsMenuAction", d.lyricsMenuAction),
            lyricsUrl = prefs.getString("lyricsUrl", d.lyricsUrl) ?: d.lyricsUrl,
            lyricsApp = prefs.getString("lyricsApp", d.lyricsApp) ?: d.lyricsApp,
            scanLrc = prefs.getBoolean("scanLrc", d.scanLrc),
            lrcFolderUri = prefs.getString("lrcFolderUri", d.lrcFolderUri) ?: d.lrcFolderUri,
            lyricsUtf8 = prefs.getBoolean("lyricsUtf8", d.lyricsUtf8),
            lyricsCharset = prefs.getInt("lyricsCharset", d.lyricsCharset),
            lyricsAuto = prefs.getBoolean("lyricsAuto", d.lyricsAuto),
            lyricsWifiOnly = prefs.getBoolean("lyricsWifiOnly", d.lyricsWifiOnly),
            notifType = prefs.getInt("notifType", d.notifType),
            notifColors = prefs.getInt("notifColors", d.notifColors),
            colorizeNotification = prefs.getBoolean("colorizeNotification", d.colorizeNotification),
            notifButtons = prefs.getString("notifButtons", d.notifButtons) ?: d.notifButtons,
            notifOpenList = prefs.getBoolean("notifOpenList", d.notifOpenList),
            keepNotification = prefs.getBoolean("keepNotification", d.keepNotification),
            keepInactiveNotification = prefs.getBoolean("keepInactiveNotification", d.keepInactiveNotification),
            keepService = prefs.getBoolean("keepService", d.keepService),
            removeOnDisconnect = prefs.getBoolean("removeOnDisconnect", d.removeOnDisconnect),
            autoFading = prefs.getInt("autoFading", d.autoFading),
            manualFading = prefs.getInt("manualFading", d.manualFading),
            fadePlayPause = prefs.getBoolean("fadePlayPause", d.fadePlayPause),
            fadeOnSeek = prefs.getBoolean("fadeOnSeek", d.fadeOnSeek),
            preloadMs = prefs.getInt("preloadMs", d.preloadMs),
            silenceMs = prefs.getInt("silenceMs", d.silenceMs),
            crossfadeMs = prefs.getInt("crossfadeMs", d.crossfadeMs),
            shortCrossfadeMs = prefs.getInt("shortCrossfadeMs", d.shortCrossfadeMs),
            playPauseFadeMs = prefs.getInt("playPauseFadeMs", d.playPauseFadeMs),
            seekFadeMs = prefs.getInt("seekFadeMs", d.seekFadeMs),
            rgApply = prefs.getInt("rgApply", d.rgApply),
            rgSource = prefs.getInt("rgSource", d.rgSource),
            rgPreampWith = prefs.getFloat("rgPreampWith", d.rgPreampWith),
            rgPreampWithout = prefs.getFloat("rgPreampWithout", d.rgPreampWithout),
            resumeAfterCall = prefs.getBoolean("resumeAfterCall", d.resumeAfterCall),
            resumeOnStart = prefs.getBoolean("resumeOnStart", d.resumeOnStart),
            resumeOnReopen = prefs.getBoolean("resumeOnReopen", d.resumeOnReopen),
            waitForStorage = prefs.getBoolean("waitForStorage", d.waitForStorage),
            focusShort = prefs.getBoolean("focusShort", d.focusShort),
            pauseInCall = prefs.getBoolean("pauseInCall", d.pauseInCall),
            resumeOnGain = prefs.getBoolean("resumeOnGain", d.resumeOnGain),
            duckVolume = prefs.getBoolean("duckVolume", d.duckVolume),
            focusPermanent = prefs.getBoolean("focusPermanent", d.focusPermanent),
            dvc = prefs.getBoolean("dvc", d.dvc),
            noDvcBtAbs = prefs.getBoolean("noDvcBtAbs", d.noDvcBtAbs),
            noDvcWired = prefs.getBoolean("noDvcWired", d.noDvcWired),
            noDvcSpeaker = prefs.getBoolean("noDvcSpeaker", d.noDvcSpeaker),
            noDvcBt = prefs.getBoolean("noDvcBt", d.noDvcBt),
            noDvcUsb = prefs.getBoolean("noDvcUsb", d.noDvcUsb),
            noDvcOther = prefs.getBoolean("noDvcOther", d.noDvcOther),
            preampReductionDb = prefs.getFloat("preampReductionDb", d.preampReductionDb),
            outputType = prefs.getInt("outputType", d.outputType),
            outputName = prefs.getString("outputName", d.outputName) ?: d.outputName,
            bitPerfect = prefs.getBoolean("bitPerfect", d.bitPerfect),
            ditherType = prefs.getInt("ditherType", d.ditherType),
        )
    }
}
