package app.apmplayer.settings

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/** Every choice on the settings pages. The names double as the keys saved on the phone. */
data class Settings(
    // Look and Feel
    val orientation: Int = 0, // 0 default, 1 portrait, 2 landscape
    val hideStatusBar: Boolean = false,
    val keepScreenOn: Boolean = false,
    val showRating: Boolean = true,
    val menuShortcuts: Int = 5,
    val waveformSeek: Boolean = true,
    // Audio
    val fadeMs: Int = 0,
    // Visualization
    val vizOpacityPct: Int = 0,
    val vizTimeoutMs: Int = 3500,
    val vizAutoSeconds: Int = 0,
    // Background
    val bgOn: Boolean = true,
    val bgIntensityPct: Int = 70,
    val bgSaturationPct: Int = 100,
    val bgDetails: Int = 16,
    val bgGradientPct: Int = 100,
    // Album art
    val forceDefaultArt: Boolean = false,
    val squareCover: Boolean = false,
    // Library
    val minTrackSeconds: Int = 6,
    val ignoreVideo: Boolean = true,
    val rememberProgress: Boolean = true,
    val rememberMinMinutes: Int = 45,
    val countPlayedPct: Int = 50,
    val excludedFolders: Set<String> = emptySet(),
    val knownFolders: Set<String> = emptySet(), // filled by the scan, not a choice
    // Headset and lock screen
    val pauseOnUnplug: Boolean = true,
    val showOnLock: Boolean = false,
    // first run tips on the player screen
    val tipsShown: Boolean = false,
    // colour skin, an index into ApmSkins
    val skin: Int = 0,
)

/** Holds the settings, saves each change, and tells the screens. */
class SettingsStore(context: Context) {

    private val prefs = context.getSharedPreferences("settings", Context.MODE_PRIVATE)
    private val _state = MutableStateFlow(load())
    val state: StateFlow<Settings> = _state.asStateFlow()

    fun update(change: (Settings) -> Settings) {
        val next = change(_state.value)
        _state.value = next
        save(next)
    }

    /** Reads everything again, used after a backup was loaded. */
    fun reload() {
        _state.value = load()
    }

    /** Back to the starting values. The list of folders the scan found is kept. */
    fun resetAll() = update { Settings(knownFolders = it.knownFolders, tipsShown = it.tipsShown) }

    private fun save(s: Settings) {
        prefs.edit()
            .putInt("orientation", s.orientation)
            .putBoolean("hideStatusBar", s.hideStatusBar)
            .putBoolean("keepScreenOn", s.keepScreenOn)
            .putBoolean("showRating", s.showRating)
            .putInt("menuShortcuts", s.menuShortcuts)
            .putBoolean("waveformSeek", s.waveformSeek)
            .putInt("fadeMs", s.fadeMs)
            .putInt("vizOpacityPct", s.vizOpacityPct)
            .putInt("vizTimeoutMs", s.vizTimeoutMs)
            .putInt("vizAutoSeconds", s.vizAutoSeconds)
            .putBoolean("bgOn", s.bgOn)
            .putInt("bgIntensityPct", s.bgIntensityPct)
            .putInt("bgSaturationPct", s.bgSaturationPct)
            .putInt("bgDetails", s.bgDetails)
            .putInt("bgGradientPct", s.bgGradientPct)
            .putBoolean("forceDefaultArt", s.forceDefaultArt)
            .putBoolean("squareCover", s.squareCover)
            .putInt("minTrackSeconds", s.minTrackSeconds)
            .putBoolean("ignoreVideo", s.ignoreVideo)
            .putBoolean("rememberProgress", s.rememberProgress)
            .putInt("rememberMinMinutes", s.rememberMinMinutes)
            .putInt("countPlayedPct", s.countPlayedPct)
            .putStringSet("excludedFolders", HashSet(s.excludedFolders))
            .putStringSet("knownFolders", HashSet(s.knownFolders))
            .putBoolean("pauseOnUnplug", s.pauseOnUnplug)
            .putBoolean("showOnLock", s.showOnLock)
            .putBoolean("tipsShown", s.tipsShown)
            .putInt("skin", s.skin)
            .apply()
    }

    private fun load(): Settings {
        val d = Settings()
        return Settings(
            orientation = prefs.getInt("orientation", d.orientation),
            hideStatusBar = prefs.getBoolean("hideStatusBar", d.hideStatusBar),
            keepScreenOn = prefs.getBoolean("keepScreenOn", d.keepScreenOn),
            showRating = prefs.getBoolean("showRating", d.showRating),
            menuShortcuts = prefs.getInt("menuShortcuts", d.menuShortcuts),
            waveformSeek = prefs.getBoolean("waveformSeek", d.waveformSeek),
            fadeMs = prefs.getInt("fadeMs", d.fadeMs),
            vizOpacityPct = prefs.getInt("vizOpacityPct", d.vizOpacityPct),
            vizTimeoutMs = prefs.getInt("vizTimeoutMs", d.vizTimeoutMs),
            vizAutoSeconds = prefs.getInt("vizAutoSeconds", d.vizAutoSeconds),
            bgOn = prefs.getBoolean("bgOn", d.bgOn),
            bgIntensityPct = prefs.getInt("bgIntensityPct", d.bgIntensityPct),
            bgSaturationPct = prefs.getInt("bgSaturationPct", d.bgSaturationPct),
            bgDetails = prefs.getInt("bgDetails", d.bgDetails),
            bgGradientPct = prefs.getInt("bgGradientPct", d.bgGradientPct),
            forceDefaultArt = prefs.getBoolean("forceDefaultArt", d.forceDefaultArt),
            squareCover = prefs.getBoolean("squareCover", d.squareCover),
            minTrackSeconds = prefs.getInt("minTrackSeconds", d.minTrackSeconds),
            ignoreVideo = prefs.getBoolean("ignoreVideo", d.ignoreVideo),
            rememberProgress = prefs.getBoolean("rememberProgress", d.rememberProgress),
            rememberMinMinutes = prefs.getInt("rememberMinMinutes", d.rememberMinMinutes),
            countPlayedPct = prefs.getInt("countPlayedPct", d.countPlayedPct),
            excludedFolders = prefs.getStringSet("excludedFolders", null)?.toSet() ?: emptySet(),
            knownFolders = prefs.getStringSet("knownFolders", null)?.toSet() ?: emptySet(),
            pauseOnUnplug = prefs.getBoolean("pauseOnUnplug", d.pauseOnUnplug),
            showOnLock = prefs.getBoolean("showOnLock", d.showOnLock),
            tipsShown = prefs.getBoolean("tipsShown", d.tipsShown),
            skin = prefs.getInt("skin", d.skin),
        )
    }
}
