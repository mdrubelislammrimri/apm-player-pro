package app.apmplayer.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.Notes
import androidx.compose.material.icons.automirrored.rounded.PlaylistAdd
import androidx.compose.material.icons.rounded.Album
import androidx.compose.material.icons.rounded.BookmarkBorder
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Folder
import androidx.compose.material.icons.rounded.Image
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.Mic
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.ThumbDown
import androidx.compose.material.icons.rounded.ThumbUp
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import app.apmplayer.data.TrackDetail
import app.apmplayer.ui.components.GeneratedArt
import app.apmplayer.ui.components.focusRing
import app.apmplayer.ui.theme.Apm
import app.apmplayer.ui.theme.ApmShape
import app.apmplayer.ui.theme.ApmSpace
import app.apmplayer.util.formatDuration
import app.apmplayer.util.mimeToExtension

/**
 * The three dot menu for a track. Album Art and Lyrics are built in a later part and shown dimmed.
 * Artist, Album and Genre are dimmed when the song has no such tag.
 * Rating: thumbs up = 5, thumbs down = 1, none = 0.
 */
@Composable
fun TrackMenu(
    detail: TrackDetail,
    onDismiss: () -> Unit,
    onLike: () -> Unit,
    onDislike: () -> Unit,
    onDelete: () -> Unit,
    onInfo: () -> Unit,
    onFolder: () -> Unit,
    onPlaylist: () -> Unit,
    onBookmark: () -> Unit,
    onArtist: () -> Unit,
    onAlbum: () -> Unit,
    onGenre: () -> Unit,
) {
    val rating = detail.track.rating
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Box(
            Modifier.fillMaxSize().clickable(
                interactionSource = remember { MutableInteractionSource() }, indication = null, onClick = onDismiss,
            ),
            contentAlignment = Alignment.Center,
        ) {
            Column(
                Modifier.fillMaxWidth().padding(horizontal = 16.dp).clip(RoundedCornerShape(36.dp))
                    .background(Color(0xFF212121))
                    .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) {}
                    .padding(horizontal = ApmSpace.s5, vertical = ApmSpace.s5),
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(ApmSpace.s4)) {
                    GeneratedArt(seed = detail.track.id, modifier = Modifier.size(96.dp), shape = ApmShape.md)
                    Column(Modifier.weight(1f)) {
                        Text(
                            detail.track.title, style = Apm.type.title.copy(fontWeight = FontWeight.Bold),
                            color = Color.White, maxLines = 2, overflow = TextOverflow.Ellipsis,
                        )
                        Text(
                            detail.artistName ?: "Unknown artist",
                            style = Apm.type.body.copy(fontWeight = FontWeight.Bold), color = Color.White,
                            maxLines = 1, overflow = TextOverflow.Ellipsis,
                        )
                        Text(
                            formatDuration(detail.track.durationMs) + " | " + mimeToExtension(detail.track.mimeType),
                            style = Apm.type.bodySm.copy(fontWeight = FontWeight.SemiBold), color = Color(0xFF9A9A9A),
                        )
                        Row(Modifier.padding(top = ApmSpace.s2), horizontalArrangement = Arrangement.spacedBy(ApmSpace.s2)) {
                            ThumbPill(Icons.Rounded.ThumbUp, "Like", rating == 5, onLike)
                            ThumbPill(Icons.Rounded.ThumbDown, "Dislike", rating == 1, onDislike)
                        }
                    }
                }
                Divider()
                Row(Modifier.fillMaxWidth()) { MenuItem(Icons.Rounded.Delete, "Delete", true, onDelete, Modifier.fillMaxWidth()) }
                Row(Modifier.fillMaxWidth()) {
                    MenuItem(Icons.AutoMirrored.Rounded.PlaylistAdd, "Playlist", true, onPlaylist, Modifier.weight(1f))
                    MenuItem(Icons.Rounded.BookmarkBorder, "Bookmark", true, onBookmark, Modifier.weight(1f))
                }
                Row(Modifier.fillMaxWidth()) {
                    MenuItem(Icons.Rounded.Image, "Album Art", false, {}, Modifier.weight(1f))
                    Box(Modifier.weight(1f))
                }
                Row(Modifier.fillMaxWidth()) {
                    MenuItem(Icons.Rounded.Info, "Info/Tags", true, onInfo, Modifier.weight(1f))
                    MenuItem(Icons.AutoMirrored.Rounded.Notes, "Lyrics", false, {}, Modifier.weight(1f))
                }
                Divider()
                Row(Modifier.fillMaxWidth()) {
                    MenuItem(Icons.Rounded.Mic, "Artist", detail.track.artistId != null, onArtist, Modifier.weight(1f))
                    MenuItem(Icons.Rounded.Album, "Album", detail.track.albumId != null, onAlbum, Modifier.weight(1f))
                }
                Row(Modifier.fillMaxWidth()) {
                    MenuItem(Icons.Rounded.Folder, "Folder", true, onFolder, Modifier.weight(1f))
                    MenuItem(Icons.Rounded.MusicNote, "Genre", !detail.track.genre.isNullOrBlank(), onGenre, Modifier.weight(1f))
                }
            }
        }
    }
}

@Composable
private fun Divider() {
    Box(Modifier.fillMaxWidth().padding(vertical = ApmSpace.s3).height(1.dp).background(Color(0xFF3A3A3A)))
}

@Composable
private fun ThumbPill(icon: ImageVector, description: String, on: Boolean, onClick: () -> Unit) {
    Box(
        Modifier.size(width = 64.dp, height = 44.dp).clip(ApmShape.pill)
            .border(1.5.dp, if (on) Apm.colors.accent else Color(0xFF8A8A8A), ApmShape.pill)
            .focusRing(ApmShape.pill).clickable(role = Role.Button, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Icon(icon, contentDescription = description, tint = if (on) Apm.colors.accent else Color.White, modifier = Modifier.size(22.dp))
    }
}

@Composable
private fun MenuItem(icon: ImageVector, label: String, enabled: Boolean, onClick: () -> Unit, modifier: Modifier) {
    Row(
        modifier
            .heightIn(min = 60.dp)
            .alpha(if (enabled) 1f else 0.4f)
            .focusRing(ApmShape.md)
            .clickable(enabled = enabled, role = Role.Button, onClick = onClick),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(ApmSpace.s4),
    ) {
        Icon(icon, contentDescription = null, tint = Color.White, modifier = Modifier.size(28.dp))
        Text(label, style = Apm.type.title.copy(fontWeight = FontWeight.Bold), color = Color.White)
    }
}
