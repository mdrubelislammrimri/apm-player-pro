package app.apmplayer.ui.screens

import androidx.compose.foundation.combinedClickable
import app.apmplayer.ui.components.StarRating
import app.apmplayer.ui.theme.n
import app.apmplayer.ui.components.TrackArt
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.Notes
import androidx.compose.material.icons.automirrored.rounded.PlaylistAdd
import androidx.compose.material.icons.rounded.Album
import androidx.compose.material.icons.rounded.BookmarkBorder
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Folder
import androidx.compose.material.icons.rounded.Image
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.Mic
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.ThumbDown
import androidx.compose.material.icons.rounded.ThumbUp
import androidx.compose.material3.Icon
import app.apmplayer.ui.components.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import app.apmplayer.data.TrackDetail
import app.apmplayer.ui.components.GeneratedArt
import app.apmplayer.ui.components.focusRing
import app.apmplayer.ui.theme.Apm
import app.apmplayer.ui.theme.ApmShape
import app.apmplayer.ui.theme.ApmSpace
import app.apmplayer.util.formatDuration
import app.apmplayer.util.mimeToExtension

/**
 * The three dot menu for a track.
 * Artist, Album and Genre are dimmed when the song has no such tag.
 * Rating: thumbs up = 5, thumbs down = 1, none = 0.
 */
@Composable
fun TrackMenu(
    detail: TrackDetail,
    onDismiss: () -> Unit,
    onLike: () -> Unit,
    onDislike: () -> Unit,
    onDelete: () -> Unit,
    onInfo: () -> Unit,
    onFolder: () -> Unit,
    onPlaylist: () -> Unit,
    onBookmark: () -> Unit,
    onArtist: () -> Unit,
    onAlbum: () -> Unit,
    onGenre: () -> Unit,
    onLyrics: () -> Unit,
    ratingType: Int = 1,
    onRate: (Int) -> Unit = {},
    onAlbumArt: () -> Unit = {},
    onLyricsLong: () -> Unit = {},
) {
    val rating = detail.track.rating
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Box(
            Modifier.fillMaxSize().clickable(
                interactionSource = remember { MutableInteractionSource() }, indication = null, onClick = onDismiss,
            ),
            contentAlignment = Alignment.Center,
        ) {
            Column(
                Modifier.fillMaxWidth().padding(horizontal = 16.dp).clip(RoundedCornerShape(36.dp))
                    .background(n(Color(0xFF212121)))
                    .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) {}
                    .padding(horizontal = ApmSpace.s5, vertical = ApmSpace.s5),
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(ApmSpace.s4)) {
                    TrackArt(trackId = detail.track.id, uri = detail.track.uri, modifier = Modifier.size(96.dp), shape = ApmShape.md, sizePx = 256)
                    Column(Modifier.weight(1f)) {
                        Text(
                            detail.track.title, style = Apm.type.title.copy(fontWeight = FontWeight.Bold),
                            color = n(Color.White), maxLines = 2, overflow = TextOverflow.Ellipsis,
                        )
                        Text(
                            detail.artistName ?: "Unknown artist",
                            style = Apm.type.body.copy(fontWeight = FontWeight.Bold), color = n(Color.White),
                            maxLines = 1, overflow = TextOverflow.Ellipsis,
                        )
                        Text(
                            formatDuration(detail.track.durationMs) + " | " + mimeToExtension(detail.track.mimeType),
                            style = Apm.type.bodySm.copy(fontWeight = FontWeight.SemiBold), color = n(Color(0xFF9A9A9A)),
                        )
                        when (ratingType) {
                            1 -> Row(Modifier.padding(top = ApmSpace.s2), horizontalArrangement = Arrangement.spacedBy(ApmSpace.s2)) {
                                ThumbPill(Icons.Rounded.ThumbUp, "Like", rating == 5, onLike)
                                ThumbPill(Icons.Rounded.ThumbDown, "Dislike", rating == 1, onDislike)
                            }
                            2, 3 -> StarRating(rating, onRate, Modifier.padding(top = ApmSpace.s2), starSize = 26.dp)
                        }
                    }
                }
                Divider()
                Row(Modifier.fillMaxWidth()) { MenuItem(Icons.Rounded.Delete, "Delete", true, onDelete, Modifier.fillMaxWidth()) }
                Row(Modifier.fillMaxWidth()) {
                    MenuItem(Icons.AutoMirrored.Rounded.PlaylistAdd, "Playlist", true, onPlaylist, Modifier.weight(1f))
                    MenuItem(Icons.Rounded.BookmarkBorder, "Bookmark", true, onBookmark, Modifier.weight(1f))
                }
                Row(Modifier.fillMaxWidth()) {
                    MenuItem(Icons.Rounded.Image, "Album Art", true, onAlbumArt, Modifier.weight(1f))
                    Box(Modifier.weight(1f))
                }
                Row(Modifier.fillMaxWidth()) {
                    MenuItem(Icons.Rounded.Info, "Info/Tags", true, onInfo, Modifier.weight(1f))
                    MenuItem(Icons.AutoMirrored.Rounded.Notes, "Lyrics", true, onLyrics, Modifier.weight(1f), onLongClick = onLyricsLong)
                }
                Divider()
                Row(Modifier.fillMaxWidth()) {
                    MenuItem(Icons.Rounded.Mic, "Artist", detail.track.artistId != null, onArtist, Modifier.weight(1f))
                    MenuItem(Icons.Rounded.Album, "Album", detail.track.albumId != null, onAlbum, Modifier.weight(1f))
                }
                Row(Modifier.fillMaxWidth()) {
                    MenuItem(Icons.Rounded.Folder, "Folder", true, onFolder, Modifier.weight(1f))
                    MenuItem(Icons.Rounded.MusicNote, "Genre", !detail.track.genre.isNullOrBlank(), onGenre, Modifier.weight(1f))
                }
            }
        }
    }
}

@Composable
private fun Divider() {
    Box(Modifier.fillMaxWidth().padding(vertical = ApmSpace.s3).height(1.dp).background(n(Color(0xFF3A3A3A))))
}

@Composable
private fun ThumbPill(icon: ImageVector, description: String, on: Boolean, onClick: () -> Unit) {
    Box(
        Modifier.size(width = 64.dp, height = 44.dp).clip(ApmShape.pill)
            .border(1.5.dp, if (on) Apm.colors.accent else n(Color(0xFF8A8A8A)), ApmShape.pill)
            .focusRing(ApmShape.pill).clickable(role = Role.Button, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Icon(icon, contentDescription = description, tint = if (on) Apm.colors.accent else n(Color.White), modifier = Modifier.size(22.dp))
    }
}

@Composable
@OptIn(androidx.compose.foundation.ExperimentalFoundationApi::class)
private fun MenuItem(
    icon: ImageVector,
    label: String,
    enabled: Boolean,
    onClick: () -> Unit,
    modifier: Modifier,
    onLongClick: (() -> Unit)? = null,
) {
    Row(
        modifier
            .heightIn(min = 60.dp)
            .alpha(if (enabled) 1f else 0.4f)
            .focusRing(ApmShape.md)
            .combinedClickable(enabled = enabled, role = Role.Button, onClick = onClick, onLongClick = onLongClick),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(ApmSpace.s4),
    ) {
        Icon(icon, contentDescription = null, tint = n(Color.White), modifier = Modifier.size(28.dp))
        Text(label, style = Apm.type.title.copy(fontWeight = FontWeight.Bold), color = n(Color.White))
    }
}
