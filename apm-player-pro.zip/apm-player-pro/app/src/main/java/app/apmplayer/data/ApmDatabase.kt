package app.apmplayer.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [ArtistEntity::class, AlbumEntity::class, FolderEntity::class, TrackEntity::class, QueueItemEntity::class, WaveformEntity::class,
        PlaylistEntity::class, PlaylistItemEntity::class, BookmarkEntity::class,
    ],
    version = 3,
    exportSchema = true,
)
abstract class ApmDatabase : RoomDatabase() {
    abstract fun artistDao(): ArtistDao
    abstract fun albumDao(): AlbumDao
    abstract fun folderDao(): FolderDao
    abstract fun trackDao(): TrackDao
    abstract fun queueDao(): QueueDao
    abstract fun waveformDao(): WaveformDao
    abstract fun browseDao(): BrowseDao
    abstract fun playlistDao(): PlaylistDao
    abstract fun bookmarkDao(): BookmarkDao

    companion object {
        fun create(context: Context): ApmDatabase =
            Room.databaseBuilder(context, ApmDatabase::class.java, "apm.db")
                // Until playlists hold things worth keeping, a schema change may start from an empty database (a scan refills it).
                // From now on, add a real Migration for every change so playlists and bookmarks survive.
                .fallbackToDestructiveMigration()
                .build()
    }
}
