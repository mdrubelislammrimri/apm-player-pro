package app.apmplayer.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [ArtistEntity::class, AlbumEntity::class, FolderEntity::class, TrackEntity::class, QueueItemEntity::class, WaveformEntity::class],
    version = 2,
    exportSchema = true,
)
abstract class ApmDatabase : RoomDatabase() {
    abstract fun artistDao(): ArtistDao
    abstract fun albumDao(): AlbumDao
    abstract fun folderDao(): FolderDao
    abstract fun trackDao(): TrackDao
    abstract fun queueDao(): QueueDao
    abstract fun waveformDao(): WaveformDao

    companion object {
        fun create(context: Context): ApmDatabase =
            Room.databaseBuilder(context, ApmDatabase::class.java, "apm.db")
                // The library is rebuilt by a scan, so a schema change may start from an empty database.
                .fallbackToDestructiveMigration()
                .build()
    }
}
