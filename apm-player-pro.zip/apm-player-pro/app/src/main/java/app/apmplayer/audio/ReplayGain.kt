package app.apmplayer.audio

import android.content.Context
import android.net.Uri
import java.io.ByteArrayInputStream
import java.io.InputStream
import java.io.SequenceInputStream
import kotlin.math.log10
import kotlin.math.min
import kotlin.math.pow

/** The loudness notes written inside a song file. Gains are in decibels, peaks are 1.0 for full scale. Any of them can be missing. */
data class RgInfo(val trackGain: Float?, val albumGain: Float?, val trackPeak: Float?, val albumPeak: Float?)

/** Turns the notes of a song and the user's choices into one gain in decibels. */
object ReplayGainMath {
    /**
     * [mode] 0 uses the track gain (the album gain if the track has none), 1 the album gain (then the track gain).
     * With a gain found, [preampWith] is added. Without one, [preampWithout] is used on its own.
     * [preventClipping] lowers the gain so the loudest sample, if known, stays below full scale.
     */
    fun gainDb(info: RgInfo?, mode: Int, preampWith: Float, preampWithout: Float, preventClipping: Boolean): Float {
        if (info == null) return preampWithout
        val useAlbum = mode == 1
        val gain = (if (useAlbum) info.albumGain ?: info.trackGain else info.trackGain ?: info.albumGain) ?: return preampWithout
        var total = gain + preampWith
        if (preventClipping) {
            val peak = (if (useAlbum) info.albumPeak ?: info.trackPeak else info.trackPeak ?: info.albumPeak)
            if (peak != null && peak > 0f) total = min(total, (-20.0 * log10(peak.toDouble())).toFloat())
        }
        return total
    }

    fun toLinear(db: Float): Double = 10.0.pow(db / 20.0)

    /** "-6.50 dB" to -6.5. Null when the text holds no number. */
    fun parseGain(text: String): Float? = Regex("[-+]?\\d+(?:[.,]\\d+)?").find(text)?.value?.replace(',', '.')?.toFloatOrNull()

    fun parsePeak(text: String): Float? = text.trim().replace(',', '.').toFloatOrNull()
}

/** Reads the replay gain notes of a song: MP3 (ID3 TXXX), FLAC and OGG (Vorbis comments), M4A (free form atoms). */
object ReplayGainTags {
    private val latin1 = Charsets.ISO_8859_1

    fun read(context: Context, uri: Uri): RgInfo? = try {
        context.contentResolver.openInputStream(uri)?.use { raw ->
            val head = ByteArray(12)
            if (readFully(raw, head) < 12) {
                null
            } else {
                val full = SequenceInputStream(ByteArrayInputStream(head), raw)
                val fields: Map<String, String>? = when {
                    String(head, 0, 3, latin1) == "ID3" -> id3(full)
                    String(head, 0, 4, latin1) == "fLaC" -> flac(full)
                    String(head, 0, 4, latin1) == "OggS" -> ogg(full)
                    String(head, 4, 4, latin1) == "ftyp" -> mp4(full)
                    else -> null
                }
                fields?.let { info(it) }
            }
        }
    } catch (e: Exception) {
        null
    }

    private fun info(f: Map<String, String>): RgInfo? {
        val track = f["REPLAYGAIN_TRACK_GAIN"]?.let { ReplayGainMath.parseGain(it) }
        val album = f["REPLAYGAIN_ALBUM_GAIN"]?.let { ReplayGainMath.parseGain(it) }
        val trackPeak = f["REPLAYGAIN_TRACK_PEAK"]?.let { ReplayGainMath.parsePeak(it) }
        val albumPeak = f["REPLAYGAIN_ALBUM_PEAK"]?.let { ReplayGainMath.parsePeak(it) }
        return if (track == null && album == null) null else RgInfo(track, album, trackPeak, albumPeak)
    }

    // ---------------------------------------------------------------- MP3

    private fun id3(input: InputStream): Map<String, String>? {
        val header = ByteArray(10)
        if (readFully(input, header) < 10) return null
        val major = header[3].toInt()
        if (major != 3 && major != 4) return null
        val size = synchsafe(header, 6)
        if (size <= 0 || size > 4_000_000) return null
        val body = ByteArray(size)
        readFully(input, body)
        var p = 0
        if (header[5].toInt() and 0x40 != 0 && size >= 4) p = if (major == 4) synchsafe(body, 0) else 4 + be32(body, 0)
        val out = HashMap<String, String>()
        while (p + 10 <= body.size) {
            if (body[p].toInt() == 0) break
            val id = String(body, p, 4, latin1)
            val fsize = if (major == 4) synchsafe(body, p + 4) else be32(body, p + 4)
            val start = p + 10
            val end = start + fsize
            if (fsize <= 0 || end > body.size) break
            if (id == "TXXX" && end - start > 2) {
                val enc = body[start].toInt()
                val width = if (enc == 1 || enc == 2) 2 else 1
                var t = start + 1
                while (t + width <= end && !(if (width == 2) body[t].toInt() == 0 && body[t + 1].toInt() == 0 else body[t].toInt() == 0)) t += width
                val key = decode(body, start + 1, t, enc).uppercase().trim()
                val value = decode(body, minOf(t + width, end), end, enc).trim { it <= ' ' || it == '\u0000' }
                if (key.startsWith("REPLAYGAIN_")) out[key] = value
            }
            p = end
        }
        return out
    }

    private fun decode(b: ByteArray, from: Int, to: Int, enc: Int): String {
        val len = (to - from).coerceAtLeast(0)
        return when (enc) {
            1 -> String(b, from, len, Charsets.UTF_16)
            2 -> String(b, from, len, Charsets.UTF_16BE)
            3 -> String(b, from, len, Charsets.UTF_8)
            else -> String(b, from, len, latin1)
        }
    }

    // ---------------------------------------------------------------- FLAC and OGG

    private fun flac(input: InputStream): Map<String, String>? {
        skipFully(input, 4)
        repeat(64) {
            val h = ByteArray(4)
            if (readFully(input, h) < 4) return null
            val last = h[0].toInt() and 0x80 != 0
            val type = h[0].toInt() and 0x7F
            val len = ((h[1].toInt() and 0xFF) shl 16) or ((h[2].toInt() and 0xFF) shl 8) or (h[3].toInt() and 0xFF)
            if (type == 4 && len in 1..4_000_000) {
                val data = ByteArray(len)
                readFully(input, data)
                return vorbis(data, 0)
            }
            skipFully(input, len.toLong())
            if (last) return null
        }
        return null
    }

    private fun ogg(input: InputStream): Map<String, String>? {
        val buf = ByteArray(300_000)
        val n = readFully(input, buf)
        val opus = indexOf(buf, n, "OpusTags".toByteArray(latin1))
        if (opus >= 0) return vorbis(buf.copyOfRange(0, n), opus + 8)
        val vorbis = indexOf(buf, n, byteArrayOf(3) + "vorbis".toByteArray(latin1))
        if (vorbis >= 0) return vorbis(buf.copyOfRange(0, n), vorbis + 7)
        return null
    }

    private fun vorbis(d: ByteArray, from: Int): Map<String, String>? {
        var p = from
        if (p + 4 > d.size) return null
        p += 4 + le32(d, p)
        if (p + 4 > d.size) return null
        val count = le32(d, p)
        p += 4
        val out = HashMap<String, String>()
        for (i in 0 until count) {
            if (p + 4 > d.size) break
            val len = le32(d, p)
            p += 4
            if (len < 0 || p + len > d.size) break
            val entry = String(d, p, len, Charsets.UTF_8)
            p += len
            val eq = entry.indexOf('=')
            if (eq > 0) out[entry.substring(0, eq).uppercase()] = entry.substring(eq + 1)
        }
        return out
    }

    // ---------------------------------------------------------------- M4A

    private fun mp4(input: InputStream): Map<String, String>? {
        repeat(200) {
            val h = ByteArray(8)
            if (readFully(input, h) < 8) return null
            var size = be32(h, 0).toLong() and 0xFFFFFFFFL
            val type = String(h, 4, 4, latin1)
            var headerLen = 8L
            if (size == 1L) {
                val ext = ByteArray(8)
                if (readFully(input, ext) < 8) return null
                size = 0
                for (b in ext) size = (size shl 8) or (b.toLong() and 0xFF)
                headerLen = 16
            }
            if (size < headerLen) return null
            val payload = size - headerLen
            if (type == "moov") {
                if (payload > 16_000_000) return null
                val data = ByteArray(payload.toInt())
                readFully(input, data)
                val out = HashMap<String, String>()
                freeForm(data, 0, data.size, out)
                return out
            }
            skipFully(input, payload)
        }
        return null
    }

    /** Looks for "----" atoms (a name and a text) inside udta, meta and ilst. */
    private fun freeForm(d: ByteArray, from: Int, to: Int, out: MutableMap<String, String>) {
        var p = from
        while (p + 8 <= to) {
            val size = be32(d, p)
            val type = String(d, p + 4, 4, latin1)
            if (size < 8 || p + size > to) return
            when (type) {
                "udta", "ilst" -> freeForm(d, p + 8, p + size, out)
                "meta" -> freeForm(d, p + 12, p + size, out)
                "----" -> {
                    var name: String? = null
                    var value: String? = null
                    var q = p + 8
                    while (q + 8 <= p + size) {
                        val ds = be32(d, q)
                        if (ds < 8 || q + ds > p + size) break
                        val dt = String(d, q + 4, 4, latin1)
                        if (dt == "name" && ds > 12) name = String(d, q + 12, ds - 12, Charsets.UTF_8)
                        if (dt == "data" && ds > 16) value = String(d, q + 16, ds - 16, Charsets.UTF_8)
                        q += ds
                    }
                    if (name != null && value != null) out[name.uppercase()] = value
                }
            }
            p += size
        }
    }

    // ---------------------------------------------------------------- small helpers

    private fun readFully(input: InputStream, buf: ByteArray): Int {
        var total = 0
        while (total < buf.size) {
            val n = input.read(buf, total, buf.size - total)
            if (n < 0) break
            total += n
        }
        return total
    }

    private fun skipFully(input: InputStream, count: Long) {
        var left = count
        val sink = ByteArray(8192)
        while (left > 0) {
            val skipped = input.skip(left)
            if (skipped > 0) {
                left -= skipped
            } else {
                val n = input.read(sink, 0, minOf(left, sink.size.toLong()).toInt())
                if (n < 0) return
                left -= n
            }
        }
    }

    private fun indexOf(buf: ByteArray, len: Int, pattern: ByteArray): Int {
        outer@ for (i in 0..(len - pattern.size)) {
            for (j in pattern.indices) if (buf[i + j] != pattern[j]) continue@outer
            return i
        }
        return -1
    }

    private fun synchsafe(b: ByteArray, o: Int) =
        ((b[o].toInt() and 0x7F) shl 21) or ((b[o + 1].toInt() and 0x7F) shl 14) or ((b[o + 2].toInt() and 0x7F) shl 7) or (b[o + 3].toInt() and 0x7F)

    private fun be32(b: ByteArray, o: Int) =
        ((b[o].toInt() and 0xFF) shl 24) or ((b[o + 1].toInt() and 0xFF) shl 16) or ((b[o + 2].toInt() and 0xFF) shl 8) or (b[o + 3].toInt() and 0xFF)

    private fun le32(b: ByteArray, o: Int) =
        (b[o].toInt() and 0xFF) or ((b[o + 1].toInt() and 0xFF) shl 8) or ((b[o + 2].toInt() and 0xFF) shl 16) or ((b[o + 3].toInt() and 0xFF) shl 24)
}
