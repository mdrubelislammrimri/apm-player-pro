package app.apmplayer.ui

import app.apmplayer.ui.components.LocalArtLoader
import app.apmplayer.ui.components.TrackArt
import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.ui.draw.clip
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.selection.selectableGroup
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.QueueMusic
import androidx.compose.material.icons.rounded.Apps
import androidx.compose.material.icons.rounded.Menu
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.layout.Box
import androidx.compose.ui.text.font.FontWeight
import app.apmplayer.ui.screens.AlbumsScreen
import app.apmplayer.ui.screens.ArtistsScreen
import app.apmplayer.ui.screens.EqualizerScreen
import app.apmplayer.ui.screens.FoldersFlatScreen
import app.apmplayer.ui.screens.BookmarksScreen
import app.apmplayer.ui.screens.LibraryHomeScreen
import app.apmplayer.ui.screens.NameGroupsScreen
import app.apmplayer.ui.screens.PlaylistsScreen
import app.apmplayer.ui.screens.QueueScreen
import app.apmplayer.ui.screens.SongsKindScreen
import app.apmplayer.ui.screens.YearsScreen
import app.apmplayer.ui.screens.SearchScreen
import app.apmplayer.ui.screens.SettingsDetailScreen
import app.apmplayer.ui.screens.SettingsScreen
import androidx.compose.material.icons.rounded.Equalizer
import androidx.compose.material.icons.rounded.LibraryMusic
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import app.apmplayer.AppContainer
import app.apmplayer.playback.PlayerUiState
import app.apmplayer.ui.components.GeneratedArt
import app.apmplayer.ui.components.PillButton
import app.apmplayer.ui.components.focusRing
import app.apmplayer.ui.screens.FoldersScreen
import app.apmplayer.ui.screens.NowPlayingScreen
import app.apmplayer.ui.screens.StubScreen
import app.apmplayer.ui.theme.Apm
import app.apmplayer.ui.theme.ApmLayout
import app.apmplayer.ui.theme.ApmShape
import app.apmplayer.ui.theme.ApmSpace

object Routes {
    const val FOLDERS = "folders"
    const val FOLDERS_PATTERN = "folders?path={path}"
    const val NOW_PLAYING = "now_playing"
    const val EQUALIZER = "equalizer"
    const val SOUND_KNOBS = "sound_knobs"
    const val ALBUMS = "albums"
    const val LIBRARY = "library"
    const val SEARCH = "search"
    const val QUEUE = "queue"
    const val SETTINGS = "settings"
    const val SETTINGS_GROUP = "settings/{group}"
    const val ARTISTS = "artists"
    const val YEARS = "years"
    const val FOLDERS_FLAT = "folders_flat"
    const val SONGS_PATTERN = "songs/{kind}?title={title}&arg={arg}"
    const val PLAYLISTS = "playlists"
    const val BOOKMARKS = "bookmarks"
    const val GROUPS_PATTERN = "groups/{kind}"
}

private data class NavItem(val route: String, val label: String, val icon: androidx.compose.ui.graphics.vector.ImageVector)

private const val MENU_ROUTE = "menu"

// Screens that belong to the library, so the Library icon stays lit on them.
private val libraryPrefixes = listOf("library", "folders", "songs", "albums", "artists", "years", "queue", "playlists", "bookmarks", "groups")

private val navItems = listOf(
    NavItem(Routes.LIBRARY, "Library", Icons.Rounded.Apps),
    NavItem(Routes.EQUALIZER, "Equalizer", Icons.Rounded.Equalizer),
    NavItem(Routes.SEARCH, "Search", Icons.Rounded.Search),
    NavItem(MENU_ROUTE, "Menu", Icons.Rounded.Menu),
)

@Composable
fun AppRoot(container: AppContainer) {
    androidx.compose.runtime.CompositionLocalProvider(LocalArtLoader provides container.art) {
        PermissionGate(container) { AppScaffold(container) }
    }
}

/** Asks for permission to read music (and to show the playback notification on Android 13+). */
@Composable
private fun PermissionGate(container: AppContainer, content: @Composable () -> Unit) {
    val context = LocalContext.current
    val audioPermission = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO
    else Manifest.permission.READ_EXTERNAL_STORAGE

    fun hasAudioAccess() =
        ContextCompat.checkSelfPermission(context, audioPermission) == PackageManager.PERMISSION_GRANTED

    var granted by remember { mutableStateOf(hasAudioAccess()) }
    var asked by rememberSaveable { mutableStateOf(false) }

    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        granted = hasAudioAccess()
        asked = true
    }
    val toRequest = if (Build.VERSION.SDK_INT >= 33) arrayOf(audioPermission, Manifest.permission.POST_NOTIFICATIONS)
    else arrayOf(audioPermission)

    // Coming back from the system settings page counts as a fresh check.
    val lifecycleOwner = LocalLifecycleOwner.current
    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) granted = hasAudioAccess()
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    LaunchedEffect(Unit) { if (!granted) launcher.launch(toRequest) }
    LaunchedEffect(granted) { if (granted) container.repository.startScan() }

    if (granted) {
        content()
    } else {
        Column(
            Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(ApmSpace.s5),
            verticalArrangement = Arrangement.spacedBy(ApmSpace.s3, Alignment.CenterVertically),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Text("Allow access to your music", style = Apm.type.title, color = Apm.colors.text, textAlign = TextAlign.Center)
            Text(
                "The player needs to see the audio files on this phone. Nothing leaves your device.",
                style = Apm.type.bodySm, color = Apm.colors.textMuted, textAlign = TextAlign.Center,
            )
            PillButton("Allow access", icon = null, filled = true) { launcher.launch(toRequest) }
            if (asked) {
                PillButton("Open phone settings", icon = null, filled = false) {
                    context.startActivity(
                        Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.fromParts("package", context.packageName, null))
                    )
                }
            }
        }
    }
}

@Composable
private fun AppScaffold(container: AppContainer) {
    val navController = rememberNavController()
    val backStack by navController.currentBackStackEntryAsState()
    val route = backStack?.destination?.route.orEmpty()
    val playerState by container.player.state.collectAsStateWithLifecycle()
    val onNowPlaying = route == Routes.NOW_PLAYING
    var showMenu by remember { mutableStateOf(false) }
    val fullScreenViz by container.fullScreenViz.collectAsStateWithLifecycle()

    Scaffold(
        containerColor = Apm.colors.bg,
        bottomBar = {
            if (!fullScreenViz) Dock(
                state = playerState,
                showMiniPlayer = !onNowPlaying,
                currentRoute = route,
                onOpenPlayer = { navController.navigate(Routes.NOW_PLAYING) },
                onTogglePlay = { container.player.togglePlayPause() },
                onSelect = { item ->
                    if (item.route == MENU_ROUTE) showMenu = true else navigateTopLevel(navController, item.route)
                },
            )
        },
    ) { padding ->
        NavHost(
            navController = navController,
            startDestination = Routes.LIBRARY,
            modifier = Modifier.padding(padding),
        ) {
            composable(
                Routes.FOLDERS_PATTERN,
                arguments = listOf(navArgument("path") { type = NavType.StringType; defaultValue = "" }),
            ) { entry ->
                val path = entry.arguments?.getString("path").orEmpty()
                FoldersScreen(
                    path = path,
                    container = container,
                    onOpenFolder = { navController.navigate("${Routes.FOLDERS}?path=${Uri.encode(it)}") },
                    onUp = { navController.popBackStack() },
                    onOpenNowPlaying = { navController.navigate(Routes.NOW_PLAYING) },
                    onOpenSettings = { navController.navigate(Routes.SETTINGS) },
                )
            }
            composable(Routes.NOW_PLAYING) {
                NowPlayingScreen(
                    container = container,
                    onBack = { navController.popBackStack() },
                    onOpenFolder = { navController.navigate("${Routes.FOLDERS}?path=${Uri.encode(it)}") },
                    onNavigate = { navController.navigate(it) },
                )
            }
            composable(Routes.EQUALIZER) { EqualizerScreen(container.sound) }
            composable(Routes.SEARCH) {
                SearchScreen(container) { navController.navigate(Routes.NOW_PLAYING) }
            }
            composable(Routes.LIBRARY) {
                LibraryHomeScreen(container) { id ->
                    when (id) {
                        "songs" -> navController.navigate("songs/all")
                        "folders" -> navController.navigate(Routes.FOLDERS_FLAT)
                        "hierarchy" -> navController.navigate(Routes.FOLDERS)
                        "albums" -> navController.navigate(Routes.ALBUMS)
                        "artists" -> navController.navigate(Routes.ARTISTS)
                        "years" -> navController.navigate(Routes.YEARS)
                        "queue" -> navController.navigate(Routes.QUEUE)
                        "toprated" -> navController.navigate("songs/top")
                        "lowrated" -> navController.navigate("songs/low")
                        "recentlyadded" -> navController.navigate("songs/recent")
                        "long" -> navController.navigate("songs/long")
                        "mostplayed" -> navController.navigate("songs/most")
                        "recentlyplayed" -> navController.navigate("songs/played")
                        "genres" -> navController.navigate("groups/genre")
                        "composers" -> navController.navigate("groups/composer")
                        "albumartists" -> navController.navigate("groups/albumartist")
                        "playlists" -> navController.navigate(Routes.PLAYLISTS)
                        "bookmarks" -> navController.navigate(Routes.BOOKMARKS)
                    }
                }
            }
            composable(
                Routes.SONGS_PATTERN,
                arguments = listOf(
                    navArgument("kind") { type = NavType.StringType },
                    navArgument("title") { type = NavType.StringType; defaultValue = "" },
                    navArgument("arg") { type = NavType.StringType; defaultValue = "" },
                ),
            ) { entry ->
                SongsKindScreen(
                    kind = entry.arguments?.getString("kind").orEmpty(),
                    titleOverride = entry.arguments?.getString("title").orEmpty(),
                    argOverride = entry.arguments?.getString("arg").orEmpty(),
                    container = container,
                    onUp = { navController.popBackStack() },
                    onSearch = { navigateTopLevel(navController, Routes.SEARCH) },
                    onOpenNowPlaying = { navController.navigate(Routes.NOW_PLAYING) },
                )
            }
            composable(Routes.ALBUMS) {
                AlbumsScreen(container, onUp = { navController.popBackStack() }) { g ->
                    navController.navigate("songs/album-${g.key}?title=${Uri.encode(g.title)}")
                }
            }
            composable(Routes.ARTISTS) {
                ArtistsScreen(container, onUp = { navController.popBackStack() }) { g ->
                    navController.navigate("songs/artist-${g.key}?title=${Uri.encode(g.title)}")
                }
            }
            composable(Routes.YEARS) {
                YearsScreen(container, onUp = { navController.popBackStack() }) { g ->
                    navController.navigate("songs/year-${g.key}?title=${Uri.encode(g.title)}")
                }
            }
            composable(Routes.FOLDERS_FLAT) {
                FoldersFlatScreen(container, onUp = { navController.popBackStack() }) { g ->
                    navController.navigate("${Routes.FOLDERS}?path=${Uri.encode(g.key)}")
                }
            }
            composable(Routes.QUEUE) {
                QueueScreen(container, onUp = { navController.popBackStack() })
            }
            composable(Routes.PLAYLISTS) {
                PlaylistsScreen(container, onUp = { navController.popBackStack() }) { p ->
                    navController.navigate("songs/playlist-${p.id}?title=${Uri.encode(p.name)}")
                }
            }
            composable(Routes.BOOKMARKS) {
                BookmarksScreen(
                    container, onUp = { navController.popBackStack() },
                    onOpenNowPlaying = { navController.navigate(Routes.NOW_PLAYING) },
                )
            }
            composable(
                Routes.GROUPS_PATTERN,
                arguments = listOf(navArgument("kind") { type = NavType.StringType }),
            ) { entry ->
                val kind = entry.arguments?.getString("kind").orEmpty()
                NameGroupsScreen(kind, container, onUp = { navController.popBackStack() }) { g ->
                    navController.navigate("songs/$kind?title=${Uri.encode(g.title)}&arg=${Uri.encode(g.key)}")
                }
            }
            composable(Routes.SETTINGS) {
                SettingsScreen(
                    onBack = { navController.popBackStack() },
                    onOpenGroup = { navController.navigate("${Routes.SETTINGS}/$it") },
                )
            }
            composable(
                Routes.SETTINGS_GROUP,
                arguments = listOf(navArgument("group") { type = NavType.StringType }),
            ) { entry ->
                SettingsDetailScreen(
                    groupId = entry.arguments?.getString("group").orEmpty(),
                    container = container,
                    onBack = { navController.popBackStack() },
                )
            }
        }
    }

    if (showMenu) {
        MenuSheet(
            onDismiss = { showMenu = false },
            onSettings = { showMenu = false; navController.navigate(Routes.SETTINGS) },
            onQueue = { showMenu = false; navController.navigate(Routes.QUEUE) },
        )
    }
}

private fun navigateTopLevel(navController: NavHostController, route: String) {
    navController.navigate(route) {
        popUpTo(navController.graph.findStartDestination().id) { saveState = true }
        launchSingleTop = true
        restoreState = true
    }
}

/** Rounded block at the bottom: the playing song on top, then four icons. */
@Composable
private fun Dock(
    state: PlayerUiState,
    showMiniPlayer: Boolean,
    currentRoute: String,
    onOpenPlayer: () -> Unit,
    onTogglePlay: () -> Unit,
    onSelect: (NavItem) -> Unit,
) {
    val shape = RoundedCornerShape(36.dp)
    Column(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 8.dp)
            .navigationBarsPadding()
            .padding(bottom = 8.dp)
            .clip(shape)
            .background(Color(0xFF1A1A1A)),
    ) {
        if (state.hasMedia && showMiniPlayer) {
            Column(
                Modifier.fillMaxWidth().background(Color(0xFF1F1F1F)).focusRing(shape)
                    .clickable(role = Role.Button, onClick = onOpenPlayer),
            ) {
                Row(
                    Modifier.fillMaxWidth().height(72.dp).padding(horizontal = ApmSpace.s4),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(ApmSpace.s3),
                ) {
                    TrackArt(
                        trackId = state.mediaId?.toLongOrNull() ?: 0L, uri = state.uri,
                        modifier = Modifier.size(48.dp), shape = ApmShape.sm, sizePx = 128,
                    )
                    Column(Modifier.weight(1f)) {
                        Text(
                            state.title, style = Apm.type.body.copy(fontWeight = FontWeight.Bold), color = Color.White,
                            maxLines = 1, overflow = TextOverflow.Ellipsis,
                        )
                        if (state.artist.isNotEmpty()) {
                            Text(
                                state.artist, style = Apm.type.bodySm.copy(fontWeight = FontWeight.SemiBold),
                                color = Color(0xFFB0B0B0), maxLines = 1, overflow = TextOverflow.Ellipsis,
                            )
                        }
                    }
                    IconButton(onClick = onTogglePlay) {
                        Icon(
                            if (state.isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                            contentDescription = if (state.isPlaying) "Pause" else "Play",
                            tint = Color.White, modifier = Modifier.size(36.dp),
                        )
                    }
                }
                val fraction = if (state.durationMs > 0) state.positionMs.toFloat() / state.durationMs else 0f
                Box(
                    Modifier.fillMaxWidth().padding(horizontal = ApmSpace.s4).padding(bottom = ApmSpace.s2)
                        .height(14.dp).clip(ApmShape.pill).background(Color(0xFF2A2A2A)),
                ) {
                    Box(
                        Modifier.fillMaxWidth(fraction.coerceIn(0.05f, 1f)).fillMaxHeight()
                            .clip(ApmShape.pill).background(Color(0xFF777777)),
                    )
                }
            }
        }
        Row(Modifier.fillMaxWidth().height(64.dp).selectableGroup()) {
            navItems.forEach { item ->
                val selected = when (item.route) {
                    MENU_ROUTE -> false
                    Routes.LIBRARY -> libraryPrefixes.any { currentRoute.startsWith(it) }
                    else -> currentRoute.startsWith(item.route)
                }
                Box(
                    Modifier.weight(1f).fillMaxHeight().focusRing(ApmShape.md)
                        .selectable(selected = selected, role = Role.Tab, onClick = { onSelect(item) }),
                    contentAlignment = Alignment.Center,
                ) {
                    Icon(
                        item.icon, contentDescription = item.label,
                        tint = if (selected) Color.White else Color(0xFF6E6E6E), modifier = Modifier.size(36.dp),
                    )
                }
            }
        }
    }
}

@Composable
private fun MenuSheet(onDismiss: () -> Unit, onSettings: () -> Unit, onQueue: () -> Unit) {
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Box(
            Modifier.fillMaxSize().clickable(
                interactionSource = remember { MutableInteractionSource() }, indication = null, onClick = onDismiss,
            ),
            contentAlignment = Alignment.BottomCenter,
        ) {
            Column(
                Modifier.fillMaxWidth().padding(8.dp).clip(RoundedCornerShape(36.dp)).background(Color(0xFF1B1B1B))
                    .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) {}
                    .padding(vertical = ApmSpace.s4),
            ) {
                Text(
                    "Apm Player Pro", style = Apm.type.title, color = Color.White,
                    modifier = Modifier.fillMaxWidth().padding(bottom = ApmSpace.s3),
                    textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                )
                MenuRow(Icons.Rounded.Settings, "Settings", onSettings)
                MenuRow(Icons.AutoMirrored.Rounded.QueueMusic, "Queue", onQueue)
            }
        }
    }
}

@Composable
private fun MenuRow(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().heightIn(min = 64.dp).focusRing(ApmShape.pill)
            .clickable(role = Role.Button, onClick = onClick).padding(horizontal = ApmSpace.s5),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(ApmSpace.s4),
    ) {
        Icon(icon, contentDescription = null, tint = Color.White, modifier = Modifier.size(28.dp))
        Text(label, style = Apm.type.title.copy(fontWeight = FontWeight.SemiBold), color = Color.White)
    }
}
