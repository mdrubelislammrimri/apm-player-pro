package app.apmplayer.ui

import androidx.compose.foundation.basicMarquee
import androidx.compose.animation.Crossfade
import androidx.compose.ui.graphics.Brush
import androidx.compose.foundation.layout.windowInsetsBottomHeight
import androidx.compose.foundation.layout.windowInsetsTopHeight
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.BoxScope
import app.apmplayer.ui.theme.n
import kotlinx.coroutines.flow.first
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeOut
import androidx.compose.animation.fadeIn
import androidx.compose.animation.ExitTransition
import androidx.compose.animation.EnterTransition
import app.apmplayer.ui.screens.GroupItem
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.horizontalScroll
import app.apmplayer.ui.screens.settingsGroups
import app.apmplayer.ui.components.LocalSettings
import app.apmplayer.ui.components.LocalArtLoader
import app.apmplayer.ui.components.TrackArt
import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.ui.draw.clip
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.selection.selectableGroup
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.QueueMusic
import androidx.compose.material.icons.rounded.Apps
import androidx.compose.material.icons.rounded.Menu
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.layout.Box
import androidx.compose.ui.text.font.FontWeight
import app.apmplayer.ui.screens.AlbumsScreen
import app.apmplayer.ui.screens.ArtistsScreen
import app.apmplayer.ui.screens.EqualizerScreen
import app.apmplayer.ui.screens.FoldersFlatScreen
import app.apmplayer.ui.screens.BookmarksScreen
import app.apmplayer.ui.screens.LibraryHomeScreen
import app.apmplayer.ui.screens.NameGroupsScreen
import app.apmplayer.ui.screens.PlaylistsScreen
import app.apmplayer.ui.screens.QueueScreen
import app.apmplayer.ui.screens.SongsKindScreen
import app.apmplayer.ui.screens.YearsScreen
import app.apmplayer.ui.screens.SearchScreen
import app.apmplayer.ui.screens.SettingsDetailScreen
import app.apmplayer.ui.screens.SettingsScreen
import androidx.compose.material.icons.rounded.Equalizer
import androidx.compose.material.icons.rounded.LibraryMusic
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Scaffold
import app.apmplayer.ui.components.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import app.apmplayer.AppContainer
import app.apmplayer.playback.PlayerUiState
import app.apmplayer.ui.components.GeneratedArt
import app.apmplayer.ui.components.PillButton
import app.apmplayer.ui.components.focusRing
import app.apmplayer.ui.screens.FoldersScreen
import app.apmplayer.ui.screens.NowPlayingScreen
import app.apmplayer.ui.screens.StubScreen
import app.apmplayer.ui.theme.Apm
import app.apmplayer.ui.theme.ApmLayout
import app.apmplayer.ui.theme.ApmShape
import app.apmplayer.ui.theme.ApmSpace

object Routes {
    const val FOLDERS = "folders"
    const val FOLDERS_PATTERN = "folders?path={path}"
    const val NOW_PLAYING = "now_playing"
    const val EQUALIZER = "equalizer"
    const val SOUND_KNOBS = "sound_knobs"
    const val ALBUMS = "albums"
    const val LIBRARY = "library"
    const val SEARCH = "search"
    const val QUEUE = "queue"
    const val SETTINGS = "settings"
    const val SETTINGS_GROUP = "settings/{group}"
    const val ARTISTS = "artists"
    const val YEARS = "years"
    const val FOLDERS_FLAT = "folders_flat"
    const val SONGS_PATTERN = "songs/{kind}?title={title}&arg={arg}"
    const val PLAYLISTS = "playlists"
    const val BOOKMARKS = "bookmarks"
    const val GROUPS_PATTERN = "groups/{kind}"
}

private data class NavItem(val route: String, val label: String, val icon: androidx.compose.ui.graphics.vector.ImageVector)

private const val MENU_ROUTE = "menu"

// Screens that belong to the library, so the Library icon stays lit on them.
private val libraryPrefixes = listOf("library", "folders", "songs", "albums", "artists", "years", "queue", "playlists", "bookmarks", "groups")

private val navItems = listOf(
    NavItem(Routes.LIBRARY, "Library", Icons.Rounded.Apps),
    NavItem(Routes.EQUALIZER, "Equalizer", Icons.Rounded.Equalizer),
    NavItem(Routes.SEARCH, "Search", Icons.Rounded.Search),
    NavItem(MENU_ROUTE, "Menu", Icons.Rounded.Menu),
)

@Composable
fun AppRoot(container: AppContainer) {
    val settings by container.settings.state.collectAsStateWithLifecycle()
    androidx.compose.runtime.CompositionLocalProvider(
        LocalArtLoader provides container.art,
        LocalSettings provides settings,
    ) {
        PermissionGate(container) { AppScaffold(container) }
    }
}

/** Asks for permission to read music (and to show the playback notification on Android 13+). */
@Composable
private fun PermissionGate(container: AppContainer, content: @Composable () -> Unit) {
    val context = LocalContext.current
    val audioPermission = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO
    else Manifest.permission.READ_EXTERNAL_STORAGE

    fun hasAudioAccess() =
        ContextCompat.checkSelfPermission(context, audioPermission) == PackageManager.PERMISSION_GRANTED

    var granted by remember { mutableStateOf(hasAudioAccess()) }
    var asked by rememberSaveable { mutableStateOf(false) }

    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        granted = hasAudioAccess()
        asked = true
    }
    val toRequest = if (Build.VERSION.SDK_INT >= 33) arrayOf(audioPermission, Manifest.permission.POST_NOTIFICATIONS)
    else arrayOf(audioPermission)

    // Coming back from the system settings page counts as a fresh check.
    val lifecycleOwner = LocalLifecycleOwner.current
    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) granted = hasAudioAccess()
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    LaunchedEffect(Unit) { if (!granted) launcher.launch(toRequest) }
    LaunchedEffect(granted) { if (granted) container.repository.startScan() }

    if (granted) {
        content()
    } else {
        Column(
            Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(ApmSpace.s5),
            verticalArrangement = Arrangement.spacedBy(ApmSpace.s3, Alignment.CenterVertically),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Text("Allow access to your music", style = Apm.type.title, color = Apm.colors.text, textAlign = TextAlign.Center)
            Text(
                "The player needs to see the audio files on this phone. Nothing leaves your device.",
                style = Apm.type.bodySm, color = Apm.colors.textMuted, textAlign = TextAlign.Center,
            )
            PillButton("Allow access", icon = null, filled = true) { launcher.launch(toRequest) }
            if (asked) {
                PillButton("Open phone settings", icon = null, filled = false) {
                    context.startActivity(
                        Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.fromParts("package", context.packageName, null))
                    )
                }
            }
        }
    }
}

@Composable
private fun AppScaffold(container: AppContainer) {
    val navController = rememberNavController()
    val backStack by navController.currentBackStackEntryAsState()
    val route = backStack?.destination?.route.orEmpty()
    val playerState by container.player.state.collectAsStateWithLifecycle()
    val onNowPlaying = route == Routes.NOW_PLAYING
    var showMenu by remember { mutableStateOf(false) }
    val fullScreenViz by container.fullScreenViz.collectAsStateWithLifecycle()
    val menuShortcuts = LocalSettings.current.menuShortcuts
    // a touch on the notification: the player, or the list the songs came from
    LaunchedEffect(Unit) {
        for (request in container.openRequests) {
            val src = container.playbackSource.value
            val route = if (container.settings.state.value.notifOpenList && src != null) container.routeFor(src) else Routes.NOW_PLAYING
            navController.navigate(route) { launchSingleTop = true }
        }
    }
    val animMs = when (LocalSettings.current.animations) { 0 -> 0; 1 -> 120; else -> 300 }
    // the app opens on the player screen: with the song that is playing, or the last queue brought back, paused.
    // "Resume On Start" then plays it. This happens once each time the app is started.
    LaunchedEffect(Unit) {
        if (container.startHandled) return@LaunchedEffect
        container.startHandled = true
        val s = container.settings.state.value
        if (s.startAtPlayer || s.resumeOnStart) {
            val playing = kotlinx.coroutines.withTimeoutOrNull(900) { container.player.state.first { it.hasMedia } }
            val has = playing != null || container.restoreLastQueue(s.waitForStorage)
            if (has && s.startAtPlayer) navController.navigate(Routes.NOW_PLAYING) { launchSingleTop = true }
            if (has && s.resumeOnStart && !container.player.state.value.isPlaying) container.player.resume()
        }
    }

    Box(Modifier.fillMaxSize()) {
    Scaffold(
        containerColor = Apm.colors.bg,
        bottomBar = {
            if (!fullScreenViz && !route.startsWith(Routes.SETTINGS)) Dock(
                state = playerState,
                showMiniPlayer = !onNowPlaying,
                currentRoute = route,
                onOpenPlayer = { navController.navigate(Routes.NOW_PLAYING) },
                onTogglePlay = { container.player.togglePlayPause() },
                onNext = { container.player.next() },
                onPrevious = { container.player.previous() },
                onSelect = { item ->
                    if (item.route == MENU_ROUTE) showMenu = true else navigateTopLevel(navController, item.route)
                },
            )
        },
    ) { padding ->
        NavHost(
            navController = navController,
            startDestination = Routes.LIBRARY,
            modifier = Modifier.padding(padding),
            // the speed of screen changes is a setting, Disabled changes screens at once
            enterTransition = { if (animMs == 0) EnterTransition.None else fadeIn(tween(animMs)) },
            exitTransition = { if (animMs == 0) ExitTransition.None else fadeOut(tween(animMs)) },
            popEnterTransition = { if (animMs == 0) EnterTransition.None else fadeIn(tween(animMs)) },
            popExitTransition = { if (animMs == 0) ExitTransition.None else fadeOut(tween(animMs)) },
        ) {
            composable(
                Routes.FOLDERS_PATTERN,
                arguments = listOf(navArgument("path") { type = NavType.StringType; defaultValue = "" }),
            ) { entry ->
                val path = entry.arguments?.getString("path").orEmpty()
                FoldersScreen(
                    path = path,
                    container = container,
                    onOpenFolder = { navController.navigate("${Routes.FOLDERS}?path=${Uri.encode(it)}") },
                    onUp = { navController.popBackStack() },
                    onOpenNowPlaying = { navController.navigate(Routes.NOW_PLAYING) },
                    onOpenSettings = { navController.navigate(Routes.SETTINGS) },
                )
            }
            composable(Routes.NOW_PLAYING) {
                NowPlayingScreen(
                    container = container,
                    onBack = { navController.popBackStack() },
                    onOpenFolder = { navController.navigate("${Routes.FOLDERS}?path=${Uri.encode(it)}") },
                    onNavigate = { navController.navigate(it) },
                )
            }
            composable(Routes.EQUALIZER) { EqualizerScreen(container.sound) }
            composable(Routes.SEARCH) {
                SearchScreen(
                    container,
                    onOpenNowPlaying = { navController.navigate(Routes.NOW_PLAYING) },
                    onNavigate = { navController.navigate(it) },
                )
            }
            composable(Routes.LIBRARY) {
                LibraryHomeScreen(container) { id ->
                    when (id) {
                        "songs" -> navController.navigate("songs/all")
                        "folders" -> navController.navigate(Routes.FOLDERS_FLAT)
                        "hierarchy" -> navController.navigate(Routes.FOLDERS)
                        "albums" -> navController.navigate(Routes.ALBUMS)
                        "artists" -> navController.navigate(Routes.ARTISTS)
                        "years" -> navController.navigate(Routes.YEARS)
                        "queue" -> navController.navigate(Routes.QUEUE)
                        "toprated" -> navController.navigate("songs/top")
                        "lowrated" -> navController.navigate("songs/low")
                        "recentlyadded" -> navController.navigate("songs/recent")
                        "long" -> navController.navigate("songs/long")
                        "mostplayed" -> navController.navigate("songs/most")
                        "recentlyplayed" -> navController.navigate("songs/played")
                        "genres" -> navController.navigate("groups/genre")
                        "composers" -> navController.navigate("groups/composer")
                        "albumartists" -> navController.navigate("groups/albumartist")
                        "playlists" -> navController.navigate(Routes.PLAYLISTS)
                        "bookmarks" -> navController.navigate(Routes.BOOKMARKS)
                    }
                }
            }
            composable(
                Routes.SONGS_PATTERN,
                arguments = listOf(
                    navArgument("kind") { type = NavType.StringType },
                    navArgument("title") { type = NavType.StringType; defaultValue = "" },
                    navArgument("arg") { type = NavType.StringType; defaultValue = "" },
                ),
            ) { entry ->
                SongsKindScreen(
                    kind = entry.arguments?.getString("kind").orEmpty(),
                    titleOverride = entry.arguments?.getString("title").orEmpty(),
                    argOverride = entry.arguments?.getString("arg").orEmpty(),
                    container = container,
                    onUp = { navController.popBackStack() },
                    onSearch = { navigateTopLevel(navController, Routes.SEARCH) },
                    onOpenNowPlaying = { navController.navigate(Routes.NOW_PLAYING) },
                )
            }
            composable(Routes.ALBUMS) {
                AlbumsScreen(container, onUp = { navController.popBackStack() }) { g ->
                    navController.navigate("songs/album-${g.key}?title=${Uri.encode(g.title)}")
                }
            }
            composable(Routes.ARTISTS) {
                ArtistsScreen(container, onUp = { navController.popBackStack() }) { g ->
                    navController.navigate("songs/artist-${g.key}?title=${Uri.encode(g.title)}")
                }
            }
            composable(Routes.YEARS) {
                YearsScreen(container, onUp = { navController.popBackStack() }) { g ->
                    navController.navigate("songs/year-${g.key}?title=${Uri.encode(g.title)}")
                }
            }
            composable(Routes.FOLDERS_FLAT) {
                FoldersFlatScreen(container, onUp = { navController.popBackStack() }) { g ->
                    navController.navigate("${Routes.FOLDERS}?path=${Uri.encode(g.key)}")
                }
            }
            composable(Routes.QUEUE) {
                QueueScreen(container, onUp = { navController.popBackStack() })
            }
            composable(Routes.PLAYLISTS) {
                PlaylistsScreen(container, onUp = { navController.popBackStack() }) { p ->
                    navController.navigate("songs/playlist-${p.id}?title=${Uri.encode(p.name)}")
                }
            }
            composable(Routes.BOOKMARKS) {
                BookmarksScreen(
                    container, onUp = { navController.popBackStack() },
                    onOpenNowPlaying = { navController.navigate(Routes.NOW_PLAYING) },
                )
            }
            composable(
                Routes.GROUPS_PATTERN,
                arguments = listOf(navArgument("kind") { type = NavType.StringType }),
            ) { entry ->
                val kind = entry.arguments?.getString("kind").orEmpty()
                NameGroupsScreen(kind, container, onUp = { navController.popBackStack() }) { g ->
                    navController.navigate("songs/$kind?title=${Uri.encode(g.title)}&arg=${Uri.encode(g.key)}")
                }
            }
            composable(Routes.SETTINGS) {
                SettingsScreen(
                    container = container,
                    onBack = { navController.popBackStack() },
                    onOpenGroup = { navController.navigate("${Routes.SETTINGS}/$it") },
                )
            }
            composable(
                Routes.SETTINGS_GROUP,
                arguments = listOf(navArgument("group") { type = NavType.StringType }),
            ) { entry ->
                SettingsDetailScreen(
                    groupId = entry.arguments?.getString("group").orEmpty(),
                    container = container,
                    onBack = { navController.popBackStack() },
                    onOpen = { navController.navigate("${Routes.SETTINGS}/$it") },
                    // the X closes the settings completely, back to where they were opened from
                    onClose = {
                        while (navController.currentBackStackEntry?.destination?.route?.startsWith(Routes.SETTINGS) == true && navController.popBackStack()) {
                            // keep going back while a settings screen is on top
                        }
                    },
                )
            }
        }
    }
        BarScrims(onPlayer = onNowPlaying)
    }

    if (showMenu) {
        MenuSheet(
            onDismiss = { showMenu = false },
            onSettings = { showMenu = false; navController.navigate(Routes.SETTINGS) },
            onQueue = { showMenu = false; navController.navigate(Routes.QUEUE) },
            shortcuts = settingsGroups.takeLast(5).take(menuShortcuts).map { it.id to it.title },
            onShortcut = { showMenu = false; navController.navigate("${Routes.SETTINGS}/$it") },
        )
    }
}

private fun navigateTopLevel(navController: NavHostController, route: String) {
    navController.navigate(route) {
        popUpTo(navController.graph.findStartDestination().id) { saveState = true }
        launchSingleTop = true
        restoreState = true
    }
}

/** Rounded block at the bottom: the playing song on top, then four icons. */
@Composable
@OptIn(androidx.compose.foundation.ExperimentalFoundationApi::class)
private fun Dock(
    state: PlayerUiState,
    showMiniPlayer: Boolean,
    currentRoute: String,
    onOpenPlayer: () -> Unit,
    onTogglePlay: () -> Unit,
    onNext: () -> Unit,
    onPrevious: () -> Unit,
    onSelect: (NavItem) -> Unit,
) {
    val shape = RoundedCornerShape(36.dp)
    Column(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = if (LocalSettings.current.offsetNavbar) 24.dp else 8.dp)
            .navigationBarsPadding()
            .padding(bottom = 8.dp)
            .clip(shape)
            .background(n(Color(0xFF1A1A1A))),
    ) {
        if (state.hasMedia && showMiniPlayer) {
            Column(
                Modifier.fillMaxWidth().background(n(Color(0xFF1F1F1F))).focusRing(shape)
                    .pointerInput(Unit) {
                        // swipe the playing song sideways to change songs
                        var dx = 0f
                        detectHorizontalDragGestures(
                            onDragStart = { dx = 0f },
                            onDragEnd = { if (dx < -120f) onNext() else if (dx > 120f) onPrevious() },
                            onDragCancel = {},
                        ) { change, amount -> change.consume(); dx += amount }
                    }
                    .clickable(role = Role.Button, onClick = onOpenPlayer),
            ) {
                Row(
                    Modifier.fillMaxWidth().height(72.dp).padding(horizontal = ApmSpace.s4),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(ApmSpace.s3),
                ) {
                    // the small cover fades when the song changes (Player Screen: Album Art Animation)
                    Crossfade(targetState = state.mediaId, animationSpec = tween(if (LocalSettings.current.albumArtAnim) 300 else 0), label = "miniCover") { mediaId ->
                        TrackArt(
                            trackId = mediaId?.toLongOrNull() ?: 0L, uri = state.uri,
                            modifier = Modifier.size(48.dp), shape = ApmShape.sm, sizePx = 128,
                        )
                    }
                    Column(Modifier.weight(1f)) {
                        Text(
                            state.title, style = Apm.type.body.copy(fontWeight = FontWeight.Bold), color = n(Color.White),
                            maxLines = 1, softWrap = !LocalSettings.current.animateLabelsEverywhere,
                            overflow = if (LocalSettings.current.animateLabelsEverywhere) TextOverflow.Clip else TextOverflow.Ellipsis,
                            modifier = if (LocalSettings.current.animateLabelsEverywhere) Modifier.basicMarquee() else Modifier,
                        )
                        if (state.artist.isNotEmpty()) {
                            Text(
                                state.artist, style = Apm.type.bodySm.copy(fontWeight = FontWeight.SemiBold),
                                color = n(Color(0xFFB0B0B0)), maxLines = 1, overflow = TextOverflow.Ellipsis,
                            )
                        }
                    }
                    IconButton(onClick = onTogglePlay) {
                        Icon(
                            if (state.isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                            contentDescription = if (state.isPlaying) "Pause" else "Play",
                            tint = n(Color.White), modifier = Modifier.size(36.dp),
                        )
                    }
                }
                val fraction = if (state.durationMs > 0) state.positionMs.toFloat() / state.durationMs else 0f
                Box(
                    Modifier.fillMaxWidth().padding(horizontal = ApmSpace.s4).padding(bottom = ApmSpace.s2)
                        .height(14.dp).clip(ApmShape.pill).background(n(Color(0xFF2A2A2A))),
                ) {
                    Box(
                        Modifier.fillMaxWidth(fraction.coerceIn(0.05f, 1f)).fillMaxHeight()
                            .clip(ApmShape.pill).background(n(Color(0xFF777777))),
                    )
                }
            }
        }
        Row(Modifier.fillMaxWidth().height(64.dp).selectableGroup()) {
            navItems.forEach { item ->
                val selected = when (item.route) {
                    MENU_ROUTE -> false
                    Routes.LIBRARY -> libraryPrefixes.any { currentRoute.startsWith(it) }
                    else -> currentRoute.startsWith(item.route)
                }
                Box(
                    Modifier.weight(1f).fillMaxHeight().focusRing(ApmShape.md)
                        .selectable(selected = selected, role = Role.Tab, onClick = { onSelect(item) }),
                    contentAlignment = Alignment.Center,
                ) {
                    Icon(
                        item.icon, contentDescription = item.label,
                        tint = if (selected) n(Color.White) else n(Color(0xFF6E6E6E)), modifier = Modifier.size(36.dp),
                    )
                }
            }
        }
    }
}

@Composable
private fun MenuSheet(
    onDismiss: () -> Unit,
    onSettings: () -> Unit,
    onQueue: () -> Unit,
    shortcuts: List<Pair<String, String>>,
    onShortcut: (String) -> Unit,
) {
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Box(
            Modifier.fillMaxSize().clickable(
                interactionSource = remember { MutableInteractionSource() }, indication = null, onClick = onDismiss,
            ),
            contentAlignment = Alignment.BottomCenter,
        ) {
            Column(
                Modifier.fillMaxWidth().padding(8.dp).clip(RoundedCornerShape(36.dp)).background(n(Color(0xFF1B1B1B)))
                    .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) {}
                    .padding(vertical = ApmSpace.s4),
            ) {
                Text(
                    "Apm Player Pro", style = Apm.type.title, color = n(Color.White),
                    modifier = Modifier.fillMaxWidth().padding(bottom = ApmSpace.s3),
                    textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                )
                MenuRow(Icons.Rounded.Settings, "Settings", onSettings)
                if (shortcuts.isNotEmpty()) {
                    // quick doors into the settings pages, how many is a setting
                    Row(
                        Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = ApmSpace.s5, vertical = ApmSpace.s1),
                        horizontalArrangement = Arrangement.spacedBy(ApmSpace.s2),
                    ) {
                        shortcuts.forEach { (id, label) ->
                            Box(
                                Modifier.heightIn(min = 40.dp).clip(ApmShape.pill).background(n(Color(0xFF2E2E2E)))
                                    .focusRing(ApmShape.pill).clickable(role = Role.Button) { onShortcut(id) }
                                    .padding(horizontal = ApmSpace.s4),
                                contentAlignment = Alignment.Center,
                            ) { Text(label, style = Apm.type.bodySm.copy(fontWeight = FontWeight.Bold), color = n(Color.White)) }
                        }
                    }
                }
                MenuRow(Icons.AutoMirrored.Rounded.QueueMusic, "Queue", onQueue)
            }
        }
    }
}

@Composable
private fun MenuRow(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().heightIn(min = 64.dp).focusRing(ApmShape.pill)
            .clickable(role = Role.Button, onClick = onClick).padding(horizontal = ApmSpace.s5),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(ApmSpace.s4),
    ) {
        Icon(icon, contentDescription = null, tint = n(Color.White), modifier = Modifier.size(28.dp))
        Text(label, style = Apm.type.title.copy(fontWeight = FontWeight.SemiBold), color = n(Color.White))
    }
}


/**
 * Soft dark bands behind the system bars so their icons can be read over any picture.
 * Skin settings: Transparent Status Bar, Transparent Navbar (player screen) and Android Navigation Bar (other screens).
 */
@Composable
private fun BoxScope.BarScrims(onPlayer: Boolean) {
    val s = LocalSettings.current
    if (s.statusScrim) {
        Box(
            Modifier.align(Alignment.TopCenter).fillMaxWidth().windowInsetsTopHeight(WindowInsets.statusBars)
                .background(Brush.verticalGradient(listOf(n(Color.Black).copy(alpha = 0.55f), Color.Transparent))),
        )
    }
    val alpha = if (onPlayer) {
        when (s.navbarPlayer) { 1 -> 0.45f; 2 -> 0f; else -> 0.85f }
    } else {
        if (s.navbarOther == 1) 0f else 0.5f
    }
    if (alpha > 0f) {
        Box(
            Modifier.align(Alignment.BottomCenter).fillMaxWidth().windowInsetsBottomHeight(WindowInsets.navigationBars)
                .background(n(Color.Black).copy(alpha = alpha)),
        )
    }
}
