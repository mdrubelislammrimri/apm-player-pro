package app.apmplayer.ui.screens

import app.apmplayer.lyrics.openLyricsSearch
import app.apmplayer.lyrics.lyricsCharset
import app.apmplayer.lyrics.LrcFolder
import app.apmplayer.data.TrackDetail
import kotlin.math.abs
import kotlinx.coroutines.delay
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import app.apmplayer.ui.theme.n
import app.apmplayer.ui.components.LocalSettings
import androidx.compose.ui.platform.LocalView
import androidx.compose.runtime.DisposableEffect
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import app.apmplayer.ui.components.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import app.apmplayer.AppContainer
import app.apmplayer.ui.components.OutlinePill
import app.apmplayer.ui.theme.Apm
import app.apmplayer.ui.theme.ApmSpace
import app.apmplayer.util.ParsedLyrics
import app.apmplayer.util.currentLyricIndex
import app.apmplayer.util.parseLyrics
import kotlinx.coroutines.launch

/**
 * Lyrics over the player. With a .lrc file (lines with times) the line being sung is lit and the list follows the music,
 * and a tap on a line jumps there. Plain text is just shown. Lyrics are added from a file or by pasting, and kept per song.
 */
@Composable
fun LyricsOverlay(
    trackId: Long,
    title: String,
    detail: TrackDetail?,
    positionMs: Long,
    container: AppContainer,
    onSeek: (Long) -> Unit,
    onClose: () -> Unit,
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var text by remember(trackId) { mutableStateOf<String?>(null) }
    var loaded by remember(trackId) { mutableStateOf(false) }
    var busy by remember(trackId) { mutableStateOf(false) }
    var menu by remember { mutableStateOf(false) }
    var paste by remember { mutableStateOf(false) }
    val listState = rememberLazyListState()
    val settings = LocalSettings.current
    var zoom by remember { mutableFloatStateOf(settings.lyricsZoom) }
    val view = LocalView.current

    // keep the screen on while the lyrics are open, if asked
    DisposableEffect(settings.lyricsKeepOn) {
        val before = view.keepScreenOn
        if (settings.lyricsKeepOn) view.keepScreenOn = true
        onDispose { view.keepScreenOn = before }
    }
    // a pinch changes the size, it is kept a moment after the fingers leave
    LaunchedEffect(zoom) {
        delay(600)
        if (zoom != settings.lyricsZoom) container.settings.update { it.copy(lyricsZoom = zoom) }
    }
    BackHandler(onBack = onClose)

    fun searchOnline(manual: Boolean) {
        val t = detail?.track ?: return
        scope.launch {
            busy = true
            val found = container.lyricsTools.online(trackId, detail?.artistName, t.title, detail?.albumTitle, t.durationMs)
            busy = false
            if (found != null) text = container.lyrics.get(trackId)
            else if (manual) Toast.makeText(context, "No lyrics found online for this song", Toast.LENGTH_LONG).show()
        }
    }

    LaunchedEffect(trackId) {
        val uri = detail?.track?.uri
        text = if (uri != null) container.lyricsTools.local(trackId, uri) else container.lyrics.get(trackId)
        loaded = true
        if (text == null && container.lyricsTools.canAutoDownload()) searchOnline(manual = false)
    }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            val s = settings
            val read = LrcFolder.readText(context, uri, s.lyricsUtf8, lyricsCharset(s.lyricsCharset))
            if (read.isNullOrBlank()) {
                Toast.makeText(context, "Could not read that file", Toast.LENGTH_SHORT).show()
            } else {
                scope.launch {
                    container.lyrics.save(trackId, read)
                    text = container.lyrics.get(trackId)
                }
            }
        }
    }

    val parsed: ParsedLyrics? = remember(text) { text?.let { parseLyrics(it) } }
    // a positive offset makes the words come earlier
    val current = if (parsed != null && parsed.synced) currentLyricIndex(parsed.lines, positionMs + settings.lyricsOffsetMs) else -1
    LaunchedEffect(current) {
        if (current >= 0 && settings.lyricsAutoScroll) listState.animateScrollToItem((current - 2).coerceAtLeast(0))
    }

    Box(
        Modifier
            .fillMaxSize()
            .background(n(Color.Black).copy(alpha = 0.9f))
            // pinch to change the size
            .pointerInput(Unit) {
                detectTransformGestures { _, _, factor, _ -> zoom = (zoom * factor).coerceIn(0.6f, 2.5f) }
            }
            // swipe to the side to go back to the player
            .pointerInput(Unit) {
                var dx = 0f
                detectHorizontalDragGestures(
                    onDragStart = { dx = 0f },
                    onDragEnd = { if (abs(dx) > 220f) onClose() },
                    onDragCancel = {},
                ) { _, amount -> dx += amount }
            },
    ) {
        Column(Modifier.fillMaxSize().padding(horizontal = ApmSpace.s4)) {
            Row(Modifier.fillMaxWidth().height(64.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Lyrics", style = Apm.type.title, color = n(Color.White))
                    Text(title, style = Apm.type.caption, color = n(Color(0xFFB0B0B0)), maxLines = 1)
                }
                Box {
                    IconButton(onClick = { menu = true }) {
                        Icon(Icons.Rounded.MoreVert, contentDescription = "Lyrics options", tint = n(Color.White))
                    }
                    DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                        DropdownMenuItem(text = { Text("Search online") }, onClick = { menu = false; searchOnline(manual = true) })
                        DropdownMenuItem(
                            text = { Text("Search in a browser or app") },
                            onClick = { menu = false; openLyricsSearch(context, settings, detail?.artistName, title) },
                        )
                        DropdownMenuItem(
                            text = { Text("Load from a file (.lrc or .txt)") },
                            onClick = { menu = false; picker.launch(arrayOf("*/*")) },
                        )
                        DropdownMenuItem(text = { Text("Paste text") }, onClick = { menu = false; paste = true })
                        if (text != null) {
                            DropdownMenuItem(
                                text = { Text("Remove lyrics") },
                                onClick = {
                                    menu = false
                                    scope.launch {
                                        container.lyrics.delete(trackId)
                                        text = null
                                    }
                                },
                            )
                        }
                    }
                }
                IconButton(onClick = onClose) {
                    Icon(Icons.Rounded.Close, contentDescription = "Close lyrics", tint = n(Color.White))
                }
            }

            when {
                !loaded || busy -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    if (busy) Text("Looking for lyrics...", style = Apm.type.body, color = n(Color(0xFFB0B0B0)))
                }
                parsed == null || parsed.lines.isEmpty() -> Column(
                    Modifier.fillMaxSize(),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(ApmSpace.s3, Alignment.CenterVertically),
                ) {
                    Text("No lyrics for this song yet", style = Apm.type.title, color = n(Color.White), textAlign = TextAlign.Center)
                    Text(
                        "Search online, load a .lrc file to see the words move with the music, or paste the text.",
                        style = Apm.type.bodySm, color = n(Color(0xFFB0B0B0)), textAlign = TextAlign.Center,
                    )
                    OutlinePill("Search online", { searchOnline(manual = true) })
                    OutlinePill("Search in a browser or app", { openLyricsSearch(context, settings, detail?.artistName, title) })
                    OutlinePill("Load from a file", { picker.launch(arrayOf("*/*")) })
                    OutlinePill("Paste text", { paste = true })
                }
                else -> LazyColumn(Modifier.fillMaxSize(), state = listState) {
                    itemsIndexed(parsed.lines) { index, line ->
                        val lit = index == current
                        Text(
                            line.text.ifEmpty { " " },
                            style = (if (lit) Apm.type.title else Apm.type.body).let { base ->
                                base.copy(
                                    fontWeight = if (lit) FontWeight.Bold else FontWeight.Medium,
                                    fontSize = base.fontSize * zoom,
                                    lineHeight = base.lineHeight * zoom,
                                )
                            },
                            color = if (lit) n(Color.White) else n(Color(0xFF8A8A8A)),
                            textAlign = TextAlign.Center,
                            modifier = Modifier
                                .fillMaxWidth()
                                .then(if (parsed.synced) Modifier.clickable(role = Role.Button) { onSeek(line.timeMs) } else Modifier)
                                .padding(vertical = ApmSpace.s2),
                        )
                    }
                }
            }
        }
    }

    if (paste) {
        var draft by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { paste = false },
            title = { Text("Paste lyrics") },
            text = {
                OutlinedTextField(
                    value = draft, onValueChange = { draft = it }, minLines = 6, maxLines = 12,
                    label = { Text("Words, or lines like [01:23.45]words") },
                )
            },
            confirmButton = {
                TextButton(
                    enabled = draft.isNotBlank(),
                    onClick = {
                        scope.launch {
                            container.lyrics.save(trackId, draft)
                            text = container.lyrics.get(trackId)
                        }
                        paste = false
                    },
                ) { Text("Save") }
            },
            dismissButton = { TextButton(onClick = { paste = false }) { Text("Cancel") } },
        )
    }
}
