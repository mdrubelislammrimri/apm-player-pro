package app.apmplayer.ui.screens

import app.apmplayer.ui.components.LocalSettings
import androidx.compose.ui.platform.LocalView
import androidx.compose.runtime.DisposableEffect
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import app.apmplayer.ui.components.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import app.apmplayer.AppContainer
import app.apmplayer.ui.components.OutlinePill
import app.apmplayer.ui.theme.Apm
import app.apmplayer.ui.theme.ApmSpace
import app.apmplayer.util.ParsedLyrics
import app.apmplayer.util.currentLyricIndex
import app.apmplayer.util.parseLyrics
import kotlinx.coroutines.launch

/**
 * Lyrics over the player. With a .lrc file (lines with times) the line being sung is lit and the list follows the music,
 * and a tap on a line jumps there. Plain text is just shown. Lyrics are added from a file or by pasting, and kept per song.
 */
@Composable
fun LyricsOverlay(
    trackId: Long,
    title: String,
    positionMs: Long,
    container: AppContainer,
    onSeek: (Long) -> Unit,
    onClose: () -> Unit,
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var text by remember(trackId) { mutableStateOf<String?>(null) }
    var loaded by remember(trackId) { mutableStateOf(false) }
    var menu by remember { mutableStateOf(false) }
    var paste by remember { mutableStateOf(false) }
    val listState = rememberLazyListState()
    val settings = LocalSettings.current
    val scale = when (settings.lyricsSize) { 0 -> 0.85f; 2 -> 1.2f; 3 -> 1.4f; else -> 1f }
    val view = LocalView.current

    // keep the screen on while the lyrics are open, if asked
    DisposableEffect(settings.lyricsKeepOn) {
        val before = view.keepScreenOn
        if (settings.lyricsKeepOn) view.keepScreenOn = true
        onDispose { view.keepScreenOn = before }
    }
    BackHandler(onBack = onClose)
    LaunchedEffect(trackId) {
        text = container.lyrics.get(trackId)
        loaded = true
    }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            val read = try {
                context.contentResolver.openInputStream(uri)?.use { it.readBytes().toString(Charsets.UTF_8) }
            } catch (e: Exception) {
                null
            }
            if (read.isNullOrBlank()) {
                Toast.makeText(context, "Could not read that file", Toast.LENGTH_SHORT).show()
            } else {
                scope.launch {
                    container.lyrics.save(trackId, read)
                    text = container.lyrics.get(trackId)
                }
            }
        }
    }

    val parsed: ParsedLyrics? = remember(text) { text?.let { parseLyrics(it) } }
    val current = if (parsed != null && parsed.synced) currentLyricIndex(parsed.lines, positionMs) else -1
    LaunchedEffect(current) {
        if (current >= 0 && settings.lyricsAutoScroll) listState.animateScrollToItem((current - 2).coerceAtLeast(0))
    }

    Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.9f))) {
        Column(Modifier.fillMaxSize().padding(horizontal = ApmSpace.s4)) {
            Row(Modifier.fillMaxWidth().height(64.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Lyrics", style = Apm.type.title, color = Color.White)
                    Text(title, style = Apm.type.caption, color = Color(0xFFB0B0B0), maxLines = 1)
                }
                Box {
                    IconButton(onClick = { menu = true }) {
                        Icon(Icons.Rounded.MoreVert, contentDescription = "Lyrics options", tint = Color.White)
                    }
                    DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                        DropdownMenuItem(
                            text = { Text("Load from a file (.lrc or .txt)") },
                            onClick = { menu = false; picker.launch(arrayOf("*/*")) },
                        )
                        DropdownMenuItem(text = { Text("Paste text") }, onClick = { menu = false; paste = true })
                        if (text != null) {
                            DropdownMenuItem(
                                text = { Text("Remove lyrics") },
                                onClick = {
                                    menu = false
                                    scope.launch {
                                        container.lyrics.delete(trackId)
                                        text = null
                                    }
                                },
                            )
                        }
                    }
                }
                IconButton(onClick = onClose) {
                    Icon(Icons.Rounded.Close, contentDescription = "Close lyrics", tint = Color.White)
                }
            }

            when {
                !loaded -> Unit
                parsed == null || parsed.lines.isEmpty() -> Column(
                    Modifier.fillMaxSize(),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(ApmSpace.s3, Alignment.CenterVertically),
                ) {
                    Text("No lyrics for this song yet", style = Apm.type.title, color = Color.White, textAlign = TextAlign.Center)
                    Text(
                        "Load a .lrc file to see the words move with the music, or paste the text. The app has no internet, so it cannot look them up.",
                        style = Apm.type.bodySm, color = Color(0xFFB0B0B0), textAlign = TextAlign.Center,
                    )
                    OutlinePill("Load from a file", { picker.launch(arrayOf("*/*")) })
                    OutlinePill("Paste text", { paste = true })
                }
                else -> LazyColumn(Modifier.fillMaxSize(), state = listState) {
                    itemsIndexed(parsed.lines) { index, line ->
                        val lit = index == current
                        Text(
                            line.text.ifEmpty { " " },
                            style = (if (lit) Apm.type.title else Apm.type.body).let { base ->
                                base.copy(
                                    fontWeight = if (lit) FontWeight.Bold else FontWeight.Medium,
                                    fontSize = base.fontSize * scale,
                                    lineHeight = base.lineHeight * scale,
                                )
                            },
                            color = if (lit) Color.White else Color(0xFF8A8A8A),
                            textAlign = TextAlign.Center,
                            modifier = Modifier
                                .fillMaxWidth()
                                .then(if (parsed.synced) Modifier.clickable(role = Role.Button) { onSeek(line.timeMs) } else Modifier)
                                .padding(vertical = ApmSpace.s2),
                        )
                    }
                }
            }
        }
    }

    if (paste) {
        var draft by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { paste = false },
            title = { Text("Paste lyrics") },
            text = {
                OutlinedTextField(
                    value = draft, onValueChange = { draft = it }, minLines = 6, maxLines = 12,
                    label = { Text("Words, or lines like [01:23.45]words") },
                )
            },
            confirmButton = {
                TextButton(
                    enabled = draft.isNotBlank(),
                    onClick = {
                        scope.launch {
                            container.lyrics.save(trackId, draft)
                            text = container.lyrics.get(trackId)
                        }
                        paste = false
                    },
                ) { Text("Save") }
            },
            dismissButton = { TextButton(onClick = { paste = false }) { Text("Cancel") } },
        )
    }
}
