package app.apmplayer.ui.screens

import android.content.Context
import android.media.AudioManager
import android.widget.Toast
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.pm.PackageInfoCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import app.apmplayer.AppContainer
import app.apmplayer.audio.MODE_PARAMETRIC
import app.apmplayer.settings.Settings
import app.apmplayer.ui.components.SettingAction
import app.apmplayer.ui.components.SettingChoices
import app.apmplayer.ui.components.SettingNote
import app.apmplayer.ui.components.SettingSection
import app.apmplayer.ui.components.SettingSlider
import app.apmplayer.ui.components.SettingSwitch
import app.apmplayer.ui.components.VisualizerNames
import app.apmplayer.ui.theme.Apm
import app.apmplayer.ui.theme.ApmSpace
import java.util.Locale
import kotlin.math.roundToInt

/** The inside of one settings group. Every switch and slider here changes how the app really behaves. */
@Composable
fun SettingsPageContent(groupId: String, container: AppContainer, s: Settings, onOpen: (String) -> Unit) {
    when (groupId) {
        "look" -> LookPage(container, s)
        "audio" -> AudioPage(container, s, onOpen)
        "visualization" -> VisualizationPage(container, s)
        "background" -> BackgroundPage(container, s)
        "albumart" -> AlbumArtPage(container, s)
        "library" -> LibraryPage(container, s, onOpen)
        "headset" -> HeadsetPage(container, s)
        "lock" -> LockPage(container, s)
        "misc" -> MiscPage(container)
        "about" -> AboutPage()
        "audioinfo" -> AudioInfoPage(container)
        "musicfolders" -> MusicFoldersPage(container, s)
    }
}

private fun AppContainer.change(change: (Settings) -> Settings) = settings.update(change)

@Composable
private fun LookPage(c: AppContainer, s: Settings) {
    SettingChoices("Screen orientation", null, listOf("Default", "Portrait", "Landscape"), s.orientation) { i ->
        c.change { it.copy(orientation = i) }
    }
    SettingSwitch("Hide status bar", "Hide the clock and icons at the top. Swipe down from the top edge to see them.", s.hideStatusBar) { v ->
        c.change { it.copy(hideStatusBar = v) }
    }
    SettingSwitch("Keep screen on", "Never let the screen turn off while the app is open", s.keepScreenOn) { v ->
        c.change { it.copy(keepScreenOn = v) }
    }
    SettingChoices("Rating buttons on the player", "The like and dislike buttons under the cover", listOf("Thumbs", "Hidden"), if (s.showRating) 0 else 1) { i ->
        c.change { it.copy(showRating = i == 0) }
    }
    SettingSwitch("Waveform seek bar", "Draw the song as bars on the seek bar. Off gives a plain slider.", s.waveformSeek) { v ->
        c.change { it.copy(waveformSeek = v) }
    }
    SettingSlider(
        "Shortcuts in the main menu", "How many settings shortcuts the menu shows", s.menuShortcuts.toString(),
        s.menuShortcuts.toFloat(), 0f..5f, steps = 4,
        onChange = { v -> c.change { it.copy(menuShortcuts = v.roundToInt()) } },
    )
    SettingNote("The light theme, fonts and language are not built. The app is always dark.")
}

@Composable
private fun AudioPage(c: AppContainer, s: Settings, onOpen: (String) -> Unit) {
    var confirm by remember { mutableStateOf(false) }
    SettingAction("Audio Info", "Details about the sound that is playing and what happens to it") { onOpen("audioinfo") }
    SettingSlider(
        "Fade on play and pause", "How long the music fades in and out. 0 means no fade.",
        if (s.fadeMs == 0) "Off" else "${s.fadeMs} ms", s.fadeMs.toFloat(), 0f..3000f, steps = 29,
        onChange = { v -> c.change { it.copy(fadeMs = (v / 100f).roundToInt() * 100) } },
    )
    SettingSection("Reset")
    SettingAction("Reset sound settings", "Equalizer, reverb, balance, tempo and volume go back to the start. Saved presets stay.") { confirm = true }
    SettingNote("Songs made to play without a gap are joined without a gap. Crossfade between songs, replay gain, the resampler and bit perfect output are not built.")
    if (confirm) {
        AlertDialog(
            onDismissRequest = { confirm = false },
            title = { Text("Reset sound settings?") },
            text = { Text("The equalizer, tone, reverb, balance, stereo expand, tempo and volume go back to the start.") },
            confirmButton = { TextButton(onClick = { c.sound.resetAll(); confirm = false }) { Text("Reset") } },
            dismissButton = { TextButton(onClick = { confirm = false }) { Text("Cancel") } },
        )
    }
}

@Composable
private fun VisualizationPage(c: AppContainer, s: Settings) {
    SettingSlider(
        "Faded controls opacity", "How much of the buttons stays on screen while the visualizer plays alone",
        "${s.vizOpacityPct}%", s.vizOpacityPct.toFloat(), 0f..100f,
        onChange = { v -> c.change { it.copy(vizOpacityPct = v.roundToInt()) } },
    )
    SettingSlider(
        "UI timeout", "How long the buttons stay before they fade", "${s.vizTimeoutMs} ms",
        s.vizTimeoutMs.toFloat(), 1000f..10000f, steps = 17,
        onChange = { v -> c.change { it.copy(vizTimeoutMs = (v / 500f).roundToInt() * 500) } },
    )
    SettingSlider(
        "Change style automatically", "Seconds between styles. Off keeps the style you picked.",
        if (s.vizAutoSeconds == 0) "Off" else "${s.vizAutoSeconds} s", s.vizAutoSeconds.toFloat(), 0f..60f, steps = 11,
        onChange = { v -> c.change { it.copy(vizAutoSeconds = (v / 5f).roundToInt() * 5) } },
    )
    SettingNote("Styles: " + VisualizerNames.joinToString(", ") + ". Long press the visualizer button on the player to pick one.")
}

@Composable
private fun BackgroundPage(c: AppContainer, s: Settings) {
    SettingSwitch("Colour wash from the cover", "Tint the player with colours taken from the cover", s.bgOn) { v -> c.change { it.copy(bgOn = v) } }
    SettingSlider(
        "Intensity", null, "${s.bgIntensityPct}%", s.bgIntensityPct.toFloat(), 0f..100f,
        onChange = { v -> c.change { it.copy(bgIntensityPct = v.roundToInt()) } },
    )
    SettingSlider(
        "Saturation", "0 is grey, 100 is the cover's own colours", "${s.bgSaturationPct}%", s.bgSaturationPct.toFloat(), 0f..200f,
        onChange = { v -> c.change { it.copy(bgSaturationPct = v.roundToInt()) } },
    )
    SettingSlider(
        "Details", "Low is a smooth blur, high shows more of the picture", s.bgDetails.toString(), s.bgDetails.toFloat(), 4f..64f,
        onChange = { v -> c.change { it.copy(bgDetails = v.roundToInt()) } },
    )
    SettingSlider(
        "Darkness at the bottom", null, "${s.bgGradientPct}%", s.bgGradientPct.toFloat(), 0f..100f,
        onChange = { v -> c.change { it.copy(bgGradientPct = v.roundToInt()) } },
    )
    SettingAction("Restore defaults", null) {
        val d = Settings()
        c.change {
            it.copy(
                bgOn = d.bgOn, bgIntensityPct = d.bgIntensityPct, bgSaturationPct = d.bgSaturationPct,
                bgDetails = d.bgDetails, bgGradientPct = d.bgGradientPct,
            )
        }
    }
}

@Composable
private fun AlbumArtPage(c: AppContainer, s: Settings) {
    val context = LocalContext.current
    SettingSwitch("Force default image", "Always show the generated colours instead of the cover in the file", s.forceDefaultArt) { v ->
        c.change { it.copy(forceDefaultArt = v) }
    }
    SettingSwitch("Square cover on the player", "Crop the cover to a square. Off keeps its own shape, so wide pictures stay wide.", s.squareCover) { v ->
        c.change { it.copy(squareCover = v) }
    }
    SettingAction("Delete cache", "Forget the covers held in memory. They load again when needed.") {
        c.art.clearCache()
        Toast.makeText(context, "Cache deleted", Toast.LENGTH_SHORT).show()
    }
    SettingNote("Covers are read from the song files. Nothing is downloaded, the app has no internet access.")
}

@Composable
private fun LibraryPage(c: AppContainer, s: Settings, onOpen: (String) -> Unit) {
    val songs by remember { c.repository.browse.observeTrackCount() }.collectAsStateWithLifecycle(initialValue = 0)
    val lists by remember { c.repository.browse.observePlaylistCount() }.collectAsStateWithLifecycle(initialValue = 0)
    val scanning by c.repository.isScanning.collectAsStateWithLifecycle()
    SettingAction(
        "Rescan",
        if (scanning) "Scanning now…" else "Folders: ${s.knownFolders.size}, Playlists: $lists, Songs: $songs",
    ) { c.repository.startScan() }
    SettingAction("Music Folders", "Choose which folders are in the library") { onOpen("musicfolders") }
    SettingSlider(
        "Ignore short tracks", "Leave out songs shorter than this, like notification sounds. Applies at the next rescan.",
        "${s.minTrackSeconds} s", s.minTrackSeconds.toFloat(), 0f..60f, steps = 59,
        onChange = { v -> c.change { it.copy(minTrackSeconds = v.roundToInt()) } },
    )
    SettingSwitch("Ignore video tracks", "Leave out video files that only have sound. Applies at the next rescan.", s.ignoreVideo) { v ->
        c.change { it.copy(ignoreVideo = v) }
    }
    SettingSection("Playback")
    SettingSwitch("Remember where long songs stopped", "Long songs start again from the place you left them", s.rememberProgress) { v ->
        c.change { it.copy(rememberProgress = v) }
    }
    SettingSlider(
        "Long means at least", null, "${s.rememberMinMinutes} min", s.rememberMinMinutes.toFloat(), 10f..120f, steps = 21,
        onChange = { v -> c.change { it.copy(rememberMinMinutes = (v / 5f).roundToInt() * 5) } },
    )
    SettingSlider(
        "Count as played after", "Used by Most Played and Recently Played", "${s.countPlayedPct}%", s.countPlayedPct.toFloat(), 10f..100f,
        onChange = { v -> c.change { it.copy(countPlayedPct = v.roundToInt()) } },
    )
}

@Composable
private fun MusicFoldersPage(c: AppContainer, s: Settings) {
    val folders = s.knownFolders.sorted()
    if (folders.isEmpty()) {
        SettingNote("No folders yet. Open the Library page and tap Rescan first.")
    } else {
        folders.forEach { path ->
            SettingSwitch(path, null, path !in s.excludedFolders) { on ->
                c.change { it.copy(excludedFolders = if (on) it.excludedFolders - path else it.excludedFolders + path) }
            }
        }
    }
    SettingNote("Switch a folder off to leave its music out. A folder inside it follows it. Changes apply at the next rescan.")
    SettingAction("Rescan now", null) { c.repository.startScan() }
}

@Composable
private fun HeadsetPage(c: AppContainer, s: Settings) {
    SettingSwitch("Pause when headphones are unplugged", "Also when a Bluetooth device disconnects", s.pauseOnUnplug) { v ->
        c.change { it.copy(pauseOnUnplug = v) }
    }
    SettingNote("The play, pause, next and previous buttons on headsets and Bluetooth devices work through the notification and need no setting.")
}

@Composable
private fun LockPage(c: AppContainer, s: Settings) {
    SettingSwitch("Show on lock screen", "Show the player over the lock screen while the app is open", s.showOnLock) { v ->
        c.change { it.copy(showOnLock = v) }
    }
    SettingNote("The song controls in the lock screen notification work with this switched off.")
}

@Composable
private fun MiscPage(c: AppContainer) {
    var confirm by remember { mutableStateOf(false) }
    SettingAction("Restore default settings", "Every choice on the settings pages goes back to the start. Songs, playlists and presets stay.") { confirm = true }
    if (confirm) {
        AlertDialog(
            onDismissRequest = { confirm = false },
            title = { Text("Restore default settings?") },
            text = { Text("Songs, playlists, bookmarks and saved presets are not touched.") },
            confirmButton = { TextButton(onClick = { c.settings.resetAll(); confirm = false }) { Text("Restore") } },
            dismissButton = { TextButton(onClick = { confirm = false }) { Text("Cancel") } },
        )
    }
}

@Composable
private fun AboutPage() {
    val context = LocalContext.current
    var licences by remember { mutableStateOf(false) }
    val version = remember {
        try {
            val info = context.packageManager.getPackageInfo(context.packageName, 0)
            "${info.versionName} (build ${PackageInfoCompat.getLongVersionCode(info)})"
        } catch (e: Exception) {
            "unknown"
        }
    }
    InfoLine("Version", version)
    SettingAction("Open source licences", "The libraries this app is built with") { licences = true }
    SettingSection("Privacy")
    SettingNote("This app has no internet access. Your music, playlists, bookmarks and settings stay on this phone.")
    if (licences) {
        AlertDialog(
            onDismissRequest = { licences = false },
            title = { Text("Open source licences") },
            text = {
                Text(
                    "AndroidX Media3, AndroidX Compose, Room, Navigation and Lifecycle, Kotlin and Kotlin coroutines are used under the " +
                        "Apache License 2.0. The Material icons are used under the Apache License 2.0.",
                )
            },
            confirmButton = { TextButton(onClick = { licences = false }) { Text("Close") } },
        )
    }
}

@Composable
private fun InfoLine(title: String, value: String) {
    Column(Modifier.padding(horizontal = ApmSpace.s4, vertical = ApmSpace.s2)) {
        Text(title, style = Apm.type.caption, color = Color(0xFF9A9A9A))
        Text(value, style = Apm.type.body, color = Apm.colors.text)
    }
}

/** What the song is, and everything that touches the sound on its way to the speaker. */
@Composable
private fun AudioInfoPage(c: AppContainer) {
    val state by c.player.state.collectAsStateWithLifecycle()
    val sound by c.sound.state.collectAsStateWithLifecycle()
    val fade by c.settings.state.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val outRate = remember {
        (context.getSystemService(Context.AUDIO_SERVICE) as AudioManager).getProperty(AudioManager.PROPERTY_OUTPUT_SAMPLE_RATE)
    }
    if (!state.hasMedia) {
        SettingNote("Nothing is playing. Play a song and come back.")
        return
    }
    fun onOff(v: Boolean) = if (v) "on" else "off"
    InfoLine("Song", state.title)
    SettingSection("Source")
    InfoLine("Codec", state.codec.ifEmpty { "unknown" })
    InfoLine("Sample rate", if (state.sampleRate > 0) "${state.sampleRate} Hz" else "unknown")
    InfoLine("Bit rate", if (state.bitrateBps > 0) "${state.bitrateBps / 1000} kbps" else "unknown")
    InfoLine("Channels", when (state.channels) { 1 -> "Mono"; 2 -> "Stereo"; 0 -> "unknown"; else -> "${state.channels}" })
    SettingSection("Output")
    InfoLine("Phone output rate", outRate?.let { "$it Hz" } ?: "unknown")
    SettingSection("Processing")
    InfoLine(
        "Equalizer",
        if (!sound.eqOn) "off"
        else if (sound.eqMode == MODE_PARAMETRIC) "parametric, ${sound.paramBands.size} filters, preamp ${String.format(Locale.ROOT, "%.1f", sound.preampDb)} dB"
        else "graphic, 10 bands, preamp ${String.format(Locale.ROOT, "%.1f", sound.preampDb)} dB",
    )
    InfoLine("Tone", if (sound.toneOn) "bass ${sound.bassPct.toInt()}%, treble ${sound.treblePct.toInt()}%" else "off")
    InfoLine("Stereo expand", if (sound.stereoExpandPct > 0f) "${sound.stereoExpandPct.toInt()}%" else "off")
    InfoLine("Balance", String.format(Locale.ROOT, "%.2f", sound.balance))
    InfoLine("Mono", onOff(sound.mono))
    InfoLine("Reverb", onOff(sound.reverbOn))
    InfoLine("Limiter", onOff(sound.limiterOn))
    InfoLine("Tempo", if (sound.tempoOn) String.format(Locale.ROOT, "%.2fx", sound.tempo) else "off")
    InfoLine("Volume", "${(sound.volume * 100).toInt()}%")
    InfoLine("Fade on play and pause", if (fade.fadeMs == 0) "off" else "${fade.fadeMs} ms")
}
