package app.apmplayer.ui.screens

import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.ui.draw.alpha
import androidx.compose.foundation.layout.Box
import androidx.compose.runtime.collectAsState
import app.apmplayer.ui.components.SettingKnobRow
import app.apmplayer.audio.SoundEngine
import app.apmplayer.audio.Outputs
import app.apmplayer.audio.OutputKind
import android.media.audiofx.AudioEffect
import android.media.AudioDeviceInfo
import app.apmplayer.ui.components.focusRing
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.ui.unit.dp
import androidx.compose.ui.Alignment
import androidx.compose.ui.semantics.Role
import androidx.compose.foundation.clickable
import app.apmplayer.ui.theme.ApmShape
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.draw.clip
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.heightIn
import app.apmplayer.settings.setAppIcon
import app.apmplayer.settings.currentAppIcon
import app.apmplayer.settings.AppIcons
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.ui.graphics.asImageBitmap
import androidx.core.graphics.drawable.toBitmap
import app.apmplayer.playback.parseNotificationButtons
import app.apmplayer.playback.DEFAULT_NOTIFICATION_BUTTONS
import app.apmplayer.playback.NotificationButtonLabels
import app.apmplayer.playback.NotificationButtonIds
import app.apmplayer.lyrics.DEFAULT_LYRICS_URL
import app.apmplayer.lyrics.LyricsCharsets
import app.apmplayer.lyrics.LyricsApps
import android.net.Uri
import android.content.Intent
import kotlinx.coroutines.withContext
import kotlinx.coroutines.launch
import kotlinx.coroutines.Dispatchers
import app.apmplayer.ui.theme.toHex
import app.apmplayer.ui.theme.parseSkinsText
import app.apmplayer.ui.theme.customSkinsToJson
import app.apmplayer.ui.theme.customSkinsFrom
import app.apmplayer.ui.theme.allSkins
import app.apmplayer.ui.components.SettingRadio
import app.apmplayer.net.fetchText
import androidx.compose.runtime.rememberCoroutineScope
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.rememberLauncherForActivityResult
import android.os.Build
import app.apmplayer.ui.theme.n
import android.content.Context
import android.media.AudioManager
import android.widget.Toast
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.AlertDialog
import app.apmplayer.ui.components.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.pm.PackageInfoCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import app.apmplayer.AppContainer
import app.apmplayer.audio.MODE_PARAMETRIC
import app.apmplayer.settings.Settings
import app.apmplayer.ui.components.SettingAction
import app.apmplayer.ui.components.SettingChoices
import app.apmplayer.ui.components.SettingNote
import app.apmplayer.ui.components.SettingSection
import app.apmplayer.ui.components.SettingSlider
import app.apmplayer.ui.components.SettingSwitch
import app.apmplayer.ui.components.VisualizerNames
import app.apmplayer.ui.theme.ApmSkins
import app.apmplayer.ui.theme.Apm
import app.apmplayer.ui.theme.ApmSpace
import java.util.Locale
import kotlin.math.roundToInt

/** The inside of one settings group. Every switch and slider here changes how the app really behaves. */
@Composable
fun SettingsPageContent(groupId: String, container: AppContainer, s: Settings, onOpen: (String) -> Unit) {
    when (groupId) {
        "look" -> LookPage(container, s, onOpen)
        "look_player" -> LookPlayerPage(container, s, onOpen)
        "look_skin" -> SkinPage(container, s, onOpen)
        "look_icon" -> IconPage()
        "look_lyrics" -> LookLyricsPage(container, s)
        "look_notif" -> LookNotificationsPage(container, s)
        "look_lists" -> LookListsPage(container, s)
        "audio" -> AudioPage(onOpen)
        "audio_fade" -> AudioFadePage(container, s)
        "audio_rg" -> AudioReplayGainPage(container, s)
        "audio_focus" -> AudioFocusPage(container, s, onOpen)
        "audio_eq" -> AudioEqualizerPage()
        "audio_resampler" -> AudioResamplerPage(container, s, onOpen)
        "audio_dvc" -> AudioDvcPage(container, s, onOpen)
        "audio_outputs" -> AudioOutputsPage(container, s)
        "audio_bitperfect" -> AudioBitPerfectPage(container, s)
        "audio_tweaks" -> AudioTweaksPage(container)
        "visualization" -> VisualizationPage(container, s)
        "background" -> BackgroundPage(container, s)
        "albumart" -> AlbumArtPage(container, s)
        "library" -> LibraryPage(container, s, onOpen)
        "headset" -> HeadsetPage(container, s)
        "lock" -> LockPage(container, s)
        "misc" -> MiscPage(container)
        "about" -> AboutPage()
        "audioinfo" -> AudioInfoPage(container)
        "musicfolders" -> MusicFoldersPage(container, s)
    }
}

private fun AppContainer.change(change: (Settings) -> Settings) = settings.update(change)

@Composable
private fun LookPage(c: AppContainer, s: Settings, onOpen: (String) -> Unit) {
    SettingAction("Skin", "Change the look: layout, colours, corners, fonts, seek bar") { onOpen("look_skin") }
    SettingSwitch("Follow Day/Night Mode", "Follow the phone's day or night mode", s.themeMode == 3) { v ->
        c.change { it.copy(themeMode = if (v) 3 else 0) }
    }
    SettingChoices("Settings Theme", null, listOf("Default", "Light", "Dark", "Follow Day/Night Mode"), s.themeMode) { i ->
        c.change { it.copy(themeMode = i) }
    }
    SettingChoices(
        "Settings Font", "Alternative font, or heavier text everywhere",
        listOf("Default", "Alternative font", "Bold", "Bold+"),
        if (s.fontBoost == 2) 3 else if (s.fontBoost == 1) 2 else if (s.fontFamily == 1) 1 else 0,
    ) { i ->
        c.change {
            when (i) {
                0 -> it.copy(fontFamily = 0, fontBoost = 0)
                1 -> it.copy(fontFamily = 1, fontBoost = 0)
                2 -> it.copy(fontBoost = 1)
                else -> it.copy(fontBoost = 2)
            }
        }
    }
    SettingSection("General")
    SettingAction("Player Screen", "Animations, buttons row, rating, menu, lyrics button, previous button") { onOpen("look_player") }
    SettingAction("Lyrics", "Text size, follow the music, keep the screen on") { onOpen("look_lyrics") }
    SettingAction("Notifications", "What happens when the app is closed") { onOpen("look_notif") }
    SettingAction("List options", "File name as title, track number, covers and format in lists") { onOpen("look_lists") }
    SettingSection("Misc")
    SettingAction("Icon", "Set launcher icon") { onOpen("look_icon") }
    SettingChoices("Screen Orientation", null, listOf("Default", "Portrait (Vertical)", "Landscape (Horizontal)"), s.orientation) { i ->
        c.change { it.copy(orientation = i) }
    }
    SettingChoices("Animations", "How fast screens change. Disabled changes screens at once.", listOf("Disabled", "Fast", "Default"), s.animations) { i ->
        c.change { it.copy(animations = i) }
    }
    SettingSwitch(
        "Start at Player Screen", "Open the app on the player screen. The last queue comes back, paused, at the place where you stopped.",
        s.startAtPlayer,
    ) { v -> c.change { it.copy(startAtPlayer = v) } }
    SettingSwitch("Hide status bar", "Hide the clock and icons at the top. Swipe down from the top edge to see them.", s.hideStatusBar) { v ->
        c.change { it.copy(hideStatusBar = v) }
    }
    SettingSwitch("Keep screen on", "Never let the screen turn off while the app is open", s.keepScreenOn) { v ->
        c.change { it.copy(keepScreenOn = v) }
    }
    SettingSlider(
        "Shortcuts in the main menu", "How many settings shortcuts the menu shows", s.menuShortcuts.toString(),
        s.menuShortcuts.toFloat(), 0f..5f, steps = 4,
        onChange = { v -> c.change { it.copy(menuShortcuts = v.roundToInt()) } },
    )
    SettingNote("The language is not built yet.")
}

@Composable
private fun LookPlayerPage(c: AppContainer, s: Settings, onOpen: (String) -> Unit) {
    var editing by remember { mutableStateOf(false) }
    SettingAction("Skin options", "Press here for the additional Skin options like Static Seekbar, Pro Buttons") { onOpen("look_skin") }
    SettingSwitch("Album Art Animation", "Animate on track advance. Also applies to bottom bar", s.albumArtAnim) { v ->
        c.change { it.copy(albumArtAnim = v) }
    }
    SettingSwitch("Animate Long Labels", "Animate long track title and album/artist labels", s.animateLabels) { v ->
        c.change { it.copy(animateLabels = v) }
    }
    SettingSwitch("Animate Long Labels Everywhere", "Animate long track labels also in lists and the miniplayer", s.animateLabelsEverywhere) { v ->
        c.change { it.copy(animateLabelsEverywhere = v) }
    }

    SettingSection("Player Screen Buttons")
    SettingNote("Player screen buttons appear as a scrollable row below the track cover. To customize, press and hold the empty space between the buttons or use the item below.")
    SettingAction("Edit Player Screen Buttons", "Choose the buttons and their order") { editing = true }
    SettingSwitch("Prefer No Gap", "Minimize gaps between buttons for the centered layout", s.preferNoGap) { v ->
        c.change { it.copy(preferNoGap = v) }
    }
    SettingSwitch("Do Not Edit On Long Press", "Prevents accidental long press started button editing", s.noEditOnLongPress) { v ->
        c.change { it.copy(noEditOnLongPress = v) }
    }
    SettingAction("Restore Player Screen Buttons", null) { c.change { it.copy(playerButtons = DEFAULT_PLAYER_BUTTONS) } }

    SettingSection("Other Buttons")
    SettingChoices(
        "Rating Type", null, listOf("Disabled", "Like/unlike thumbs", "5 stars", "5 stars (menu/lists only)"), s.ratingType,
    ) { i -> c.change { it.copy(ratingType = i) } }
    SettingNote("Swipe over stars to select rating. Touch an empty space where star should be placed for immediate rating. Long press to toggle between 5 or 0 stars.")
    SettingChoices("Menu Button", "Menu can be opened by long pressing the cover", listOf("Disabled", "Enabled"), if (s.coverMenu) 1 else 0) { i ->
        c.change { it.copy(coverMenu = i == 1) }
    }
    SettingChoices("Menu Button Long Press", "Long press action for the track menu button", MenuLongPressLabels, s.menuLongPress) { i ->
        c.change { it.copy(menuLongPress = i) }
    }
    SettingChoices(
        "Lyrics Button", "Button on the Player Screen/cover", listOf("Disabled", "When local lyrics available", "Always"), s.lyricsButton,
    ) { i -> c.change { it.copy(lyricsButton = i) } }
    SettingChoices("Line2 Press", "Handle press on the 2nd track text line", Line2Labels, s.line2Press) { i ->
        c.change { it.copy(line2Press = i) }
    }
    SettingChoices("Line2 Long Press", "Handle long press on the 2nd track text line", Line2Labels, s.line2LongPress) { i ->
        c.change { it.copy(line2LongPress = i) }
    }
    SettingNote("Track Counter is available via Player Screen Buttons customization.")
    SettingSwitch(
        "<< Button Resets Current Track",
        "First press rewinds track, second press changes track. Includes headset/bluetooth button presses and the notification button",
        s.prevResets,
    ) { v -> c.change { it.copy(prevResets = v) } }
    SettingNote("To reset a track to 0:00 on the Player Screen use a long press on Elapsed time (left to Play button).")
    SettingSwitch(
        "-10/+10s Rewind Pro Buttons",
        "Change <<< >>> (category change) pro buttons to -10/+10s rewinding buttons for long tracks. Also applies to Long category",
        s.rewindProLong,
    ) { v -> c.change { it.copy(rewindProLong = v) } }
    SettingNote("Requires the Pro Buttons skin option to be enabled.")
    SettingAction("Long track duration", "At least: ${s.rememberMinMinutes} min. Press here to set long track duration.") { onOpen("library") }
    SettingSwitch(
        "Navigate to the Folders", "Track menu: the Folders button goes to the Folders category instead of the Folders hierarchy",
        s.folderNavFlat,
    ) { v -> c.change { it.copy(folderNavFlat = v) } }

    SettingSection("More")
    SettingSwitch("Time labels on pills", "Put the times on black pills. Off writes them as plain text.", s.timePills) { v ->
        c.change { it.copy(timePills = v) }
    }
    SettingSwitch("Show the info line", "The line with the sample rate, bit rate and file type under the buttons", s.showInfoLine) { v ->
        c.change { it.copy(showInfoLine = v) }
    }
    SettingSwitch("Swipe the cover to change songs", "Swipe left or right on the cover. Off stops accidental changes.", s.coverSwipe) { v ->
        c.change { it.copy(coverSwipe = v) }
    }
    SettingAction("Restore Defaults", null) {
        val d = Settings()
        c.change {
            it.copy(
                albumArtAnim = d.albumArtAnim, animateLabels = d.animateLabels, animateLabelsEverywhere = d.animateLabelsEverywhere,
                playerButtons = d.playerButtons, preferNoGap = d.preferNoGap, noEditOnLongPress = d.noEditOnLongPress,
                ratingType = d.ratingType, coverMenu = d.coverMenu, menuLongPress = d.menuLongPress, lyricsButton = d.lyricsButton,
                line2Press = d.line2Press, line2LongPress = d.line2LongPress, prevResets = d.prevResets, rewindProLong = d.rewindProLong,
                folderNavFlat = d.folderNavFlat, timePills = d.timePills, showInfoLine = d.showInfoLine, coverSwipe = d.coverSwipe,
            )
        }
    }
    if (editing) {
        PlayerButtonsEditor(
            current = parsePlayerButtons(s.playerButtons),
            onChange = { list -> c.change { it.copy(playerButtons = list.joinToString(",")) } },
            onDismiss = { editing = false },
        )
    }
}

@Composable
private fun LookLyricsPage(c: AppContainer, s: Settings) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var urlDialog by remember { mutableStateOf(false) }
    val installed = LyricsApps.filter { (_, pkg) ->
        try {
            context.packageManager.getPackageInfo(pkg, 0)
            true
        } catch (e: Exception) {
            false
        }
    }
    val appNames = listOf("Browser") + installed.map { it.first }
    val appPackages = listOf("") + installed.map { it.second }
    val folderLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) {
            try {
                context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (e: Exception) {
                // the folder still works for this run
            }
            c.change { it.copy(lrcFolderUri = uri.toString()) }
            Toast.makeText(context, "Folder saved. Looking for lyrics files...", Toast.LENGTH_SHORT).show()
            scope.launch {
                kotlinx.coroutines.delay(400)
                val n = c.lyricsTools.scanFolder { _, _ -> }
                Toast.makeText(context, if (n < 0) "Could not read that folder" else "Lyrics added for $n songs", Toast.LENGTH_LONG).show()
            }
        }
    }

    SettingNote("When lyrics swipe is enabled, swipe the album art up to show lyrics. Return from lyrics by swiping to the side. Pinch to zoom the text.")
    SettingChoices(
        "Lyrics Swipe Up", "Swipe action on the Player Screen/cover",
        listOf("Disabled", "When local lyrics available", "Always"), s.lyricsSwipe,
    ) { i -> c.change { it.copy(lyricsSwipe = i) } }
    SettingNote("Local lyrics: a lyrics tag inside the song, an .lrc or .txt file, or lyrics found online and kept. Use Rescan Lyrics Tags below to read the tags of all songs.")
    SettingChoices(
        "Lyrics Button", "Button on the Player Screen/cover",
        listOf("Disabled", "When local lyrics available", "Always"), s.lyricsButton,
    ) { i -> c.change { it.copy(lyricsButton = i) } }
    SettingNote("Long press on the lyrics button always searches in a browser or app.")
    SettingChoices("Lyrics Item In The Track Menu", null, listOf("Open lyrics UI", "Open 3rd party app"), s.lyricsMenuAction) { i ->
        c.change { it.copy(lyricsMenuAction = i) }
    }
    SettingNote("Long press on the lyrics item in the track menu always searches in a browser or app.")
    SettingSwitch("Keep Screen On", "Keep the screen on for the lyrics", s.lyricsKeepOn) { v -> c.change { it.copy(lyricsKeepOn = v) } }
    SettingSlider(
        "Lyrics Time Offset", "Applied to synced lyrics in addition to the offset tag",
        "${s.lyricsOffsetMs} ms", s.lyricsOffsetMs.toFloat(), -5000f..5000f, steps = 99,
        onChange = { v -> c.change { it.copy(lyricsOffsetMs = (Math.round(v / 100f) * 100)) } },
    )
    SettingNote("Positive value makes lyrics text appear earlier. Negative value delays lyrics text.")
    SettingChoices(
        "Lyrics Size", "Pinch to zoom on the lyrics screen",
        listOf("Small Font", "Default", "Large Font"),
        when { s.lyricsZoom < 0.9f -> 0; s.lyricsZoom > 1.1f -> 2; else -> 1 },
    ) { i -> c.change { it.copy(lyricsZoom = when (i) { 0 -> 0.8f; 2 -> 1.3f; else -> 1f }) } }
    SettingNote("The app loads lyrics from song tags, from .lrc and .txt files, and from the internet. If nothing is found, the lyrics can be searched in a browser or app.")
    SettingChoices(
        "Preferred Lyrics App", "App for searching lyrics when none are found (if installed)", appNames,
        appPackages.indexOf(s.lyricsApp).coerceAtLeast(0),
    ) { i -> c.change { it.copy(lyricsApp = appPackages[i]) } }
    SettingAction("Custom URL", "For the browser via custom URL: " + s.lyricsUrl) { urlDialog = true }

    SettingSection("Online")
    SettingSwitch("Download lyrics automatically", "When a song has no lyrics, look for them on the internet (LRCLIB) when you open the lyrics", s.lyricsAuto) { v ->
        c.change { it.copy(lyricsAuto = v) }
    }
    SettingSwitch("Only on Wi-Fi", "Do not use mobile data for the automatic lookup", s.lyricsWifiOnly) { v ->
        c.change { it.copy(lyricsWifiOnly = v) }
    }

    SettingSection("Scanner")
    SettingAction("Rescan Lyrics Tags", "Read the lyrics tags of songs without saved lyrics, including timed (SYLT) lyrics") {
        Toast.makeText(context, "Reading tags in the background...", Toast.LENGTH_SHORT).show()
        scope.launch {
            val n = c.lyricsTools.rescanTags { _, _ -> }
            Toast.makeText(context, "Lyrics found inside $n songs", Toast.LENGTH_LONG).show()
        }
    }
    SettingSwitch("Scan LRC Files", "Match .lrc and .txt files in the lyrics folder to songs by file name, a few seconds after the app starts", s.scanLrc) { v ->
        c.change { it.copy(scanLrc = v) }
    }
    SettingAction(
        "Lyrics Folder",
        if (s.lrcFolderUri.isBlank()) "Pick the folder with your .lrc files" else "Folder: " + (Uri.parse(s.lrcFolderUri).lastPathSegment ?: s.lrcFolderUri),
    ) { folderLauncher.launch(null) }
    SettingAction("Scan Lyrics Folder Now", "Look for new .lrc and .txt files") {
        scope.launch {
            val n = c.lyricsTools.scanFolder { _, _ -> }
            Toast.makeText(
                context, if (n < 0) "Pick a lyrics folder first" else "Lyrics added for $n songs", Toast.LENGTH_LONG,
            ).show()
        }
    }
    SettingSwitch("Always Use UTF-8", "If disabled, the Tag Encoding below is used for non-Unicode files", s.lyricsUtf8) { v ->
        c.change { it.copy(lyricsUtf8 = v) }
    }
    SettingChoices("Tag Encoding", "Used when Always Use UTF-8 is off", LyricsCharsets, s.lyricsCharset.coerceIn(0, LyricsCharsets.lastIndex)) { i ->
        c.change { it.copy(lyricsCharset = i) }
    }
    SettingAction("Restore Defaults", null) {
        val d = Settings()
        c.change {
            it.copy(
                lyricsSwipe = d.lyricsSwipe, lyricsButton = d.lyricsButton, lyricsMenuAction = d.lyricsMenuAction, lyricsKeepOn = d.lyricsKeepOn,
                lyricsOffsetMs = d.lyricsOffsetMs, lyricsZoom = d.lyricsZoom, lyricsApp = d.lyricsApp, lyricsUrl = d.lyricsUrl,
                lyricsAuto = d.lyricsAuto, lyricsWifiOnly = d.lyricsWifiOnly, scanLrc = d.scanLrc, lyricsUtf8 = d.lyricsUtf8,
                lyricsCharset = d.lyricsCharset, lyricsAutoScroll = d.lyricsAutoScroll,
            )
        }
    }
    if (urlDialog) {
        NameDialog("Custom URL (use %ARTIST% and %TITLE%)", s.lyricsUrl, "Save", { urlDialog = false }) { url ->
            urlDialog = false
            c.change { it.copy(lyricsUrl = url.trim().ifEmpty { DEFAULT_LYRICS_URL }) }
        }
    }
}

@Composable
private fun LookNotificationsPage(c: AppContainer, s: Settings) {
    var buttons by remember { mutableStateOf(false) }
    val colorized = s.notifType == 1 || (s.notifType != 3 && s.colorizeNotification)
    SettingChoices(
        "Notification Type", null,
        listOf("Auto", "Media / Colorized", "Media with the custom cover", "Legacy"), s.notifType,
    ) { i -> c.change { it.copy(notifType = i) } }
    SettingNote(
        when (s.notifType) {
            1 -> "The standard media notification, always coloured from the cover."
            2 -> "The standard media notification with the cover of the song, including a picture you chose for it."
            3 -> "A plain notification with the song, the artist and three buttons. No cover and no media look."
            else -> "The standard media notification of the phone."
        },
    )
    SettingChoices(
        "Notification Colors", "Adjust if notification text/icons are not visible due to the non-standard colors",
        listOf("Auto", "Black", "White"), s.notifColors,
    ) { i -> c.change { it.copy(notifColors = i) } }
    SettingNote(
        if (colorized) "Black makes the colour lighter for dark text, White makes it darker for light text."
        else "Colors work when the notification is coloured from the cover. Switch on Colorize Notification or pick Media / Colorized.",
    )
    SettingSwitch("Colorize Notification", "Match notification colors and background to the track album art image", s.colorizeNotification) { v ->
        c.change { it.copy(colorizeNotification = v) }
    }
    SettingAction("Buttons", "Media action buttons: " + parseNotificationButtons(s.notifButtons).joinToString(", ") { id -> NotificationButtonLabels[NotificationButtonIds.indexOf(id)] }) {
        buttons = true
    }
    SettingSwitch("Navigate to the List", "Notification navigates to the current list on touch", s.notifOpenList) { v ->
        c.change { it.copy(notifOpenList = v) }
    }

    SettingSection("Notification Keeping")
    SettingSwitch(
        "Keep Notification", "Notification stays even if the player is paused, when playback auto-ends, etc.", s.keepNotification,
    ) { v -> c.change { it.copy(keepNotification = v) } }
    SettingNote("If disabled, the notification is removed when the queue ends, or after 5 minutes of pause. It can always be removed by swiping it away.")
    SettingSwitch(
        "Keep Inactive Media Notification", "Player can be resumed via the media notification suggestion when inactive or unloaded (depending on the firmware)",
        s.keepInactiveNotification,
    ) { v -> c.change { it.copy(keepInactiveNotification = v) } }
    SettingNote("The saved queue comes back at the last place. Whether Android shows the suggestion depends on the phone.")
    SettingSwitch("Keep Service", "The player service will not be unloaded when idle after the app is closed from recent apps", s.keepService) { v ->
        c.change { it.copy(keepService = v) }
    }
    SettingNote("On Android 8 and newer this works reliably only with the active notification.")
    SettingSwitch(
        "Remove Notification on Disconnection", "Notification is removed on Headset/BT disconnection if the player is paused", s.removeOnDisconnect,
    ) { v -> c.change { it.copy(removeOnDisconnect = v) } }
    SettingNote("This option may temporarily keep the idle service if required.")
    SettingChoices(
        "When the app is closed from recent apps", "Most music players keep playing, like this one by default",
        listOf("Keep playing", "Stop the music"), if (s.stopOnSwipe) 1 else 0,
    ) { i -> c.change { it.copy(stopOnSwipe = i == 1) } }
    SettingAction("Restore Defaults", null) {
        val d = Settings()
        c.change {
            it.copy(
                notifType = d.notifType, notifColors = d.notifColors, colorizeNotification = d.colorizeNotification, notifButtons = d.notifButtons,
                notifOpenList = d.notifOpenList, keepNotification = d.keepNotification, keepInactiveNotification = d.keepInactiveNotification,
                keepService = d.keepService, removeOnDisconnect = d.removeOnDisconnect, stopOnSwipe = d.stopOnSwipe,
            )
        }
    }
    if (buttons) {
        ButtonsOrderDialog(
            title = "Notification buttons",
            all = NotificationButtonIds.zip(NotificationButtonLabels),
            current = parseNotificationButtons(s.notifButtons),
            mustHave = "playpause",
            onChange = { list -> c.change { it.copy(notifButtons = list.joinToString(",")) } },
            onRestore = { c.change { it.copy(notifButtons = DEFAULT_NOTIFICATION_BUTTONS) } },
            onDismiss = { buttons = false },
        )
    }
}

@Composable
private fun LookListsPage(c: AppContainer, s: Settings) {
    SettingSwitch(
        "File name as title", "Show the name of the file instead of the title written inside it. The library updates after a moment.",
        s.filenameAsTitle,
    ) { v ->
        c.change { it.copy(filenameAsTitle = v) }
        c.repository.startScan()
    }
    SettingSwitch("Show track number", "Start the title with the number of the song in its album, like 03.", s.showTrackNumber) { v ->
        c.change { it.copy(showTrackNumber = v) }
    }
    SettingSwitch("Show file type", "Write the file type after the length, like 4:32 | mp3", s.showFormat) { v ->
        c.change { it.copy(showFormat = v) }
    }
    SettingSwitch("Show covers in lists", "Small pictures next to the songs. Off makes the lists plainer and a little lighter.", s.listCovers) { v ->
        c.change { it.copy(listCovers = v) }
    }
}

@Composable
private fun AudioPage(onOpen: (String) -> Unit) {
    SettingAction("Audio Info", "Detailed info about the audio processing. Also available by long press on the small meta info on the Main and Equalizer screens") { onOpen("audioinfo") }
    SettingAction("Crossfade, Fade, and Gapless", "Crossfade options, fade type and length, gapless") { onOpen("audio_fade") }
    SettingAction("Replay Gain (RG)", "Enable RG, set source, preamp values") { onOpen("audio_rg") }
    SettingAction("Audio Focus", "Pause/Resume/Duck volume on calls/notifications/start") { onOpen("audio_focus") }
    SettingAction("Equalizer", "Equalizer settings, number of bands, frequencies") { onOpen("audio_eq") }
    SettingAction("Resampler", "Resampling/dither settings") { onOpen("audio_resampler") }
    SettingAction("Direct Volume Control (DVC)", "DVC options, DVC for Bluetooth") { onOpen("audio_dvc") }
    SettingAction("Audio Outputs", "Wired Headset, Bluetooth, USB, Chromecast, and other outputs") { onOpen("audio_outputs") }
    SettingAction("Bit Perfect", "64-bit audio pipeline, Perfect Bit Perfect") { onOpen("audio_bitperfect") }
    SettingAction("Advanced Tweaks", "Volume levels, MusicFX, equalizer/reverb presets reset") { onOpen("audio_tweaks") }
}

@Composable
private fun AudioFadePage(c: AppContainer, s: Settings) {
    SettingSlider(
        "Fade on play and pause", "How long the music fades in and out when you press play or pause. 0 means no fade.",
        if (s.fadeMs == 0) "Off" else "${s.fadeMs} ms", s.fadeMs.toFloat(), 0f..3000f, steps = 29,
        onChange = { v -> c.change { it.copy(fadeMs = (v / 100f).roundToInt() * 100) } },
    )
    SettingSlider(
        "Fade between songs", "The end of a song fades out and the start of the next one fades in. 0 means no fade.",
        if (s.songFadeMs == 0) "Off" else "${s.songFadeMs / 1000.0} s", s.songFadeMs.toFloat(), 0f..12000f, steps = 23,
        onChange = { v -> c.change { it.copy(songFadeMs = (v / 500f).roundToInt() * 500) } },
    )
    SettingNote("Gapless: songs made to play without a gap (live albums, mixes) are joined without a gap, nothing to switch.")
    SettingNote("A crossfade where two songs play together is not built yet.")
}

@Composable
private fun AudioReplayGainPage(c: AppContainer, s: Settings) {
    val off = s.rgApply == 0
    SettingChoices(
        "Replay Gain", null,
        listOf("Don't apply", "Apply Gain", "Apply Gain/prevent clipping according to Peak"), s.rgApply,
    ) { i -> c.change { it.copy(rgApply = i) } }
    // the Source choice is dimmed while Replay Gain is off
    Box(Modifier.alpha(if (off) 0.4f else 1f)) {
        SettingChoices("Source", null, listOf("Album", "Track"), s.rgSource) { i -> if (!off) c.change { it.copy(rgSource = i) } }
    }
    SettingKnobRow(
        "RG preamp", null, s.rgPreampWith, -15f, 15f, 0f, String.format(java.util.Locale.ROOT, "%.1fdB", s.rgPreampWith), enabled = !off,
    ) { v -> c.change { it.copy(rgPreampWith = (v * 2f).roundToInt() / 2f) } }
    SettingKnobRow(
        "Preamp for songs without RG info", null, s.rgPreampWithout, -15f, 15f, 0f,
        String.format(java.util.Locale.ROOT, "%.1fdB", s.rgPreampWithout), enabled = !off,
    ) { v -> c.change { it.copy(rgPreampWithout = (v * 2f).roundToInt() / 2f) } }
    SettingNote("The loudness notes are read from MP3 (ID3), FLAC, OGG and M4A files. Changes apply at once.")
    SettingAction("Restore Defaults", null) {
        val d = Settings()
        c.change { it.copy(rgApply = d.rgApply, rgSource = d.rgSource, rgPreampWith = d.rgPreampWith, rgPreampWithout = d.rgPreampWithout) }
    }
}

@Composable
private fun AudioFocusPage(c: AppContainer, s: Settings, onOpen: (String) -> Unit) {
    SettingSwitch("Resume After Call", "Resume playing on hang up (if paused by call)", s.resumeAfterCall) { v -> c.change { it.copy(resumeAfterCall = v) } }
    SettingSwitch("Resume On Start", "Resume playing when the app is started", s.resumeOnStart) { v -> c.change { it.copy(resumeOnStart = v) } }
    SettingSwitch("Resume On Reopen", "Also resume when the app is already running and reopened from the launcher", s.resumeOnReopen) { v ->
        c.change { it.copy(resumeOnReopen = v) }
    }
    SettingSwitch("Wait For Storage", "Wait for a storage (up to 30s.) to mount before resuming on start", s.waitForStorage) { v ->
        c.change { it.copy(waitForStorage = v) }
    }
    SettingSection("Audio Focus")
    SettingAction(
        "Keep Notification",
        "On Android 8 and up the app can be unloaded by the system while paused. Press here to avoid that via the Keep Notification option",
    ) { onOpen("look_notif") }
    SettingSwitch(
        "Short Audio Focus Change / Calls", "Temporarily pause on short audio focus change (calls/notifications/navigation/etc.)", s.focusShort,
    ) { v -> c.change { it.copy(focusShort = v) } }
    SettingSwitch("Pause In Call", "Pause when a phone call happens. The app always pauses for a call via Bluetooth", s.pauseInCall) { v ->
        c.change { it.copy(pauseInCall = v) }
    }
    SettingNote("Some firmwares may not support this option")
    SettingSwitch("Resume On Focus Gain", "Resume after getting back the focus. If disabled, player stays paused", s.resumeOnGain) { v ->
        c.change { it.copy(resumeOnGain = v) }
    }
    SettingSwitch(
        "Duck Volume", "When possible, allow lowering the volume on short audio focus. This option can be overridden by the output settings", s.duckVolume,
    ) { v -> c.change { it.copy(duckVolume = v) } }
    SettingSwitch(
        "Permanent Audio Focus Change", "Pause on permanent audio focus change (other player/game/etc.)", s.focusPermanent,
    ) { v -> c.change { it.copy(focusPermanent = v) } }
    SettingAction("Restore Defaults", null) {
        val d = Settings()
        c.change {
            it.copy(
                resumeAfterCall = d.resumeAfterCall, resumeOnStart = d.resumeOnStart, resumeOnReopen = d.resumeOnReopen, waitForStorage = d.waitForStorage,
                focusShort = d.focusShort, pauseInCall = d.pauseInCall, resumeOnGain = d.resumeOnGain, duckVolume = d.duckVolume, focusPermanent = d.focusPermanent,
            )
        }
    }
}

@Composable
private fun AudioEqualizerPage() {
    SettingNote("The equalizer, its presets, the parametric mode and the response curve are on the Equalizer screen.")
    SettingNote("Choosing the number of bands (5, 10, 15, 20, 31) and their frequencies is not built yet.")
}

private val DitherNames = listOf(
    "None (fastest)", "Rectangular (fast)", "Triangular (fast)", "Triangular with high pass (fast)",
    "F-weighted noise shaping (slow)", "Modified-e-weighted noise shaping (slow)", "Improved-e-weighted noise shaping (slow)", "Shibata noise shaping (slow)",
)

@Composable
private fun AudioResamplerPage(c: AppContainer, s: Settings, onOpen: (String) -> Unit) {
    var dialog by remember { mutableStateOf(false) }
    SettingNote("Enable the Bit Perfect options to avoid or minimize resampling. Resampling options are applied only when the applicable resampling stage is used.")
    SettingAction("Bit Perfect", "Open the Bit Perfect options") { onOpen("audio_bitperfect") }
    SettingNote("Resampler Type and Resampler Cutoff Frequency Ratio are built together with the resampler itself, in a later step.")
    SettingAction("Dither", DitherNames[s.ditherType.coerceIn(0, 7)] + ". Applied when the sound is cut to 16 bit. A float output needs none.") { dialog = true }
    SettingAction("Restore Defaults", null) { c.change { it.copy(ditherType = Settings().ditherType) } }
    if (dialog) {
        AlertDialog(
            onDismissRequest = { dialog = false },
            title = { Text("Dither") },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState())) {
                    DitherNames.forEachIndexed { i, name ->
                        SettingRadio(name, null, s.ditherType == i) {
                            c.change { it.copy(ditherType = i) }
                            dialog = false
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { dialog = false }) { Text("Close") } },
        )
    }
}

@Composable
private fun AudioDvcPage(c: AppContainer, s: Settings, onOpen: (String) -> Unit) {
    val context = LocalContext.current
    var more by remember { mutableStateOf(false) }
    val active by SoundEngine.dvcActive.collectAsState()
    val kind = remember(active) { Outputs.active(context) }
    val rows = listOf(
        Triple(OutputKind.WIRED, s.noDvcWired, false),
        Triple(OutputKind.BLUETOOTH, s.noDvcBt || s.noDvcBtAbs, false),
        Triple(OutputKind.USB, s.noDvcUsb, true),
        Triple(OutputKind.SPEAKER, s.noDvcSpeaker, true),
        Triple(OutputKind.OTHER, s.noDvcOther, true),
    )
    SettingNote("Direct Volume Control (DVC) improves volume and equalizer/tone dynamic range, especially in the bass. Here it means the volume knob moves the phone's own music volume, and the player stays at full volume.")
    SettingNote("DVC for Bluetooth works only when Absolute Volume is disabled. Otherwise, the volume may be too low. Absolute Volume means Bluetooth device volume is synced to the phone.")
    SettingNote("Some devices/Android variants block Absolute Volume detection. In this case please toggle \"No DVC For Bluetooth Absolute Volume\" manually.")
    SettingSwitch("Enable Direct Volume Control", null, s.dvc) { v -> c.change { it.copy(dvc = v) } }
    rows.filter { more || !it.third }.forEach { (output, blocked, _) ->
        SettingNote(output.label + " \u2192 AudioTrack Output  " + if (s.dvc && !blocked) "\u2714" else "\u2716")
    }
    SettingAction(if (more) "Show Less" else "Show More", null) { more = !more }
    SettingNote("DVC is enabled if: the per output \"No DVC\" option allows it, the \"No DVC for Bluetooth Absolute Volume\" option allows it, and the output driver and the end device support DVC.")
    SettingNote("Output now: " + kind.label + ". DVC now: " + if (active) "enabled" else "disabled")
    SettingSwitch(
        "No DVC for Bluetooth Absolute Volume",
        "Automatically disable DVC for Bluetooth when Absolute Volume is detected or it's not possible to detect it", s.noDvcBtAbs,
    ) { v -> c.change { it.copy(noDvcBtAbs = v) } }
    SettingNote("It's not possible to detect Absolute Volume on this phone, so this option just disables DVC for Bluetooth by default. Uncheck it if you know that Absolute Volume is disabled for your device.")
    SettingAction("Disable Bluetooth Absolute Volume", "Please toggle Bluetooth off/on after changing the option. Press here for details") {
        try {
            context.startActivity(Intent(android.provider.Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (e: Exception) {
            Toast.makeText(context, "Turn on Developer options first, then use \"Disable absolute volume\"", Toast.LENGTH_LONG).show()
        }
    }
    SettingKnobRow(
        "No DVC - Preamp Reduction",
        "Allows equalization/basses without distortion. Set to 0 dB to match other players' volume, though this makes equalization less effective. Applied only when DVC is disabled for any reason",
        s.preampReductionDb, -12f, 0f, 0f, String.format(java.util.Locale.ROOT, "%.1fdB", s.preampReductionDb),
    ) { v -> c.change { it.copy(preampReductionDb = (v * 2f).roundToInt() / 2f) } }
    SettingAction("Restore Defaults", null) {
        val d = Settings()
        c.change { it.copy(dvc = d.dvc, noDvcBtAbs = d.noDvcBtAbs, preampReductionDb = d.preampReductionDb) }
    }
}

private fun outputTypeName(type: Int): String = when (type) {
    AudioDeviceInfo.TYPE_BUILTIN_SPEAKER -> "Phone speaker"
    AudioDeviceInfo.TYPE_BUILTIN_EARPIECE -> "Phone earpiece"
    AudioDeviceInfo.TYPE_WIRED_HEADSET -> "Wired headset"
    AudioDeviceInfo.TYPE_WIRED_HEADPHONES -> "Wired headphones"
    AudioDeviceInfo.TYPE_BLUETOOTH_A2DP -> "Bluetooth"
    AudioDeviceInfo.TYPE_BLUETOOTH_SCO -> "Bluetooth (calls)"
    AudioDeviceInfo.TYPE_USB_DEVICE -> "USB audio"
    AudioDeviceInfo.TYPE_USB_HEADSET -> "USB headset"
    AudioDeviceInfo.TYPE_HDMI -> "HDMI"
    AudioDeviceInfo.TYPE_LINE_ANALOG -> "Line out"
    else -> "Other output ($type)"
}

@Composable
private fun AudioOutputsPage(c: AppContainer, s: Settings) {
    val context = LocalContext.current
    var refresh by remember { mutableIntStateOf(0) }
    val devices = remember(refresh) {
        context.getSystemService(AudioManager::class.java).getDevices(AudioManager.GET_DEVICES_OUTPUTS).toList()
    }
    SettingNote("Pick the output the music should ask for when it is connected. Automatic lets the phone choose.")
    SettingRadio("Automatic", "The phone chooses", s.outputType < 0) { c.change { it.copy(outputType = -1, outputName = "") } }
    devices.forEach { d ->
        val name = d.productName.toString()
        SettingRadio(outputTypeName(d.type), name, s.outputType == d.type && s.outputName == name) {
            c.change { it.copy(outputType = d.type, outputName = name) }
        }
    }
    SettingAction("Refresh the list", "Outputs that were connected after this page opened") { refresh++ }
    SettingNote("Chromecast and other network outputs are not built yet.")
}

@Composable
private fun AudioBitPerfectPage(c: AppContainer, s: Settings) {
    SettingSwitch(
        "Bit Perfect", "The sound passes through untouched: no equalizer, tone, reverb, limiter, balance, replay gain or fade by sound processing. " +
            "On Android 14 and newer with a USB DAC, the phone is also asked for an untouched mix.",
        s.bitPerfect,
    ) { v -> c.change { it.copy(bitPerfect = v) } }
    SettingNote("The sound is already processed in 64-bit numbers inside the app. Whether the output is truly bit perfect depends on the phone and the DAC.")
}

@Composable
private fun AudioTweaksPage(c: AppContainer) {
    val context = LocalContext.current
    var confirm by remember { mutableStateOf(false) }
    var confirmPresets by remember { mutableStateOf(false) }
    var confirmReverbs by remember { mutableStateOf(false) }
    SettingAction("Phone sound settings", "Open the sound settings of Android") {
        try {
            context.startActivity(Intent(android.provider.Settings.ACTION_SOUND_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (e: Exception) {
            Toast.makeText(context, "Could not open the sound settings", Toast.LENGTH_SHORT).show()
        }
    }
    SettingAction("MusicFX (system equalizer)", "Open the equalizer of the phone, if it has one") {
        try {
            context.startActivity(
                Intent(AudioEffect.ACTION_DISPLAY_AUDIO_EFFECT_CONTROL_PANEL)
                    .putExtra(AudioEffect.EXTRA_CONTENT_TYPE, AudioEffect.CONTENT_TYPE_MUSIC)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            )
        } catch (e: Exception) {
            Toast.makeText(context, "This phone has no system equalizer", Toast.LENGTH_SHORT).show()
        }
    }
    SettingSection("Reset")
    SettingAction("Remove my equalizer presets", "Deletes the presets you saved. The built-in ones stay.") { confirmPresets = true }
    SettingAction("Remove my reverb presets", "Deletes the reverb presets you saved. The built-in ones stay.") { confirmReverbs = true }
    SettingAction("Reset sound settings", "Equalizer, reverb, balance, tempo and volume go back to the start. Saved presets stay.") { confirm = true }
    SettingNote("The volume knob has no steps to set. It goes from 0 to 100 percent.")
    if (confirm) {
        AlertDialog(
            onDismissRequest = { confirm = false },
            title = { Text("Reset sound settings?") },
            text = { Text("The equalizer, tone, reverb, balance, stereo expand, tempo and volume go back to the start.") },
            confirmButton = { TextButton(onClick = { c.sound.resetAll(); confirm = false }) { Text("Reset") } },
            dismissButton = { TextButton(onClick = { confirm = false }) { Text("Cancel") } },
        )
    }
    if (confirmReverbs) {
        AlertDialog(
            onDismissRequest = { confirmReverbs = false },
            title = { Text("Remove your reverb presets?") },
            text = { Text("All the reverb presets you saved are deleted.") },
            confirmButton = {
                TextButton(onClick = {
                    c.sound.userReverbs.value.map { it.name }.forEach { c.sound.deleteReverbPreset(it) }
                    confirmReverbs = false
                }) { Text("Remove") }
            },
            dismissButton = { TextButton(onClick = { confirmReverbs = false }) { Text("Cancel") } },
        )
    }
    if (confirmPresets) {
        AlertDialog(
            onDismissRequest = { confirmPresets = false },
            title = { Text("Remove your presets?") },
            text = { Text("All the equalizer presets you saved are deleted.") },
            confirmButton = {
                TextButton(onClick = {
                    c.sound.userPresets.value.map { it.name }.forEach { c.sound.deletePreset(it) }
                    confirmPresets = false
                }) { Text("Remove") }
            },
            dismissButton = { TextButton(onClick = { confirmPresets = false }) { Text("Cancel") } },
        )
    }
}


@Composable
private fun VisualizationPage(c: AppContainer, s: Settings) {
    SettingSlider(
        "Faded controls opacity", "How much of the buttons stays on screen while the visualizer plays alone",
        "${s.vizOpacityPct}%", s.vizOpacityPct.toFloat(), 0f..100f,
        onChange = { v -> c.change { it.copy(vizOpacityPct = v.roundToInt()) } },
    )
    SettingSlider(
        "UI timeout", "How long the buttons stay before they fade", "${s.vizTimeoutMs} ms",
        s.vizTimeoutMs.toFloat(), 1000f..10000f, steps = 17,
        onChange = { v -> c.change { it.copy(vizTimeoutMs = (v / 500f).roundToInt() * 500) } },
    )
    SettingSlider(
        "Change style automatically", "Seconds between styles. Off keeps the style you picked.",
        if (s.vizAutoSeconds == 0) "Off" else "${s.vizAutoSeconds} s", s.vizAutoSeconds.toFloat(), 0f..60f, steps = 11,
        onChange = { v -> c.change { it.copy(vizAutoSeconds = (v / 5f).roundToInt() * 5) } },
    )
    SettingNote("Styles: " + VisualizerNames.joinToString(", ") + ". Long press the visualizer button on the player to pick one.")
}

@Composable
private fun BackgroundPage(c: AppContainer, s: Settings) {
    SettingSwitch("Colour wash from the cover", "Tint the player with colours taken from the cover", s.bgOn) { v -> c.change { it.copy(bgOn = v) } }
    SettingSlider(
        "Intensity", null, "${s.bgIntensityPct}%", s.bgIntensityPct.toFloat(), 0f..100f,
        onChange = { v -> c.change { it.copy(bgIntensityPct = v.roundToInt()) } },
    )
    SettingSlider(
        "Saturation", "0 is grey, 100 is the cover's own colours", "${s.bgSaturationPct}%", s.bgSaturationPct.toFloat(), 0f..200f,
        onChange = { v -> c.change { it.copy(bgSaturationPct = v.roundToInt()) } },
    )
    SettingSlider(
        "Details", "Low is a smooth blur, high shows more of the picture", s.bgDetails.toString(), s.bgDetails.toFloat(), 4f..64f,
        onChange = { v -> c.change { it.copy(bgDetails = v.roundToInt()) } },
    )
    SettingSlider(
        "Darkness at the bottom", null, "${s.bgGradientPct}%", s.bgGradientPct.toFloat(), 0f..100f,
        onChange = { v -> c.change { it.copy(bgGradientPct = v.roundToInt()) } },
    )
    SettingAction("Restore defaults", null) {
        val d = Settings()
        c.change {
            it.copy(
                bgOn = d.bgOn, bgIntensityPct = d.bgIntensityPct, bgSaturationPct = d.bgSaturationPct,
                bgDetails = d.bgDetails, bgGradientPct = d.bgGradientPct,
            )
        }
    }
}

@Composable
private fun AlbumArtPage(c: AppContainer, s: Settings) {
    val context = LocalContext.current
    SettingSwitch("Force default image", "Always show the generated colours instead of the cover in the file", s.forceDefaultArt) { v ->
        c.change { it.copy(forceDefaultArt = v) }
    }
    SettingSwitch("Square cover on the player", "Crop the cover to a square. Off keeps its own shape, so wide pictures stay wide.", s.squareCover) { v ->
        c.change { it.copy(squareCover = v) }
    }
    SettingAction("Delete cache", "Forget the covers held in memory. They load again when needed.") {
        c.art.clearCache()
        Toast.makeText(context, "Cache deleted", Toast.LENGTH_SHORT).show()
    }
    SettingNote("Covers are read from the song files.")
}

@Composable
private fun LibraryPage(c: AppContainer, s: Settings, onOpen: (String) -> Unit) {
    val songs by remember { c.repository.browse.observeTrackCount() }.collectAsStateWithLifecycle(initialValue = 0)
    val lists by remember { c.repository.browse.observePlaylistCount() }.collectAsStateWithLifecycle(initialValue = 0)
    val scanning by c.repository.isScanning.collectAsStateWithLifecycle()
    SettingAction(
        "Rescan",
        if (scanning) "Scanning now…" else "Folders: ${s.knownFolders.size}, Playlists: $lists, Songs: $songs",
    ) { c.repository.startScan() }
    SettingAction("Music Folders", "Choose which folders are in the library") { onOpen("musicfolders") }
    SettingSlider(
        "Ignore short tracks", "Leave out songs shorter than this, like notification sounds. Applies at the next rescan.",
        "${s.minTrackSeconds} s", s.minTrackSeconds.toFloat(), 0f..60f, steps = 59,
        onChange = { v -> c.change { it.copy(minTrackSeconds = v.roundToInt()) } },
    )
    SettingSwitch("Ignore video tracks", "Leave out video files that only have sound. Applies at the next rescan.", s.ignoreVideo) { v ->
        c.change { it.copy(ignoreVideo = v) }
    }
    SettingSection("Playback")
    SettingSwitch("Remember where long songs stopped", "Long songs start again from the place you left them", s.rememberProgress) { v ->
        c.change { it.copy(rememberProgress = v) }
    }
    SettingSlider(
        "Long means at least", null, "${s.rememberMinMinutes} min", s.rememberMinMinutes.toFloat(), 10f..120f, steps = 21,
        onChange = { v -> c.change { it.copy(rememberMinMinutes = (v / 5f).roundToInt() * 5) } },
    )
    SettingSlider(
        "Count as played after", "Used by Most Played and Recently Played", "${s.countPlayedPct}%", s.countPlayedPct.toFloat(), 10f..100f,
        onChange = { v -> c.change { it.copy(countPlayedPct = v.roundToInt()) } },
    )
}

@Composable
private fun MusicFoldersPage(c: AppContainer, s: Settings) {
    val folders = s.knownFolders.sorted()
    if (folders.isEmpty()) {
        SettingNote("No folders yet. Open the Library page and tap Rescan first.")
    } else {
        folders.forEach { path ->
            SettingSwitch(path, null, path !in s.excludedFolders) { on ->
                c.change { it.copy(excludedFolders = if (on) it.excludedFolders - path else it.excludedFolders + path) }
            }
        }
    }
    SettingNote("Switch a folder off to leave its music out. A folder inside it follows it. Changes apply at the next rescan.")
    SettingAction("Rescan now", null) { c.repository.startScan() }
}

@Composable
private fun HeadsetPage(c: AppContainer, s: Settings) {
    SettingSwitch("Pause when headphones are unplugged", "Also when a Bluetooth device disconnects", s.pauseOnUnplug) { v ->
        c.change { it.copy(pauseOnUnplug = v) }
    }
    SettingNote("The play, pause, next and previous buttons on headsets and Bluetooth devices work through the notification and need no setting.")
}

@Composable
private fun LockPage(c: AppContainer, s: Settings) {
    SettingSwitch("Show on lock screen", "Show the player over the lock screen while the app is open", s.showOnLock) { v ->
        c.change { it.copy(showOnLock = v) }
    }
    SettingNote("The lock screen notification shows the cover, the song name and the buttons even with this switched off. This switch only decides whether the app itself can be shown over the lock screen.")
}

@Composable
private fun MiscPage(c: AppContainer) {
    var confirm by remember { mutableStateOf(false) }
    SettingAction("Restore default settings", "Every choice on the settings pages goes back to the start. Songs, playlists and presets stay.") { confirm = true }
    SettingAction("Show tips again", "The small guide on the player screen shows up once more") { c.change { it.copy(tipsShown = false) } }
    if (confirm) {
        AlertDialog(
            onDismissRequest = { confirm = false },
            title = { Text("Restore default settings?") },
            text = { Text("Songs, playlists, bookmarks and saved presets are not touched.") },
            confirmButton = { TextButton(onClick = { c.settings.resetAll(); confirm = false }) { Text("Restore") } },
            dismissButton = { TextButton(onClick = { confirm = false }) { Text("Cancel") } },
        )
    }
}

@Composable
private fun AboutPage() {
    val context = LocalContext.current
    var licences by remember { mutableStateOf(false) }
    val version = remember {
        try {
            val info = context.packageManager.getPackageInfo(context.packageName, 0)
            "${info.versionName} (build ${PackageInfoCompat.getLongVersionCode(info)})"
        } catch (e: Exception) {
            "unknown"
        }
    }
    InfoLine("Version", version)
    SettingAction("Open source licences", "The libraries this app is built with") { licences = true }
    SettingSection("Privacy")
    SettingNote("The app can use the internet, for things you ask for like adding a skin from a web address. Your music, playlists, bookmarks and settings stay on this phone.")
    if (licences) {
        AlertDialog(
            onDismissRequest = { licences = false },
            title = { Text("Open source licences") },
            text = {
                Text(
                    "AndroidX Media3, AndroidX Compose, Room, Navigation and Lifecycle, Kotlin and Kotlin coroutines are used under the " +
                        "Apache License 2.0. The Material icons are used under the Apache License 2.0. The alternative font, Nunito, " +
                        "is used under the SIL Open Font License 1.1.",
                )
            },
            confirmButton = { TextButton(onClick = { licences = false }) { Text("Close") } },
        )
    }
}

@Composable
private fun InfoLine(title: String, value: String) {
    Column(Modifier.padding(horizontal = ApmSpace.s4, vertical = ApmSpace.s2)) {
        Text(title, style = Apm.type.caption, color = n(Color(0xFF9A9A9A)))
        Text(value, style = Apm.type.body, color = Apm.colors.text)
    }
}

/** What the song is, and everything that touches the sound on its way to the speaker. */
@Composable
private fun AudioInfoPage(c: AppContainer) {
    val state by c.player.state.collectAsStateWithLifecycle()
    val sound by c.sound.state.collectAsStateWithLifecycle()
    val fade by c.settings.state.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val outRate = remember {
        (context.getSystemService(Context.AUDIO_SERVICE) as AudioManager).getProperty(AudioManager.PROPERTY_OUTPUT_SAMPLE_RATE)
    }
    if (!state.hasMedia) {
        SettingNote("Nothing is playing. Play a song and come back.")
        return
    }
    fun onOff(v: Boolean) = if (v) "on" else "off"
    InfoLine("Song", state.title)
    SettingSection("Source")
    InfoLine("Codec", state.codec.ifEmpty { "unknown" })
    InfoLine("Sample rate", if (state.sampleRate > 0) "${state.sampleRate} Hz" else "unknown")
    InfoLine("Bit rate", if (state.bitrateBps > 0) "${state.bitrateBps / 1000} kbps" else "unknown")
    InfoLine("Channels", when (state.channels) { 1 -> "Mono"; 2 -> "Stereo"; 0 -> "unknown"; else -> "${state.channels}" })
    SettingSection("Output")
    InfoLine("Phone output rate", outRate?.let { "$it Hz" } ?: "unknown")
    SettingSection("Processing")
    InfoLine(
        "Equalizer",
        if (!sound.eqOn) "off"
        else if (sound.eqMode == MODE_PARAMETRIC) "parametric, ${sound.paramBands.size} filters, preamp ${String.format(Locale.ROOT, "%.1f", sound.preampDb)} dB"
        else "graphic, 10 bands, preamp ${String.format(Locale.ROOT, "%.1f", sound.preampDb)} dB",
    )
    InfoLine("Tone", if (sound.toneOn) "bass ${sound.bassPct.toInt()}%, treble ${sound.treblePct.toInt()}%" else "off")
    InfoLine("Stereo expand", if (sound.stereoExpandPct > 0f) "${sound.stereoExpandPct.toInt()}%" else "off")
    InfoLine("Balance", String.format(Locale.ROOT, "%.2f", sound.balance))
    InfoLine("Mono", onOff(sound.mono))
    InfoLine("Reverb", onOff(sound.reverbOn))
    InfoLine("Limiter", onOff(sound.limiterOn))
    InfoLine("Tempo", if (sound.tempoOn) String.format(Locale.ROOT, "%.2fx", sound.tempo) else "off")
    InfoLine("Volume", "${(sound.volume * 100).toInt()}%")
    InfoLine("Fade on play and pause", if (fade.fadeMs == 0) "off" else "${fade.fadeMs} ms")
}


private val skinJsonExample = """{"name":"Ocean","accent":"#3DA5F4"}"""

/** The Skin page: theme, layout of the player, colours, corners, font, seek bar, knobs, bars. */
@Composable
private fun SkinPage(c: AppContainer, s: Settings, onOpen: (String) -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val skins = allSkins(s)
    val custom = customSkinsFrom(s.customSkins)
    var address by remember { mutableStateOf<String?>(null) }

    fun addSkins(text: String?) {
        val found = if (text == null) emptyList() else parseSkinsText(text)
        if (found.isEmpty()) {
            Toast.makeText(context, "That is not a skin file. It needs a name and an accent like #3DA5F4.", Toast.LENGTH_LONG).show()
        } else {
            c.change { st ->
                val old = customSkinsFrom(st.customSkins).filterNot { o -> found.any { it.name.equals(o.name, ignoreCase = true) } }
                st.copy(customSkins = customSkinsToJson(old + found))
            }
            Toast.makeText(context, "Added ${found.size} skin(s)", Toast.LENGTH_SHORT).show()
        }
    }
    val fileLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            val text = try {
                context.contentResolver.openInputStream(uri)?.use { it.readBytes().toString(Charsets.UTF_8) }
            } catch (e: Exception) {
                null
            }
            addSkins(text)
        }
    }
    val saveLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) {
            val pick = skins[s.skin.coerceIn(0, skins.lastIndex)]
            val ok = try {
                context.contentResolver.openOutputStream(uri)?.use { it.write(customSkinsToJson(listOf(pick)).removePrefix("[").removeSuffix("]").toByteArray()) } != null
            } catch (e: Exception) {
                false
            }
            Toast.makeText(context, if (ok) "Skin saved" else "Could not save the file", Toast.LENGTH_SHORT).show()
        }
    }

    SettingSection("Built-in Skins")
    SettingRadio("Light", "Light look, same layout options", s.themeMode == 1) { c.change { it.copy(themeMode = 1) } }
    SettingRadio("Dark", "Black look, same layout options", s.themeMode != 1) { c.change { it.copy(themeMode = 2) } }

    SettingSection("Layout")
    SettingRadio("Default", "Track labels and buttons on the cover. Best for small or wide screens.", s.layout == 0) { c.change { it.copy(layout = 0) } }
    SettingRadio("Alternative layout", "Moves the track labels below the cover, makes the buttons on the cover smaller and faded", s.layout == 1) {
        c.change { it.copy(layout = 1) }
    }
    SettingRadio("Full cover", "Moves all track labels and buttons below the cover. Works best on long screen phones.", s.layout == 2) {
        c.change { it.copy(layout = 2) }
    }
    SettingAction("Player Screen options", "Rating, menu, lyrics button and more") { onOpen("look_player") }
    SettingAction("Lyrics options", "Lyrics swipe, size, offset") { onOpen("look_lyrics") }

    SettingChoices("Track Labels", "Centered applies to the Alternative layout and Full cover", listOf("Default", "Centered"), if (s.labelsCentered) 1 else 0) { i ->
        c.change { it.copy(labelsCentered = i == 1) }
    }
    SettingChoices("Labels Background", "Hidden removes the dark band behind the labels. Check the Background settings so they stay readable.", listOf("Enabled", "Hidden"), if (s.labelsBg) 0 else 1) { i ->
        c.change { it.copy(labelsBg = i == 0) }
    }
    SettingChoices("Player Buttons Background", "Hidden removes the dark band behind the player buttons", listOf("Enabled", "Hidden"), if (s.buttonsBg) 0 else 1) { i ->
        c.change { it.copy(buttonsBg = i == 0) }
    }
    SettingChoices(
        "Material You colors",
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) "Use the colours of the phone's wallpaper" else "Needs Android 12 or newer",
        listOf("Disabled", "More pronounced", "Less pronounced"), s.materialYou,
    ) { i -> c.change { it.copy(materialYou = i) } }
    SettingChoices("Accent colour", "The colour of buttons, switches and highlights", skins.map { it.name }, s.skin) { i ->
        c.change { it.copy(skin = i) }
    }
    SettingChoices("Font", null, listOf("Default", "Alternative font"), s.fontFamily) { i -> c.change { it.copy(fontFamily = i) } }
    SettingChoices("Font weight", null, listOf("Default", "Bold", "Bold+"), s.fontBoost) { i -> c.change { it.copy(fontBoost = i) } }
    SettingChoices("Rounded Corners", null, listOf("More rounded", "Less rounded"), if (s.lessRounded) 1 else 0) { i ->
        c.change { it.copy(lessRounded = i == 1) }
    }
    SettingChoices(
        "Seekbar Style", "Default: waveform under the buttons. Static: a waveform strip below them. Simple: a plain slider.",
        listOf("Default", "Static Seekbar", "Simple Seekbar (with Pro Buttons)"), s.seekStyle,
    ) { i -> c.change { it.copy(seekStyle = i) } }
    SettingSwitch("Pro Buttons", "The small buttons that go 10 seconds back and forward. Always on for the Simple seek bar.", s.proButtons) { v ->
        c.change { it.copy(proButtons = v) }
    }
    SettingChoices("Knob Highlight", "The ring around the knobs", listOf("None", "Monochromatic", "Colorful"), s.knobHighlight) { i ->
        c.change { it.copy(knobHighlight = i) }
    }
    SettingChoices("Eq. Graphic Mode Curve", null, listOf("Monochromatic", "Colorful"), if (s.eqColorful) 1 else 0) { i ->
        c.change { it.copy(eqColorful = i == 1) }
    }
    SettingChoices(
        "Transparent Status Bar", "Default adds a soft dark band so the icons stay readable over covers",
        listOf("Default", "No Background"), if (s.statusScrim) 0 else 1,
    ) { i -> c.change { it.copy(statusScrim = i == 0) } }
    SettingChoices("Transparent Navbar", "Applied on the Player Screen", listOf("Default", "Semi-transparent", "No Background"), s.navbarPlayer) { i ->
        c.change { it.copy(navbarPlayer = i) }
    }
    SettingSwitch("Offset Navbar", "Move the bottom bar slightly away from the corners (for screens with large corner radius)", s.offsetNavbar) { v ->
        c.change { it.copy(offsetNavbar = v) }
    }
    SettingChoices("Android Navigation Bar", "On the other screens", listOf("Default", "No Background"), s.navbarOther) { i ->
        c.change { it.copy(navbarOther = i) }
    }
    SettingAction("Restore Defaults", null) {
        val d = Settings()
        c.change {
            it.copy(
                themeMode = d.themeMode, layout = d.layout, labelsCentered = d.labelsCentered, labelsBg = d.labelsBg, buttonsBg = d.buttonsBg,
                materialYou = d.materialYou, skin = d.skin, fontFamily = d.fontFamily, fontBoost = d.fontBoost, lessRounded = d.lessRounded,
                seekStyle = d.seekStyle, proButtons = d.proButtons, knobHighlight = d.knobHighlight, eqColorful = d.eqColorful,
                statusScrim = d.statusScrim, navbarPlayer = d.navbarPlayer, offsetNavbar = d.offsetNavbar, navbarOther = d.navbarOther,
            )
        }
    }

    SettingSection("3rd Party Skins")
    if (custom.isEmpty()) {
        SettingNote("No skins added yet. A skin is a small text file like $skinJsonExample.")
    } else {
        custom.forEach { skin ->
            SettingAction(skin.name, "Accent " + skin.accent.toHex() + ". Tap to remove it.") {
                c.change { st -> st.copy(customSkins = customSkinsToJson(customSkinsFrom(st.customSkins).filterNot { it.name == skin.name }), skin = 0) }
            }
        }
    }
    SettingAction("Add a skin from a file", "A text file with a name and an accent colour") { fileLauncher.launch(arrayOf("*/*")) }
    SettingAction("Add a skin from a web address", "An https address of such a file") { address = "" }
    SettingAction("Save the chosen skin to a file", "To share it or keep it") { saveLauncher.launch("apm-skin.json") }

    address?.let { text ->
        NameDialog("Skin web address", text, "Add", { address = null }) { url ->
            address = null
            scope.launch {
                val body = withContext(Dispatchers.IO) { fetchText(url.trim()) }
                if (body == null) Toast.makeText(context, "Could not read that address. It must be https and small.", Toast.LENGTH_LONG).show() else addSkins(body)
            }
        }
    }
}


/** The Icon page: a list of launcher icons with a round marker, picking one changes the app's icon on the phone. */
@Composable
private fun IconPage() {
    val context = LocalContext.current
    var selected by remember { mutableIntStateOf(currentAppIcon(context)) }
    SettingNote("Actual icon look may vary depending on the Android version, the launcher and the system settings.")
    SettingNote("It may take a few seconds for the launcher to update the icon.")
    SettingSection("Icons")
    AppIcons.forEachIndexed { i, icon ->
        val picture = remember(icon.res) {
            androidx.core.content.ContextCompat.getDrawable(context, icon.res)?.toBitmap(128, 128)?.asImageBitmap()
        }
        Row(
            Modifier
                .fillMaxWidth()
                .heightIn(min = 72.dp)
                .focusRing(ApmShape.md)
                .clickable(role = Role.RadioButton) {
                    setAppIcon(context, i)
                    selected = i
                    Toast.makeText(context, "Icon changed. The launcher may take a few seconds.", Toast.LENGTH_SHORT).show()
                }
                .padding(horizontal = ApmSpace.s4, vertical = ApmSpace.s2),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(ApmSpace.s3),
        ) {
            androidx.compose.material3.RadioButton(
                selected = selected == i, onClick = null,
                colors = androidx.compose.material3.RadioButtonDefaults.colors(selectedColor = Apm.colors.accent, unselectedColor = n(Color(0xFF8A8A8A))),
            )
            if (picture != null) {
                androidx.compose.foundation.Image(
                    bitmap = picture, contentDescription = null,
                    modifier = Modifier.size(56.dp).clip(ApmShape.round),
                )
            }
            Column(Modifier.weight(1f)) {
                Text(icon.name, style = Apm.type.body.copy(fontWeight = FontWeight.Bold), color = Apm.colors.text)
                Text(icon.kind, style = Apm.type.bodySm, color = Apm.colors.textMuted)
            }
        }
    }
}
