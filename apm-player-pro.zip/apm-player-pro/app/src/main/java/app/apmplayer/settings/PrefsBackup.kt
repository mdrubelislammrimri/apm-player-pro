package app.apmplayer.settings

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** Saves all choices (settings, sound, presets, small screen choices) to one text, and reads them back. */
object PrefsBackup {
    private val FILES = listOf("settings", "sound", "ui")

    fun export(context: Context): String {
        val files = JSONObject()
        for (name in FILES) {
            val prefs = context.getSharedPreferences(name, Context.MODE_PRIVATE)
            val out = JSONObject()
            for ((key, value) in prefs.all) {
                val entry = JSONObject()
                when (value) {
                    is Boolean -> entry.put("type", "boolean").put("value", value)
                    is Int -> entry.put("type", "int").put("value", value)
                    is Long -> entry.put("type", "long").put("value", value)
                    is Float -> entry.put("type", "float").put("value", value.toDouble())
                    is String -> entry.put("type", "string").put("value", value)
                    is Set<*> -> entry.put("type", "set").put("value", JSONArray(value.map { it.toString() }))
                    else -> continue
                }
                out.put(key, entry)
            }
            files.put(name, out)
        }
        return JSONObject().put("app", "Apm Player Pro").put("version", 1).put("files", files).toString(2)
    }

    /** Returns false when the text is not a backup of this app. Existing choices in the same files are replaced. */
    fun import(context: Context, text: String): Boolean {
        return try {
            val files = JSONObject(text).optJSONObject("files") ?: return false
            var found = false
            for (name in FILES) {
                val saved = files.optJSONObject(name) ?: continue
                found = true
                val edit = context.getSharedPreferences(name, Context.MODE_PRIVATE).edit()
                edit.clear()
                for (key in saved.keys()) {
                    val entry = saved.getJSONObject(key)
                    when (entry.getString("type")) {
                        "boolean" -> edit.putBoolean(key, entry.getBoolean("value"))
                        "int" -> edit.putInt(key, entry.getInt("value"))
                        "long" -> edit.putLong(key, entry.getLong("value"))
                        "float" -> edit.putFloat(key, entry.getDouble("value").toFloat())
                        "string" -> edit.putString(key, entry.getString("value"))
                        "set" -> {
                            val arr = entry.getJSONArray("value")
                            edit.putStringSet(key, HashSet((0 until arr.length()).map { arr.getString(it) }))
                        }
                    }
                }
                edit.apply()
            }
            found
        } catch (e: Exception) {
            false
        }
    }
}
