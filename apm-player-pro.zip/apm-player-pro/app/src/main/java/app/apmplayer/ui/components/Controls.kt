package app.apmplayer.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.semantics.ProgressBarRangeInfo
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.progressBarRangeInfo
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.semantics.setProgress
import androidx.compose.ui.semantics.stateDescription
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import app.apmplayer.ui.theme.Apm
import app.apmplayer.ui.theme.ApmShape
import app.apmplayer.ui.theme.ApmSpace
import java.util.Locale
import kotlin.math.cos
import kotlin.math.sin

val EqGreen = Color(0xFF14E014)
val VolumeRed = Color(0xFFFF1A1A)
private val KnobFace = Color(0xFF222222)
private val KnobRing = Color(0xFF444444)
private val KnobTick = Color(0xFFD0D0D0)

fun oneDecimal(v: Float): String = String.format(Locale.ROOT, "%.1f", v)

/** Round dark knob. Drag up or right to turn up, down or left to turn down. Double tap resets. */
@Composable
fun Knob(
    value: Float,
    min: Float,
    max: Float,
    defaultValue: Float,
    onChange: (Float) -> Unit,
    description: String,
    valueText: String,
    modifier: Modifier = Modifier,
    size: Dp = 96.dp,
    enabled: Boolean = true,
    ringColor: Color? = null,
) {
    val current by rememberUpdatedState(value)
    val sizePx = with(LocalDensity.current) { size.toPx() }
    val pad = if (ringColor != null) 14.dp else 0.dp
    Box(
        modifier = modifier
            .size(size + pad * 2)
            .alpha(if (enabled) 1f else 0.35f)
            .semantics {
                contentDescription = description
                stateDescription = valueText
                progressBarRangeInfo = ProgressBarRangeInfo(value.coerceIn(min, max), min..max)
                if (enabled) setProgress { v -> onChange(v.coerceIn(min, max)); true }
            }
            .pointerInput(enabled, min, max) {
                if (!enabled) return@pointerInput
                detectDragGestures { change, drag ->
                    change.consume()
                    val delta = (drag.x - drag.y) / (sizePx * 1.6f)
                    onChange((current + delta * (max - min)).coerceIn(min, max))
                }
            }
            .pointerInput(enabled, defaultValue) {
                if (!enabled) return@pointerInput
                detectTapGestures(onDoubleTap = { onChange(defaultValue) })
            },
        contentAlignment = Alignment.Center,
    ) {
        Canvas(Modifier.fillMaxSize()) {
            val n = ((current - min) / (max - min)).coerceIn(0f, 1f)
            val c = Offset(this.size.width / 2f, this.size.height / 2f)
            val r = size.toPx() / 2f
            if (ringColor != null) {
                val arcR = r + 8.dp.toPx()
                val arcTop = Offset(c.x - arcR, c.y - arcR)
                val arcSize = Size(arcR * 2, arcR * 2)
                for ((w, a) in listOf(14.dp to 0.12f, 9.dp to 0.25f, 5.dp to 1f)) {
                    drawArc(
                        color = ringColor.copy(alpha = a), startAngle = 135f, sweepAngle = 270f * n,
                        useCenter = false, topLeft = arcTop, size = arcSize,
                        style = Stroke(width = w.toPx(), cap = StrokeCap.Round),
                    )
                }
            }
            drawCircle(KnobFace, radius = r, center = c)
            drawCircle(KnobRing, radius = r, center = c, style = Stroke(3.dp.toPx()))
            val ang = Math.toRadians(135.0 + 270.0 * n)
            val dx = cos(ang).toFloat()
            val dy = sin(ang).toFloat()
            drawLine(
                KnobTick, Offset(c.x + dx * r * 0.58f, c.y + dy * r * 0.58f),
                Offset(c.x + dx * r * 0.82f, c.y + dy * r * 0.82f),
                strokeWidth = 6.dp.toPx(), cap = StrokeCap.Round,
            )
        }
    }
}

/** One vertical equalizer slider with a glowing green fill from the middle to the thumb. */
@Composable
fun EqSlider(
    value: Float,
    range: Float,
    onChange: (Float) -> Unit,
    description: String,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
) {
    val current by rememberUpdatedState(value)
    var heightPx by remember { mutableFloatStateOf(1f) }
    val thumbH = with(LocalDensity.current) { 56.dp.toPx() }
    Box(
        modifier = modifier
            .onSizeChanged { heightPx = it.height.toFloat() }
            .alpha(if (enabled) 1f else 0.4f)
            .semantics {
                contentDescription = description
                stateDescription = oneDecimal(value) + " decibels"
                progressBarRangeInfo = ProgressBarRangeInfo(value.coerceIn(-range, range), -range..range)
                if (enabled) setProgress { v -> onChange(v.coerceIn(-range, range)); true }
            }
            .pointerInput(heightPx, enabled) {
                if (!enabled) return@pointerInput
                val usable = (heightPx - thumbH).coerceAtLeast(1f)
                detectVerticalDragGestures { change, drag ->
                    change.consume()
                    onChange((current - drag / usable * 2f * range).coerceIn(-range, range))
                }
            }
            .pointerInput(heightPx, enabled) {
                if (!enabled) return@pointerInput
                val usable = (heightPx - thumbH).coerceAtLeast(1f)
                detectTapGestures(
                    onTap = { o -> onChange((range - (o.y - thumbH / 2f) / usable * 2f * range).coerceIn(-range, range)) },
                    onDoubleTap = { onChange(0f) },
                )
            },
    ) {
        Canvas(Modifier.fillMaxSize()) {
            val x = size.width / 2f
            val usable = (size.height - thumbH).coerceAtLeast(1f)
            val mid = size.height / 2f
            val thumbY = mid - (current / range) * (usable / 2f)
            // track and end marks
            drawLine(Color(0xFF666666), Offset(x, 0f), Offset(x, size.height), strokeWidth = 2.dp.toPx())
            val top = thumbH / 2f
            val bottom = size.height - thumbH / 2f
            for (y in listOf(top, bottom)) {
                drawLine(Color(0xFF777777), Offset(x - 14.dp.toPx(), y), Offset(x - 8.dp.toPx(), y), strokeWidth = 2.dp.toPx())
                drawLine(Color(0xFF777777), Offset(x + 8.dp.toPx(), y), Offset(x + 14.dp.toPx(), y), strokeWidth = 2.dp.toPx())
            }
            // glow from the middle to the thumb
            for ((w, a) in listOf(10.dp to 0.12f, 6.dp to 0.25f, 3.dp to 1f)) {
                drawLine(EqGreen.copy(alpha = a), Offset(x, mid), Offset(x, thumbY), strokeWidth = w.toPx(), cap = StrokeCap.Round)
            }
            // thumb
            val tw = minOf(size.width * 0.92f, 30.dp.toPx())
            val tl = Offset(x - tw / 2f, thumbY - thumbH / 2f)
            drawRoundRect(Color(0xFF232323), tl, Size(tw, thumbH), CornerRadius(tw * 0.45f))
            drawRoundRect(Color(0xFF4A4A4A), tl, Size(tw, thumbH), CornerRadius(tw * 0.45f), style = Stroke(2.dp.toPx()))
            drawLine(
                Color(0xFFE6E6E6), Offset(x - tw * 0.25f, thumbY), Offset(x + tw * 0.25f, thumbY),
                strokeWidth = 3.dp.toPx(), cap = StrokeCap.Round,
            )
        }
    }
}

/** Dark pill that shows on or off, like Equ, Tone, Limit, Tempo, Mono. */
@Composable
fun TogglePill(text: String, on: Boolean, onClick: () -> Unit, modifier: Modifier = Modifier) {
    val colors = Apm.colors
    Box(
        modifier = modifier
            .heightIn(min = 48.dp)
            .clip(ApmShape.pill)
            .background(if (on) Color(0xFF2C2C2C) else Color(0xFF161616))
            .border(1.5.dp, if (on) colors.accent else Color.Transparent, ApmShape.pill)
            .focusRing(ApmShape.pill)
            .clickable(role = Role.Switch, onClick = onClick)
            .padding(horizontal = ApmSpace.s5),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            text, style = Apm.type.body.copy(fontWeight = FontWeight.Bold),
            color = if (on) colors.text else Color(0xFF8A8A8A), textAlign = TextAlign.Center,
        )
    }
}

/** Outlined pill button, like Preset, Save, Reset. */
@Composable
fun OutlinePill(text: String, onClick: () -> Unit, modifier: Modifier = Modifier, enabled: Boolean = true) {
    val colors = Apm.colors
    Box(
        modifier = modifier
            .heightIn(min = 48.dp)
            .alpha(if (enabled) 1f else 0.4f)
            .clip(ApmShape.pill)
            .border(1.5.dp, Color(0xFF8A8A8A), ApmShape.pill)
            .focusRing(ApmShape.pill)
            .clickable(enabled = enabled, role = Role.Button, onClick = onClick)
            .padding(horizontal = ApmSpace.s5),
        contentAlignment = Alignment.Center,
    ) {
        Text(text, style = Apm.type.body.copy(fontWeight = FontWeight.Bold), color = colors.text)
    }
}

@Composable
fun BoldLabel(title: String, value: String, modifier: Modifier = Modifier, align: TextAlign = TextAlign.Center) {
    Column(modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        Text(title, style = Apm.type.bodySm.copy(fontWeight = FontWeight.Bold), color = Apm.colors.text, textAlign = align)
        Text(value, style = Apm.type.bodySm.copy(fontWeight = FontWeight.SemiBold), color = Color(0xFF8A8A8A), textAlign = align)
    }
}
