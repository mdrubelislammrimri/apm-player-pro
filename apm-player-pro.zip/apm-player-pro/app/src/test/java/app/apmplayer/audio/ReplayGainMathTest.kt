package app.apmplayer.audio

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class ReplayGainMathTest {
    @Test fun parsesTheNumberInGainText() {
        assertEquals(-6.5f, ReplayGainMath.parseGain("-6.50 dB")!!, 0.001f)
        assertEquals(3.2f, ReplayGainMath.parseGain("+3,2 dB")!!, 0.001f)
        assertNull(ReplayGainMath.parseGain("no number"))
    }

    @Test fun trackModeUsesTrackGainThenAlbumGain() {
        val both = RgInfo(-5f, -7f, null, null)
        assertEquals(-5f, ReplayGainMath.gainDb(both, 0, 0f, 0f, false), 0.001f)
        assertEquals(-7f, ReplayGainMath.gainDb(both, 1, 0f, 0f, false), 0.001f)
        val onlyAlbum = RgInfo(null, -7f, null, null)
        assertEquals(-7f, ReplayGainMath.gainDb(onlyAlbum, 0, 0f, 0f, false), 0.001f)
    }

    @Test fun usesThePreampWithoutTagsOnlyWhenThereIsNoGain() {
        assertEquals(-3f, ReplayGainMath.gainDb(null, 0, 2f, -3f, false), 0.001f)
        assertEquals(-3f, ReplayGainMath.gainDb(RgInfo(null, null, 0.9f, null), 0, 2f, -3f, false), 0.001f)
        assertEquals(-3f, ReplayGainMath.gainDb(RgInfo(-5f, null, null, null), 0, 2f, -9f, false), 0.001f)
    }

    @Test fun preventClippingKeepsThePeakBelowFullScale() {
        // a peak of 0.5 can only be raised by about 6 dB
        val info = RgInfo(10f, null, 0.5f, null)
        assertEquals(6.0206f, ReplayGainMath.gainDb(info, 0, 0f, 0f, true), 0.01f)
        assertEquals(10f, ReplayGainMath.gainDb(info, 0, 0f, 0f, false), 0.001f)
    }
}
