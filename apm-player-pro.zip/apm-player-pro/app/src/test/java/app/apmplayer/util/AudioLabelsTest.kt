package app.apmplayer.util

import org.junit.Assert.assertEquals
import org.junit.Test

class AudioLabelsTest {
    @Test fun kiloHertzWhole() = assertEquals("48", formatKiloHertz(48000))
    @Test fun kiloHertzFraction() = assertEquals("44.1", formatKiloHertz(44100))
    @Test fun aacLc() = assertEquals("AAC LC", codecLabel("audio/mp4a-latm", "mp4a.40.2"))
    @Test fun mp3() = assertEquals("MP3", codecLabel("audio/mpeg", null))
    @Test fun unknownMimeUsesSubtype() = assertEquals("XYZ", codecLabel("audio/xyz", null))
    @Test fun infoLineFull() = assertEquals("44.1 KHZ 96 KBPS AAC LC", audioInfoLine(44100, 96000, "AAC LC"))
    @Test fun infoLineSkipsUnknown() = assertEquals("FLAC", audioInfoLine(-1, -1, "FLAC"))
    @Test fun extensionM4a() = assertEquals("m4a", mimeToExtension("audio/mp4"))
    @Test fun extensionFallback() = assertEquals("amr", mimeToExtension("audio/x-amr"))
    @Test fun extensionNull() = assertEquals("", mimeToExtension(null))
}
