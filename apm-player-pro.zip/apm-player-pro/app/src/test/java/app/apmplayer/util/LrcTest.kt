package app.apmplayer.util

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class LrcTest {
    @Test fun readsTimes() {
        val p = parseLyrics("[00:12.50]first\n[01:05.00]second")
        assertTrue(p.synced)
        assertEquals(listOf(12_500L, 65_000L), p.lines.map { it.timeMs })
        assertEquals(listOf("first", "second"), p.lines.map { it.text })
    }
    @Test fun oneLineWithTwoTimes() {
        val p = parseLyrics("[00:10.00][00:30.00]chorus\n[00:20.00]verse")
        assertEquals(listOf(10_000L, 20_000L, 30_000L), p.lines.map { it.timeMs })
        assertEquals(listOf("chorus", "verse", "chorus"), p.lines.map { it.text })
    }
    @Test fun skipsFileTags() {
        val p = parseLyrics("[ar:Someone]\n[ti:A song]\n[00:01.00]hello\n[00:02.00]world")
        assertEquals(2, p.lines.size)
    }
    @Test fun twoDigitFractionIsHundredths() = assertEquals(1_230L, parseLyrics("[00:01.23]a\n[00:09.00]b").lines.first().timeMs)
    @Test fun threeDigitFractionIsMillis() = assertEquals(1_234L, parseLyrics("[00:01.234]a\n[00:09.000]b").lines.first().timeMs)
    @Test fun plainTextIsNotSynced() {
        val p = parseLyrics("\nline one\n\nline two\n\n")
        assertFalse(p.synced)
        assertEquals(listOf("line one", "", "line two"), p.lines.map { it.text })
    }
    @Test fun currentLine() {
        val lines = parseLyrics("[00:10.00]a\n[00:20.00]b\n[00:30.00]c").lines
        assertEquals(-1, currentLyricIndex(lines, 5_000))
        assertEquals(1, currentLyricIndex(lines, 25_000))
        assertEquals(2, currentLyricIndex(lines, 99_000))
    }
}
