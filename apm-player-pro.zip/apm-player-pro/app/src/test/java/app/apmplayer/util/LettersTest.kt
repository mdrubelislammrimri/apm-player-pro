package app.apmplayer.util

import org.junit.Assert.assertEquals
import org.junit.Test

class LettersTest {
    @Test fun upperCase() = assertEquals('A', indexLetter("Aankhon Se Tune"))
    @Test fun lowerCase() = assertEquals('B', indexLetter("baarish"))
    @Test fun leadingSpaces() = assertEquals('C', indexLetter("  Cham Cham"))
    @Test fun digit() = assertEquals('#', indexLetter("2026 mix"))
    @Test fun otherScript() = assertEquals('#', indexLetter("আমার"))
    @Test fun empty() = assertEquals('#', indexLetter(""))
}
