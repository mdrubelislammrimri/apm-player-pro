package app.apmplayer.util

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class PathsTest {
    @Test fun normalizeTrimsSlashes() = assertEquals("Music/Rock", normalizeFolderPath("Music/Rock/"))
    @Test fun normalizeEmptyIsStorageRoot() = assertEquals(STORAGE_ROOT_NAME, normalizeFolderPath(""))
    @Test fun normalizeNullIsStorageRoot() = assertEquals(STORAGE_ROOT_NAME, normalizeFolderPath(null))
    @Test fun parentOfNested() = assertEquals("Music", parentFolderPath("Music/Rock"))
    @Test fun parentOfTopLevelIsNull() = assertNull(parentFolderPath("Music"))
    @Test fun displayName() = assertEquals("Rock", folderDisplayName("Music/Rock"))
    @Test fun filePathBecomesRelative() =
        assertEquals("/Music/Rock", relativeFolderFromFilePath("/storage/emulated/0/Music/Rock/a.mp3", "/storage/emulated/0"))
    @Test fun durationMinutes() = assertEquals("1:49", formatDuration(109_000))
    @Test fun durationHours() = assertEquals("1:02:03", formatDuration(3_723_000))
    @Test fun durationNegativeIsZero() = assertEquals("0:00", formatDuration(-5))
}
