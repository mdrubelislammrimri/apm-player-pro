# Room and Media3 ship their own consumer rules. Add app-specific rules here if release builds break.
