# Apm Player Pro (working name)

Android music player, first slice: scan the phone, browse folders, play a song with a notification and a mini player.

## Open and run
1. Android Studio (current stable). File > Open > this folder.
2. If it asks to create the Gradle wrapper or upgrade Gradle or AGP, accept. Versions are pinned conservatively (compileSdk 35).
3. Let it sync, then Run on a phone or emulator with some audio files on it.
4. First launch asks for music access, then scans.

## Before publishing
- Set the real `applicationId` in `app/build.gradle.kts`. It cannot change after the first Play upload.
- Check the target SDK Google Play currently requires and raise `compileSdk` / `targetSdk` to match.
- Replace the placeholder icon and name in the brand step.

## Not built yet
Equalizer, waveform seek bar, albums, search, queue, playlists, settings, purchase unlock.
See `replica/features.csv` and `replica/build-log.md`.
